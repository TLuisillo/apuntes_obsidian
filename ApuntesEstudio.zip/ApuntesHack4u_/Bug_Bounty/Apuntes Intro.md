
----
- Tags: #bugbounty #web 
----

#### Curl (Client URL)

- Peticion basica
```bash
curl domain.com
```

- Peticion con descarga y parametro **s** modo silencioso (parecido a mandar stdr al /dev/null para no ver output)
```bash
curl -s -O domain.com/index.html
```

- Redirect peticion con **POST** parametro **L**
```bash
curl -X POST -d 'username=admin&password=admin' http://<SERVER_IP>:<PORT>/ -L
```

- Especificar una cookie de sesion:
```bash
curl -b 'PHPSESSID=c1nsa6op7vtk7kdis7bcnbadf1' http://<SERVER_IP>:<PORT>/
```

- Salida en formato **JSON**, pipe *JQ*
```bash
curl -X POST -d '{"search":" "}' http://host/index.php -H 'Content-Type: application/json' | jq
```