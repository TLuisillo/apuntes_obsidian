# 🧠 Bug Bounty Hub

> Tu centro de mando para aprender, practicar y reportar.

---

## 📆 Planner Semanal

| Día        | Actividad                                               | Horas |
|------------|---------------------------------------------------------|-------|
| Lunes      | Estudio de contenido (videos, artículos, podcasts)      | 2–4h  |
| Martes     | Investigación de herramientas y técnicas                | 2–4h  |
| Miércoles  | Práctica teórica + preparar el finde                    | 2–4h  |
| Jueves     | 🧠 Día libre para tareas de UNI                          | —     |
| Viernes    | Práctica técnica: Burp Suite, recon                     | 2–4h  |
| Sábado     | Práctica intensiva (labs, recon real, bug hunting)     | 4–8h  |
| Domingo    | Práctica intensiva (labs, recon real, bug hunting)     | 4–8h  |

---

## 🧰 Herramientas

### Recon
- [ ] `subfinder`
- [ ] `httpx`
- [ ] `gau`
- [ ] `waybackurls`
- [ ] `amass`
- [ ] `katana`
- [ ] `loxs.py`
- [ ] `paramsipder`

### Fuzzing / Scanning
- [ ] `ffuf`
- [ ] `nuclei`
- [ ] `dirsearch`
- [ ] `dalfox`
- [ ] `burp suite` (pro / community)

### Otros útiles
- [ ] `QSReplace`
- [ ] `Interactsh`
- [ ] `LinkFinder`

---

## 🧪 Laboratorios (PortSwigger)

- [ ] XSS: Reflejado
- [ ] XSS: Almacenado
- [ ] XSS: DOM-Based
- [ ] SQLi: Inyección clásica
- [ ] SQLi: Blind
- [ ] IDOR: Acceso directo a objetos
- [ ] CSRF
- [ ] XXE
- [ ] SSRF
- [ ] ...

📝 **Notas:**  
> _Anota trucos, payloads efectivos o formas distintas de resolver los labs._

---

## 📚 Writeups y PoCs Interesantes

- ✍️ [Nombre de la vuln] - [Link al writeup]  
  → _Resumen corto, puntos clave, payload usado_

- ✍️ [LiveOverflow Video #X]  
  → _Qué aprendiste, qué técnica te interesa probar_

---

## 🧭 Metodología Personal

### 🛠️ Recon
1. Enumeración de subdominios con `subfinder`, `amass`.
2. Revisión con `httpx` + screenshots.
3. Escaneo con `nuclei` para fingerprints.
4. `gau` + `waybackurls` para rutas antiguas.

### 📌 Manual Testing
1. Navegación + Burp Suite (interceptar y registrar).
2. Fuzzing de parámetros (IDOR, XSS, etc.).
3. Validar cookies, headers, roles, CSRF tokens.
4. Revisar paneles de admin, cambios de privilegios.

---

## 🔍 Hallazgos & Intentos

### 🧷 Programa: [Nombre / URL]
- Fecha: [YYYY-MM-DD]
- Herramientas usadas: ...
- Observaciones:
  - [ ] Posible IDOR
  - [ ] Endpoint sospechoso
  - [ ] Necesita validación manual

📝 **Notas técnicas:**  
> Logs, payloads probados, respuestas del servidor, comportamiento observado.

---

## 🌐 Comunidades & Recursos

### YouTube
- [ ] NahamSec
- [ ] LiveOverflow
- [ ] InsiderPhD
- [ ] STÖK

### Podcasts
- [ ] Darknet Diaries
- [ ] Critical Thinking – by NahamSec

### Plataformas
- [ ] HackerOne
- [ ] Bugcrowd
- [ ] Intigriti
- [ ] YesWeHack

### Discord / Reddit
- [ ] r/bugbounty
- [ ] Discord de NahamSec
- [ ] Bug Bounty Radar

---

## 📒 Payloads Útiles

```js
// XSS básico
"><script>alert(1)</script>

// SQLi clásico
' OR 1=1 --

