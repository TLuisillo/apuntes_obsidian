---

---
---
- Tags:  #writeup #info #htb #ejpt
----
# Reconocimiento

- [x] Puertos *Abiertos*( 22,80)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones
En este punto encontarmos una ruta /content, la cual contiene un archivo XML el cual muestra que el usuario **admin** existe. 

----------
# Enumeracion

- **OS**:

- **Credentials**

- **Pendientes**

- ### INFO GRAL



------
# Explotacion
Teniendo en cuenta que no conocemos la password del usario **Admin** intentamos reutilizar contraseñas, credenciales por defecto, etc.
La contraseña es **nibbles**, al igual que el nombre de la maquina.

- Dentro tenemos un *CMS nibbleblog* el cual dispone de una version desactualizada (4.0.3), dicha version es vulnerable a una subida de archivos. Reportada con el **CVE-2015-6967**
- [Github Exploit](https://github.com/dix0nym/CVE-2015-6967)

```bash
python3 exploit.py --url http://10.10.10.75/nibbleblog/ --username admin --password nibbles --payload shell.php
```



### Vias Potenciales Explotacion
Brute force hydra /admin panel

---------
# Privesc

- [x] sudo -l
Disponemos de ejecucion de comando  **monitor.sh**, como root sin proporcionar contraseña.
En este binario tenemos permisos de escritura, simplemente cambiamos el permiso de la bash a [[SUID]]
##### PWNED
- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits
- [x] BruteForce Su


------------
