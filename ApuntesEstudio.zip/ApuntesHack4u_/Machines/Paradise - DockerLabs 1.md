---

---
---
- Tags:  #writeup #info #dockerlabs #tutorial 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 80,445,139,22)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**: Information Leakage

- **Credentials**: -- lucas:chocolate

- **Pendientes** --
  Encoded hash in base64


-----

- ### INFO GRAL
No vale brga la maquina .

------
# Explotacion

- Ruta http://172.17.0.2/galery.html, con leakage en codigo fuente
- Ruta expuesta:  172.17.0.2/estoesunsecreto/mensaje_para_lucas.txt
- Bruteforce attack a el usuario lucas.  Pass --> **chocolate** 

---------
# Privesc

- [x] sudo -l
    - Abusando de binario con persimos de sudo como el usuario andy **/usr/bin/sed**
```bash
sudo -u andy /usr/bin/sed -n '1e exec sh 1>&0' /etc/hosts
```

- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits
- [x] BruteForce Su

- Bianrio **/usr/local/bin/privileged_exec** (ni idea) 
- Root -- Pwned!

------------
