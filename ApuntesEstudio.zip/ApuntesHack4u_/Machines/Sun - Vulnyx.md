---

---
---
- Tags:  #writeup #info #vulnyx #smb #cme
----
# Reconocimiento

- [x] Puertos *Abiertos*(8080,80,22,445,139)
 Esta WEB es 100% aspx ASP_NET
 La explotacion comienza por  [[SMB - 445]] [[Samba]]


- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**: Debian

- **Credentials**: punt4n0:sunday

- **Pendientes**: smbmap,smblclient, rpcclient

- ### INFO GRAL

- ## Enumeracion SMB

```shell
nmap -p445 --script
```

```shell
smbclient -NL 192.168.1.72

smbmap -H "host"
```
 
 - No encontramos algo para inspeccionar, vamos a enumerar *Usuarios* **RIDs Cycling** 
 Este comando intenta buscar el nombre de usuario asociado con el SID `root` en el servidor remoto especificado.
 
```shell
rpcclient -W '' -U ''%'' 192.168.1.72 -c 'lookupnames root'
```

- Con este comando estamos intentando con [[RPC Client]] y un usuario *Vacio / Nulo* y con el parametro *-c* para ejecutar el comando **lookupnames root** en la maquina remota y buscar al usuario *ROOT*

```salida del comando
root S-1-22-1-0 (User: 1)
```

- Podemos ver **El SID (Security Identifier)** *S-1-22-1-0*
- Ahora se utiliza el comando `rpcclient` para realizar consultas a un servidor remoto utilizando el protocolo RPC (Remote Procedure Call).

- El script ejecuta un bucle `for` que va desde 1000 hasta 1005, y en cada iteración, ejecuta el comando `rpcclient` con el parámetro `-c` que realiza una consulta específica al servidor remoto.

```shell
for i in $(seq 1000 1005); do bash -c "rpcclient -W '' -U ''%'' 192.168.1.72 -c 'lookupsids S-1-22-1-$i'" ;done
```


```SALIDA DEL COMANDO
S-1-22-1-1000 Unix User\punt4n0 (1)  
S-1-22-1-1001 Unix User\1001 (1)  
S-1-22-1-1002 Unix User\1002 (1)  
S-1-22-1-1003 Unix User\1003 (1)  
S-1-22-1-1004 Unix User\1004 (1)  
S-1-22-1-1005 Unix User\1005 (1)
```

- Podemos Ver el usuario **punt4n0**
- Ahora con [[crackmapexec]] vamos a intentar hacer *Fuerza Bruta* a la contrasena (sunday)

```shell
crackmapexec smb 192.168.1.72 -u punt4n0 -p /opt/techyou.txt |grep -v '[-]'
```

```SALIDA DE COMANDO
SMB         192.168.1.72    445    SUN              [*] Windows 6.1 Build 0
SMB         192.168.1.72    445    SUN              [+] SUN\punt4n0:sunday
```

- Con estas credenciales nos conectamos con [[smbclient]]
```shell
smbmap -u punt4n0 -p sunday -H 192.168.1.72
```

### Explicacion
Dentro del smb al parecer estamos en el recurso compartido de la Pagina WEB *(Puerto 8080)* el cual funciona con *ASP_NET*

- Dentro del [[smb]] usando el metodo *PUT* podemos subirle una *shell.aspx* ya que corre *ASP_NET* 

- De esta forma podemos ver que tenemos un **RCE** 
- En este punto no me fue posible entablar una [[Reverse Shell]] pero usando este vector de explotacion, controlando el parametro *cmd* podemos ver el contenido del **id_rsa** y de un archivo *remember_pass* (el cual contiene una credencial)
  
  - Aqui tratamos de conectarnos por [[SSH - 22]] con las credenciales obtenidas *(punt4n0:sunday)* no nos deja conectarnos usando el *id_rsa*, nos pide una *Phrase*, al parecer esta protegida, pero esta *frase o contrasena* es la que encontramos en el archivo *.remember_pass*

- Aqui ya podemos conectarnos por [[SSH - 22]]


------
# Explotacion

### Vias Potenciales Explotacion

La **PRIVESC** va por una [[Detección y explotación de tareas Cron]]
usando **PSPY** o nuestro [[Manual PSPY]]

Encuentro una [[Detección y explotación de tareas Cron]] que ejecuta un **script** `.ps1 (PowerShell)`, el **script** ejecuta el comando `id` y la salida del comando se guarda en `/dev/shm` en un archivo saliente llamado `out`


- el propietario de `service.ps1` es `root` y “**otros”** pueden escribir

## Simplemente cambiamos el contenido del archivo para por ejemplo, modificar el permiso de la *BASH* a *SUID*

# PWNED

---------
# Privesc

- [x] sudo -l
- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
  ###### This 
  
- [x] Kernel Exploits


------------
