---

---
---
- Tags:  #writeup #info #vulnhub #tutorial #smb #sql 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 21,22,80,139,445)
- [x] Servicios
- [ ] WhatWeb
- [ ] Headers
- [ ] Gobsuter
- [ ] Gobuster Extensiones

----------
# Enumeracion

- **OS**:Debian *stretch*
- **Credentials**
Anonymous
aeolus
- **Pendientes**

- ### INFO GRAL



------
# Explotacion

### Vias Potenciales Explotacion

---------
# Privesc

- [ ] sudo -l
- [ ] history
- [ ] SUID
- [ ] crontab
- [ ] getcap
- [ ] find .txt
- [ ] find .sh
- [ ] id
- [ ] env
- [ ] /opt /tmp
- [ ] pspy, lse, linpeas,etc
- [ ] Kernel Exploits


------------
