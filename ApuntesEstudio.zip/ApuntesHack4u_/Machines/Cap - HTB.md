---

---
---
- Tags:  #writeup #info #htb  #tutorial #tshark #capabilities 
----
# Reconocimiento

- [x] Puertos *Abiertos*(21,22,80)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:

- **Credentials**

- **Pendientes**

- ### INFO GRAL

Se tiene al parcer un panel de administarcion o gestion de Red, por el estilo

------
# Explotacion
- Se tiene un idor en la url donde se almacenan las capturas, podemos cambiar al numero **/0**
y el contenido cambia permitiendonos descargar una caputra
### Vias Potenciales Explotacion

- Leemos la captura, por ejmplo con [[tshark]], aunque tambien se podria usando [[TO DO/Wireshark|Wireshark]]
```
tshark -r captura.pcap -Y 'ftp'
```

- Aqui leemos una conexion realizada por el usuario *Nathan*, podemos leer su pass en texto claro
- Con estas credenciales podemos entrar por [[FTP - 21]] y leer la flag user.txt
- Tambien podemos reutilizar credenciales y conectarnos ahora por [[SSH - 22]]

---------
# Privesc

- [x] sudo -l
- [x] history
- [x] SUID
- [x] crontab

- [x] getcap  
 // Capabilities
 
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits
- [x] BruteForce Su

- El usuario **Nathan** tiene la capabilite con Python3.8 
-  setcap cap_setuid+ep python
- Gtfobins y padentro!

```bash
python3 -c 'import os; os.setuid(0); os.system("/bin/sh")'

//PWNED!
```

------------
