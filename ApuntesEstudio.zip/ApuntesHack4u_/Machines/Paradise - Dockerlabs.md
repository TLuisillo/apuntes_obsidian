---

---
---
- Tags:  #writeup #dockerlabs 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 80,22,139,445)
- [ ] Servicios
- [ ] WhatWeb
- [ ] Headers
- [ ] Gobsuter
- [ ] Gobuster Extensiones

----------
# Enumeracion

- **OS**:

- **Credentials**

- **Pendientes**

- ### INFO GRAL



------
# Explotacion

### Vias Potenciales Explotacion

---------
# Privesc

- [ ] sudo -l
- [ ] history
- [ ] SUID
- [ ] crontab
- [ ] getcap
- [ ] find .txt
- [ ] find .sh
- [ ] id
- [ ] env
- [ ] /opt /tmp
- [ ] pspy, lse, linpeas,etc
- [ ] Kernel Exploits
- [ ] BruteForce Su


------------
