---

---
---
- Tags:  #writeup #info #vulnyx #tutorial #sudo #web 
----
# Reconocimiento

- [x] Puertos *Abiertos*([[FTP - 21]] ,[[SSH - 22]], [[80 HTTP]], *9090*)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**: Debian Bullseye

- **Credentials**marco

- **Pendientes**

- ### INFO GRAL
La maquina tiene habilitao usuario *Anonymous* por [[FTP - 21]], dentro hay un *backup*


-- ----
# Explotacion

Con la herramienta [Firerox_decrypt](https://github.com/unode/firefox_decrypt)
Desencriptamos la carpeta del *Backup*

### Vias Potenciales Explotacion
- Si usamos la herramienta en local, haremos un decript de *Nuestro* firefox
```bash
python firefox_decrypt.py
```

- Para hacerlo en el archivo *backup*, hacemos el *git clone* dentro de la carpeta y le pasamos la ruta del *Firefox* o lo que necesitemos desencriptar que contenga el *profiles.ini*
```bash
python firefox_decrypt.py python firefox_decrypt.py /folder/containing/profiles.ini/
```

- Obentemos las credenciales del *Login*
- Una vez dentro vemos el apartado */Terminal*
- Una simple [[Reverse Shell]] y entramos
 ---------
# Privesc

- [x] sudo -l
	- La escalada es que podemos ejecutar como *root*, sin proporcionar contraseña el binario */usr/bin/units*
	- Al parecer es una herramienta para realizar conversiones de varias medias 
	- Al ejecutarlo entramos en modo interactivo.
	- Lo que hacemos es entrar a *--help*, Lo cual hace que nos de la opcion de pasarle comandos, como por ejemplo *!/bin/bash -p*
	- Y pa dentro!
	
- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits


------------
