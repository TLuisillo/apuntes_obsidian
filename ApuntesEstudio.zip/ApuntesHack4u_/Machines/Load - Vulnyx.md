---

---
---
- Tags:  #writeup #info #vulnhub #tutorial
----
# Reconocimiento

- [x] Puertos *Abiertos*( )
[[SSH - 22]] , *80*
- [x] Servicios

MySQL 8.0.25

- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:Debian

- **Credentials**

- **Pendientes**

- ### INFO GRAL
*RiteCMS 3.1*



------
# Explotacion
Nos autenticamos sin mas como usuario admin:admin
Subimos WebShell
### Vias Potenciales Explotacion

---------
# Privesc

- [x] sudo -l
	 - Migramos al usuario *Travis* con
	/usr/bin/crash [[GTFOBins]]

	- Aqui tenemos permisos para ejecutar este binario como *Root*:	 /usr/bin/xauth , Simplemente leemos el archivo:
		/usr/bin/xauth source /root/.ssh/id_rsa	
		y usamos esta clave privada de *Root* para conectarnos por [[SSH - 22]]
		y pa dentro!
---------

- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits


------------
