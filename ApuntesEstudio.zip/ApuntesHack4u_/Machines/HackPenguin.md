---

---
---
- Tags:  #writeup #info #hackerlabs #cracking 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 22,80)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

Encontramos un **penguin.html**

----------
# Enumeracion

- **OS**: ubuntu jammy

- **Credentials**: pinguinomaravilloso123, password1

- **Pendientes**: Probar Esteganografía

- ### INFO GRAL: 

Encontramos un **penguin.html**

------
# Explotacion

### Vias Potenciales Explotacion:

En el penguin.html
Encontramos una imagen **penguin.jpg**, y nada mas

- Buscamos con [[StegHide]]
```shell
steghide -sf penguin.jpg
```

- Nos pide una contrasena, la cual no conocemos, vamos a hacer un script que automatice la **phrase** o inyeccion de contrasena.

- La contrasena es **chocolate**, obtenemos **penguin.kdbx**

- con *keepass2* **penguin.kdbx**
- **keepass2john** penguin.kdbx > password
- john password
- obtenemos la contrasena **password1**

Dentro obtenemos una contrasena para el usuario **penguin:pinguinomaravilloso123**

---------
# Privesc

- [x] sudo -l
- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc:

  Usamos nuestro [[Manual PSPY]]

  ###### La escalada es sencillamente un script.sh que se ejecuta como Root. tenemos permiso de escritura, simplemente le cambiamos el permiso a [[SUID]] y padentro!

- [x] Kernel Exploits

------------
