---

---
---
- Tags:  #writeup #info #vulnyx  #tutorial #web 
----
# Reconocimiento

- [x] Puertos *Abiertos*( [[SSH - 22]],*80* , *8080*)
- [x] Servicios [[SSH]], *HTTP*
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:

- **Credentials**

- **Pendientes**

- ### INFO GRAL
Acepta peticiones por *PUT* y *MOVE*


------
# Explotacion

- Usando *CURL* y provechando *PUT*, Subimos un archivo.txt(*webshell*)
```bash
curl -v -X PUT -T shell.txt http://url
```

- Y ahora con *CURL*, usando *MOVE* le cambiamos el nombre o la extension a *PHP*
```bash
curl -v -X MOVE --header "Destination:http://IP/shell.php" "http://IP/shell.txt"
```
### Vias Potenciales Explotacion

- Oneliner de siempre, reverse shell y pa dentro!

---------
# Privesc

- [x] sudo -l
- Pivoting sencillo a usuario con binario *XARGS*
- Y dicho usuario tiene privielegios para usar */usr/bin/su* como *root*
- Sudo su y pa dentro EZ


- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp
- [x] pspy, lse, linpeas,etc
- [x] Kernel Exploits


------------
