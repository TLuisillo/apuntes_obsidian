
------------
- Tags:  #writeup #info #vulnhub #tutorial #enum 
-----------

# Enumeracion 
- En esta maquina solamente tenemos el puerto 8080 abierto, no queda otro que ver la web. La cual es una especie de chat. Se intenta todo tipo de inyeccion de codigo, XSS, CSRF, pero nada.
- No queda otro que *Fuzzear*, Aqui es el punto clave, ya que la enumeracion no la hacemos como normalmente se hace, a la pagina no le gusta las peticiones con Gobuster, o wfuzz. Debido
a que tiene una especie de *redirect*, en este caso lo que hacemos es usar [[wfuzz]], pero de una forma mas *explicita*:
```bash
	wfuzz -c -t 200 -w /usr/share/seclists/Discovery/Web-Content/common.txt -z list,html-php-txt -u 'http://192.168.3.193:8080/FUZZ.FUZ2Z'  --hc=404 --hh=2899
```

De esta forma Podemos hacer uso de extensiones con [[wfuzz]] y especificarle que nos oculte codigos de *estado* 404 y contenidos con 2899 *caracteres*.

- Nos encuentra los recursos *Administration.php* y *Process.php*.
- Hasta este punto no tenemos nada en *Process* lo descartamos.
- Por otro lado en *administration.php*, nos aparece que no tenemos permiso para ver el contenido *X*. Entonces como es un recurso *php*, podemos intentar fuzzear algun *parametro*.

```bash
wfuzz -c -t 200 -w /usr/share/seclists/Discovery/Web-Content/common.txt -u 'http://192.168.3.193:8080/administration.php?FUZZ=/etc/passwd' --hc=404 --hh=65
```

- Encontramos el parametro *logfile*
Por lo cual de esta forma tenemos un [[Local File Inclusion (LFI)]],  como tal no nos muestra el /etc/passwd, pero nos muestra el parametro debido a que cambia la longitud de los caracteres que pusimos en *blacklist*. No podemos bypassear el LFI con
```bash
../../../../../../../../../etc/passwd
....//....//....//....//....//....//....//....//....//etc/passwd
urlencode,etc,etc
```

- Pero lo que si podemos hacer es apuntar a otros archivos de la misma maquina como el *chat.txt*, por lo cual podemos intentar insertarle algun Comando de la siguientes formas:
```bash
http://<IpAtacante>:8080/administration.php?logfile=chat.txt & & id
   
http://<IpAtacante>:8080/administration.php?logfile=chat.txt || id

http://<IpAtacante>:8080/administration.php?logfile=chat.txt;id
```

- Con el *or* nos deja ejecutar comandos a nivel de sistema, nos muestra la respuesta en el *chat*, la pagina index.
- Simplemente nos mandamos una [[Reverse Shell]] , como siempre.

  -----------
# Privesc
- Escalada con [[Detección y explotación de tareas Cron]]
```bash
cat /etc/crontab
```
- La escalada es bastante sencilla, podemos ver que se ejecuta una tarea cron en 2do plano de *root*, si vemos este proceso es un *Binario.sh*.
- En este binario tenemos permisos de *escritura*. Nada del otro mundo, editamos el archivo para cambiar el permiso de la bash  a [[SUID]] y padentro!
