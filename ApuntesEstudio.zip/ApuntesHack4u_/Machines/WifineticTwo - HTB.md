---

---
---
- Tags:  #writeup #info #vulnhub #tutorial #hijacking 
----
# Reconocimiento

- [x] Puertos *Abiertos*( 22, 8080)
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**:UBUNTU FOCAL

- **Credentials**
	openplc:openplc
- **Pendientes**

- ### INFO GRAL



------
# Explotacion

### Vias Potenciales Explotacion
Dentro tenemos una especie de consola en la cual nos creamos una [[Reverse Shell]] con la pagina de toda la vida,
hay que mencionar que esta plataforma corre con lenguaje *C*

---------
# Privesc

- [x] sudo -l
- [x] history
- [ ] SUID
- [ ] crontab
- [ ] getcap
- [ ] find .txt
- [ ] find .sh
- [ ] id
- [ ] env
- [ ] /opt /tmp
- [ ] pspy, lse, linpeas,etc
- [ ] Kernel Exploits


------------
