---

---
----
- Tags:  #writeup #info #thm #tutorial #wordpress 
--------
- # Explotacion 
- Enumeramos puertos *21, 21 y 80*
-------------

- En el [[FTP - 21]] tenemos disponible el acceso con el usuario *Anonymous*, pero al acceder nos damos cuenta que no hay absolutamente NADA.

- En el [[SSH - 22]] Podemos ver una version inferior a la 7.7, por lo cual podriamos aprovechar el script *45939.py* Para poder enumerar usuarios validos.

- En el puerto *80* solomente encontramos la Pagina de inicio de apache por lo cual toca hacer *Fuzzing*
- Del lado a esto, podemos usar el *http-enum* de [[Nmap]] para intentar destacar contenido de la web

- Identificamos que la web corre por detras un [[WordPress]], por lo cual podemos usar la herramienta [[Wpscan]] para su enumeracion.

- Encontramos el [[XMLRPC]] activo, el usuairio *elyana*, y los plugins *Mail Masta y Reflex Gallery* vulnerables.
- Por el plugin de *Reflex gallery* no encontramos nada.
- Por otro lado, en el *Mail Masta* nos encontramos con una vulnerabilidad [[Local File Inclusion (LFI)]]

- Lo que hacemos es comprobar apuntando a algun archivo como el */etc/passwd* . Una vez comprabada la vuln. Podemos intentar apuntar a algun *Log* para intentar derivar nuestro [[Local File Inclusion (LFI)]] a un [[Log Poisoning (LFI -> RCE)]]. *Esta via no nos funcionó*

- Por otro lado, como sabemos que estamos ante un [[WordPress]] podemos intentar apuntar al archivo de configuracion *wp-config.php*, pero para que no se nos interprete el codigo podemos hacer uso de 
*Wrapper* de php para que el codigo nos lo muestre en *Base64* y no lo interprete la WEB, por ultimo solamente lo decodificamos en nuestro equipo local para poder leer el contenido del archivo.

```
domain/wordpress/wp-content/plugins/mail-masta/inc/campaign/count_of_send.php?pl=php://filter/convert.base64-encode/resource=../../../../../../../../../wp-config.php
```

- # Importante:
- Aqui nos enocntramos con que el contenido no se muestra en caso de que el directorio no sea el correcto, es decir que tenemos que probar retroceder de *1 en 1* los directorios con *../*
- El *Path Traversal* lo tenemos que hacer *A prueba y error* , de *1 por 1 el retroceso de directorio*

- El codigo en *Base64* lo decodificamos para poder leer el contenido del archivo de configuracion
- Nos encontramos con las credenciales para el usuario *Elyana*, dicha credencial es valida en el panel de inicio del [[WordPress]]
- Aqui simplemente nos dirigimos a la seccion del *Theme editor* y en  la seccion del *Footer.php* ponemos nuestra [[Reverse Shell]], nos ponemos en escucha, y actualizamos los cambios
-----

# Privesc
- Aqui disponemos de un archivo de Texto el cual podemos buscar con el comando *Find*, nada del otro mundo. Dicho archivo dispone de la contraseña del usuario Elyana

----

- ## Para la escalada de privilegios, hay muchas opciones, unas mas faciles que otras.

- 1era: La primera es que tenemos la */bin/bash* directamente con el permiso *SUID*
- 2da: Otra opcion es que el usuario Elyana forma parte del *Grupo lxd*, por lo cual podemos hacer uso de *monturas* y aprovechar el Exploit *46978.sh*
- 3era: La tercera opcion es la [[Detección y explotación de tareas Cron]], existe un *Script.sh* el cual el propietario es *root*, y tenemos capacidad de *Escritura*, easy.
- 4ta: La mas interesante creo es la de [[Abuso de privilegios SUID]] con [[Socat SUID]]










