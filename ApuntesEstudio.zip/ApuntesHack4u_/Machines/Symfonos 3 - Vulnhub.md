---

---
---
- Tags:  #writeup #info #vulnhub #tutorial #hijacking
----
# Reconocimiento

- [x] Puertos *Abiertos*( 21,22,80)
- [x] httpEnum,vuln&Safe
- [x] Servicios
- [x] WhatWeb
- [x] Headers
- [x] Gobsuter
- [x] Gobuster Extensiones

----------
# Enumeracion

- **OS**: Debian Stretch

- **Credentials**: hades:PTpZTfU4vxgzvRBE

- **Pendientes**: ---

- ### INFO GRAL
Directorio *cgi-bin*


------
# Explotacion

### Vias Potenciales Explotacion

Versiones Servicios, cgi-bin

la via fue cgi-bin, directorio corriendo un archivo local de la maquina

**Shellshock y pa dentro!** 

---------
# Privesc

- [x] sudo -l
- [x] history
- [x] SUID
- [x] crontab
- [x] getcap
- [x] find .txt
- [x] find .sh
- [x] id
- [x] env
- [x] /opt /tmp (ojo aqui, archivo FTP, sin capacidad lectura)
- [x] pspy, lse, linpeas,etc (proceso corriendo de ftp)
- [x] Kernel Exploits(nacha)


- La explotacion consiste en que por detras se está ejecutando algo relacionado al servicio [[FTP - 21]]. Lo que hacemos es ver que hace uso de librerias de python.
- Con ayuda de *TcpDump* nos ponemos en escucha (**de preferencia en la Loopback**) con la interfaz para intentar capturar paquetes.
```
tcpdump -i Interfaz -w captura.cap
//
tshark -r captura.cap -Y "ftp"
```
- Dentro podemos ver las credenciales del usuario *hades*
- Podemos pivotar usuario, o conectarnos por [[SSH]]

- Dentro vemos que hay un archivo que **Grupos** pueden editar, especificamente 2 librerias de python.
```
find / -group Gods -writable 2>/dev/null
```


simplemente modificamos el archivo para cambiarle el permiso a [[SUID]] a la **/bin/bash**
```
os.system("chmod u+s /bin/bash")
```

**Y pa dentro!**

------------
