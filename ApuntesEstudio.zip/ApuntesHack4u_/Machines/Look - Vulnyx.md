
--------
- Tags: #writeup #info #vulnyx #tutorial #hydra
-------------

# Explotacion

- Puertos escaneados abiertos [[SSH - 22]] y *80 HTTP*
- La version del [[SSH]] es superior a la 7.7 por lo cual no tenemos la opcion de enumeracion de usarios.
- Dicho esto no queda otra opcion mas que ir directamente a la web y Hacer *FUZZING*

- Aqui encontramos un *phpInfo* y un *look.php*
- En el *Look.php* no encontramos nada, al parecer es una especie de ejecucion de algun comando.
- Por otro lado en el *phpInfo* podemos encontrar la seccion de *Users/Group* el usuario *alex*

- Teniendo en cuenta este usuario podemos intentar un ataque de *Fueza Bruta* con [[Hydra]] :
```bash
 hydra -l axel -P /usr/share/wordlists/rockyou.txt 192.168.3.183 ssh
 //
 //login: axel   password: bambam
 ```

Con [[Hydra]] encontramos las credenciales del usuario alex, simplemente nos conectamos por [[SSH]]

--------

# Privesc

- Una vez dentro podemos ver que existe otro usuario *Dylan*, por lo cual es necesario Pivotar a este usuario antes de poder conseguir *Root*.
- No encontramos alguna via potencial *común* para escalar privilegios, aqui entra una nueva tecnica la cual consiste en ver las *Variables de Entorno* del sistema, dentro encontramos las credenciales de el usuario *Dylan*, simplemente nos movemos a este usuario

- Una vez estamos como *Dylan*, vemos si tenemos algun permiso asignado de *Sudoers*, y al parecer podemos ejecutar como el usuario *Root* el comando */usr/bin/nokogiri* sin proporcionar contraseña.
- Al ejecutar el comando, podemos ver que existe la opcion de pasarle un comando con el parametro *-e*, pero no se realiza de esa forma. Lo que tenemos que hacer es pasarle un archivo de extension *.html*
- Al hacer esto nos otorga una especie de consola de comandos en *Ruby*, podemos simplemente spawnearnos una bash, o cambiar el Permiso de la Bash a *SUID*:
- Para ejecutar algun comando con ruby usamos la Funcion *exec "comando"*
- 
```bash
exec "chmod u+s /bin/bash"
```

- Y Listo, ahora si nos spawneamos una Bash con permisos, haciendo uso del parametro *-p*, y pa dentro!






