
---
- Tags: #cisco 
----

Cisco ofrece una certificación llamada "Introducción a la Ciberseguridad", diseñada para proporcionar conocimientos y habilidades fundamentales en el campo de la ciberseguridad. Esta certificación es ideal para personas nuevas en el área que desean comprender los conceptos básicos, herramientas y técnicas utilizadas para proteger activos digitales. Cubre principios de seguridad, tipos de amenazas cibernéticas, conceptos básicos de criptografía, seguridad de redes, herramientas de ciberseguridad, y prepara a los estudiantes para roles de nivel inicial en este campo en constante evolución.


- [x] DONE!!!  
