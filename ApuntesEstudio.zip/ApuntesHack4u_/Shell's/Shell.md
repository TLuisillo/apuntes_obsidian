-------------------------------
- Tags: #scripting  #bash  #shell 
---------------------
# Definicion:

El shell o intérprete de órdenes​ o intérprete de comandos es el programa informático que provee una interfaz de usuario para acceder a los servicios del sistema operativo.

El Shell es una herramienta del sistema operativo que sirve de **mediador entre el usuario y el núcleo del sistema operativo**. Cada vez que realizas una acción sobre tu equipo, el shell está actuando sin que lo notes.

También llamado intérprete de comandos, este software **provee de forma nativa un grupo de instrucciones con parámetros específicos** que facilitan acciones sobre los distintos recursos a los que tiene acceso el sistema operativo.

Se puede utilizar **de dos formas**: comando a comando o por medio de un script que incluye un grupo de instrucciones almacenadas en un archivo de uso repetitivo, que permite alcanzar determinado objetivo de entrada, salida, procesamiento o almacenamiento.

### Su función es la de interpretar las peticiones del usuario, para que el sistema operativo pueda realizar el trabajo. La gran ventaja de usar el Shell es que requiere de muy pocos recursos para la operatividad, por lo cual favorece la velocidad de procesamiento

La desventaja es que necesitas dominar las instrucciones para realizar hasta las tareas simples, y su ambiente es poco atractivo para el usuario común. Sin embargo, es una vía eficaz para ciertas operaciones más técnicas.