
-----

---


### Zone Transfer

```bash
dig axfr domain.com @<IpVictima>

```