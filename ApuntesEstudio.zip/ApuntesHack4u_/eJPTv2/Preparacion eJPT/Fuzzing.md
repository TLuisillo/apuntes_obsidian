


### - Enumeracion de directorios con DIRB

![[Pasted image 20250621110054.png]]


**"Tener en cuenta que es busqueda recursiva"**


### - Enumeracion Subdominios

```bash
wfuzz -c -hc 404 -w /usr/share/wordlist/discovery/web-content/dire...2-3.txt

//lLa ruta se puede usar la de /usr/share/dirbuster

```


### Otras Herramientas de fuzzing
- dirsearch
- dirb
- gobuster