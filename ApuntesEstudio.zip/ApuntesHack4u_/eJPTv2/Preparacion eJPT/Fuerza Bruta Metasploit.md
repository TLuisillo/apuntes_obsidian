
---

-----


## - FTP
```bash
use auxiliary/scanner/ftp/ftp_login)
show options

// Modificar PASS_FILE, USERNAME, RHOSTS ETC
RUN
```


## - SSH
```bash
auxiliary/scanner/ssh/ssh_login  
show options

// Modificar PASS_FILE, USERNAME, RHOSTS ETC
RUN
```