
----

----

##### Configuracion manual del proxy
![[Pasted image 20250623183006.png]]