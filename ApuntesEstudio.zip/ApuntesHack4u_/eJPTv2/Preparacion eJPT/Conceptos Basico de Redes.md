
-----------

----

- **IP**, identifica a un equipo (o host) dentro de la RED

##### Clases Redes 

- CLASE A --> 255.0.0.0 --> 16.7M Hosts --> 1.0.0.0 - 126.255.255.255 --> CIDR /8
- CLASE B --> 255.255.0.0 --> 65,534 Hosts --> 128.0.0.0 - 191.255.255.255 --> CIDR /16   
- CLASE C --> 255.255.255.0 --> 254 Hosts --> 192.0.0.0 - 223.255.255.255 --> CIDR /24