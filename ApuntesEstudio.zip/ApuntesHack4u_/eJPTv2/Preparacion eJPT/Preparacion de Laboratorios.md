 
---

---
### TEMARIO
- Prepracion Labs
- Herramientas Basicas
- Explotacion de Vuln
- Fuzzing web y ataques de fuerza bruta
- Protocolos de Red
- Uso de metasploit y MsfVenom
- Explotacion protocolos SMB Windows
- Intrusion y escalada de privilegios
- Pivoting Windows/Linux

---
#### EJEMPLO DE LABORATORIO DEL EXAMEN
  ![[Pasted image 20250517034045.png]]

----

#### DIFERENCIA NAT - BRIDGE - RED INTERNA

- **Bridge**: se comporta como cualquier otro equipo conectado en la red, mismo segmento
- NAT: Varias maquinas compartiendo IP, realmente las peticiones las hace la maquina HOST, traduce la IP e la VM a la IP de la maquina anfitrion/host
- Red INTERNA/NAT: Red configurada en otro interfaz de red
  
  