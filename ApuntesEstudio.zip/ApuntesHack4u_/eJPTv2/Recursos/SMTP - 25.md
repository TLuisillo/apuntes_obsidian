
-----------
- Tags #enum  #tutorial #reconocimiento #puerto #smtp
--------------

- Verificar existencia de usuarios
```bash
smtp-user-enum -M VRFY -U <Diccionario.txt> -t <IpVictima>
```
