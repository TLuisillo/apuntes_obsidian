
---
- Tags: #ejpt #preparation
---

#### *RECOMMENDED TOOLS*

- Nmap
- Dirbuster
- Nikto
- WpScan
- CrackMapExce
- Metasploit
- Searchsploit
- Hydra

### Diagramas
- https://app.diagrams.net/ 
- draw.io

