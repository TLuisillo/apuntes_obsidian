
----
- Tags: #ejpt #enum 
---

#### Reconocer Segmento de Red

- Trabajaremos en una carpeta para mejorar el orden
```bash
mkdir ejpt
cd !$

// Reconocer segmento de red
ip a
// Dependiendo el rango o segmento de red
nmap -sn 10.10.2.0/24
```

- Dadas las IP que quen podemos alcanzar reealizaremos un Diagrama con [Draw.io] para poder entender mejor la red, ejemplo

 ![[Pasted image 20250224220949.png]]

----
### Nmap Scan

```bash
// Descubrir puertos abiertos para todas las maquinas
sudo nmap -p- -sS --min-rate 5000 172.22.200.1,2,3,4,5 -Pn -oN tcp_scan.txt

// REGEX para tomar solo puertos especificos que queremos auditar
grep '^[0-9]' tcp_scan.txt | cut -d '/t' -f1 | sort -u | xargs | tr ' ' ','

// Ver servicios y versiones de puertos abiertos de las maquinas
nmap -p[listado de puertos] --open -sCV 172.22.200.1,2,3,4,5 -Pn -oN targeted.txt
```

```bash
//Escaneo UDP (si te cuesta encontrar algo, puede ser protocolo SNMP)
nmap -sU --top-ports 200 --min-rate 5000 192.168.3.79 -Pn 

//Escaneo VULNS
nmap --script "vuln" -p445 192.168.0.X
``` 