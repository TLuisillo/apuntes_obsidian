
---
- Tags: #ejpt #enum 
---

- Para la certificacion se usa **Dirbuster** para realizar la parte de **Fuzzing**

```bash
nohup dirbuster &>/dev/null & disown; 
```

![[Pasted image 20250224223655.png]]

- ###### Bastante intuitivo, Echale coco