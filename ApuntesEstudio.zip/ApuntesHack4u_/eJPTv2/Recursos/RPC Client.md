
-----------
- Tags #enum  #tutorial #reconocimiento #puerto #smb 
--------------

### Parecido a *SMB_Client*, para auditar el puerto [[SMB - 445]]

- Conectarnos con usuario invitado, *Guest*
```bash
rpcclient -U "" <IpVictima>
```

- Comandos a probar
```bash
help

srvinfo

enumdomgroups
enumdomusers

querydominfo

netshareenumall

```

- Otra que podriamos usar para hacer todo automatico es *enum4linux*
```bash
enum4linux <IpVictima> -A
```

- Para Ejecutar algun comando usamos el parametro *-c 'Comando'*
