-----------
- Tags: #windows #meterpreter #tutorial  #comands #tutorial #postExplotation 
--------------
### Windows

- Comandos utiles a utilziar
```cmd
//user actual
whoami

//privilegios
whoami /priv

//informacion del sistema, parches instalAdos
systeminfo

//lista de usuarios que han iniciado sesión en la máquina
query user

//informacion detallada del user
net user administrator

//vet grupos al que peretenece un usuario
net localgroup
net localgroup administrators 

//Nombre del equipo
hostname

```

- *Pivoting*
```Cmd
//interfaces de red
ipconfig

```







- Ver *Usuarios disponibles*, (*Guest* tambien cuenta como usuario)
```
shell

net users
```


----------

### Meterpreter

- *METERPRETER* Session
```METERPRETER
//info del sistema pa
sysinfo

//info user actual
getuid


//privilegios user actual
getprivs

//ps la auida pa
help

hashdump
// En caso que no nos deje hacer lo sig:

pgrep lsass
migrate 464

//Ahora si Hashdump

//escaneo ARP
run arp_scanner -r <IpSubred> (Formato: X.X.X.0/24)

```

-------------

- # Pivoting
- De aqui ahora si [[Pivoting eJPT]]
