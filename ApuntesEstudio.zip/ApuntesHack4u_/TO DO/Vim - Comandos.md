
-------
- Tags: #tools #software #tutorial #comands #info #terminal #shell 
---------
### Vim = Vi Improved
# Uso

#### Alias de vim=nvim
```bash
alias vim=nvim
//
echo 'alias vim=nvim' >> ~/.zshrc

```
------
## : Comando Interno Vim
## :! Comando en Terminal

---------
### Modos
- *Esc* = Modo *Normal*

- *i* = Modo *Insertar*
- *v* = Modo *Visual*
- *a, e, i* Diferentes modos de *Insert*
* *shift  I* = Insertar pero desde el inicio de la linea actual
* *shift A* = Insertar desde el final de la linea
- *shift O* = Insertar, una linea abajo de la actual (desplazar)
----------
# Comandos basicos
------
- *:set number* = ver numeros de linea
-  *:set relativenumber* = ver numeros de linea *RELATIVO*
- Los numeros se puden combinar por ejemplo mover 10 lineas abajo 
```bash
10 + Flecha abajo
```

-----
### Movildiad
- *K* = Up
- *J* = Down
- *H* = Left
- *L* = Rigth
-------
- **u** = Undo
- **Ctrl + R** = Redo
----
*r* = Replace 
--- -

### Visual mode
- *Double for Full Line*
*D* = Delete
*Y* = Copy

- *Capital For rest of the line*
*CC* = Delete and change (Go to insert mode)

*ci* = Borrar lo que esté dentro de ... *caractér*

---

### Borrrar Palabra actual:

Aquí tienes una breve explicación de este comando: *diw*

1. Coloca el cursor sobre la palabra que deseas borrar.
2. Presiona d para activar el modo de eliminación (delete).
3. Presiona  iw para indicar que quieres borrar la palabra actual.

-------

