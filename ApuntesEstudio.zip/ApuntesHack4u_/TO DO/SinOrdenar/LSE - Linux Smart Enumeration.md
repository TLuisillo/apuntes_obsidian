---------------
- Tags: #tools #github #privesc 
--------------

# Definicion

Es una herramienta de enumeración para sistemas Linux que permite a los atacantes obtener información detallada sobre la configuración del sistema, los servicios en ejecución y los permisos de archivo. LSE utiliza una variedad de comandos de Linux para recopilar información y presentarla en un formato fácil de entender. Al utilizar LSE, los atacantes pueden detectar posibles vulnerabilidades y encontrar información valiosa para futuros ataques.


Una vez insertado el archivo en la maquina victima:
```bash
./lse.sh
```

- Link to Github Repo [here](https://github.com/diego-treitos/linux-smart-enumeration)

