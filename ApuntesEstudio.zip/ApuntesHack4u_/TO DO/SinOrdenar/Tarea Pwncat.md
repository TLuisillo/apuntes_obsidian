--------
- Tags: #github #tools #privesc #shell  #terminal 
------------

# Para ahorrarnos tratamiento de TTY

(al entrar hay que hacer un *back* y un *export TERM=xterm*)