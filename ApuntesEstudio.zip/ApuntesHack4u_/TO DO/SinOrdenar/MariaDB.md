---------
- Tags: #sql #sqli #basesdatos 
------------------

## Instalacion:

```bash
// instalacion
apt install mariadb-server

//iniciar servicio 
service mysql start

//comprobar servicio activo
lsof -i:3306
```

## Comandos Basicos:

- Ver Bases de Datos
```sql
show databases;
```

- Usar una BD:
```sql
use nombreBD;
```

- Ver tablas disponibles
```sql
show tables;
```

- Ver columnas de una tabla
```sql
describe nombreCol;
```

- Select Basico Ejemplo: (usr  y pass de la table user donde usuario sea = root)
```sql
select user,password from user where user = 'root';
```

- Crear tabla:
```sql
create table users(id int(32), username varchar(32), password varchar(32));
```

- Insertar Datos a una tabla:
```sql
insert into users(id, username, password) values(1, 'admin', 'admin123$!p@$$');
```

- Actualizar Campo de una tabla:
```sql
update users set username='luisillo' where password = 'luisillo123';
```

- Crear Usuario especial para conectar con el php: 
```sql
create user 'luisillo'@'localhost' identified by 'luis123';
```

- Darle privilegios al usuario:
```sql
grant all privileges on nameDD.* to 'luisillo'@'localhost';
```
