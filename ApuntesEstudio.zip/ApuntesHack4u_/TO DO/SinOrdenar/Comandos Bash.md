----------------------------------
- Tags: #shell #bash #scripting #shell #tutorial #comands #terminal #oneliner #info 
----------------

- Convertir cadena a MD5
```Bash
echo -n "admin" | md5sum
```
Es importante el paramentro **-n** ya que de lo contrario, al no ponerlo tomaria como caracter el salto de linea por defecto y el hash no seria el correcto 