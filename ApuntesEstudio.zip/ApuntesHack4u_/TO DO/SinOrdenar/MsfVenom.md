------------
- Tags: #scripting  #payload  #shellcode #reversing #tools #msfv
-----------

# Definicon

Esta herramienta que pertenece al framework de Metasploit, no dispone de una larga vida... allá por 2011 es cuando explota y muestra su potencial y flexibilidad.

**Realmente msfvenom es la unión de msfpayload y msfencode.** Como recordatorio decir que msfpayload se encarga de generar payloads para distintas plataformas, mientras que msfencode se encarga de codificar dichos payloads con el objetivo de evadir la detección mediante el uso de antivirus.

**Beneficios de msfvenom** Los beneficios de msfvenom se enumeran a continuación:

- Se simplifica la generación de payloads y los intentos de codificación de éstos.
- Se presenta como una herramienta estándar que ayuda a los auditores y a cualquier usuario su manejo. Es realmente intuitiva y con fácil aprendizaje.
- El rendimiento ha sido mejorado considerablemente. La velocidad con la que msfvenom trabaja es claramente más alta que el uso de msfpayload y msfencode por separado. Esto es bastante lógico debido a que se evita el paso de información entre distintos procesos, y toda acción es realizada por el mismo proceso.

**Opciones de msfvenom** Algunas de las opciones más útiles de msfvenom se enumeran a continuación:

- Payload. Este parámetro especifica el payload que se utilizará.
- Encoder. Este parámetro especifica el algoritmo que se utilizará para realizar la codificación.
- Format. Especifica el formato, normalmente EXE 
- Bad-chars. Este parámetro indica un listado de bytes que no se deben generar en el proceso de obtención del payload. Por ejemplo, si se quieren evitar los bytes nulos '\x00' se añaden en la lista de este parámetro.
- Iterations. Indica el número de iteraciones que se ejecutará el algoritmo del encoder.
- Template. Indica la plantilla de ejecutable que se utilizará.
- Keep. Especifica que el payload se ejecutará en un thread y no en el main del ejecutable. Con esta opción se implementa la técnica de plantilla personalizada sigilosa.