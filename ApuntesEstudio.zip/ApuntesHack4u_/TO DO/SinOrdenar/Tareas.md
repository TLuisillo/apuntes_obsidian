---------------------------------------
- Tags: #info #indice
-----------------------


- Gestores de contenido Pendientes por definir:

- [x] WordPress
- [x] Joomla
- [x] Drupal
- [x] Magento

-----------------------------------------


# INVESTIGAR MAS A FONDO:
- [ ] Google Dorks
- [ ] Reforzar Bash scripting | Awk | REGEX
- [ ] SqlMap
- [ ] Msf





------------------

 



 


