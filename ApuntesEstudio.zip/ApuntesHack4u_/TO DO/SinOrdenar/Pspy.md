----------------------
- Tags: #tools #github #privesc
----------------------

Es una herramienta de enumeración de procesos que permite a los atacantes observar los procesos y comandos que se ejecutan en el sistema objetivo a intervalos regulares de tiempo. Pspy es una herramienta útil para la detección de malware y backdoors, así como para la identificación de procesos maliciosos que se ejecutan en segundo plano sin la interacción del usuario.


Una vez transferido el archivo a la maquina victima:

```bash
./pspy64
```


- Link to Github Repo [here](https://github.com/DominicBreuker/pspy/releases)

