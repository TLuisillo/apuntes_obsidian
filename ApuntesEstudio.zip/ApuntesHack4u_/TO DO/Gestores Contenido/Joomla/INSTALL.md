
---
- Tags: #info #tutorial 
-----

- [LINK](https://www.linuxhelp.com/how-to-install-joomla-cms-on-ubuntu-22-04)

## ESTO VA EN EL **/etc/apache2/sites-available/joomla.conf**

```
cat /etc/apache2/sites-available/joomla.conf 
<VirtualHost *:80>

ServerAdmin webmaster@linuxhelp.xyz

ServerName Linuxhelp.xyz 
ServerAlias www.linuxhelp.xyz 
DocumentRoot /var/www/html/joomla

<Directory /var/www/html/joomla/> 
	Options FollowSymlinks
        AllowOverride All
	Require all granted
</Directory>

ErrorLog ${APACHE_LOG_DIR}/linuxhelp.xyz_error.log.
CustomLog ${APACHE_LOG_DIR}/linuxhelp.xyz_access.log combined

</VirtualHost>
root@aa30daf44f3b:/# 
```