------------------ 
- Tags: #web #tools #wordpress #reconocimiento #github 
- -------------

La herramienta *Wpscan* [^1] es comunmente utilizada para enumerar una web, que disponga de gestor de contenidos [[WordPress]]

Su modo de uso es muy sencillo, podriamos realizar un escaneo a modo de prueba ejecutando el siguiente comando en *Bash*:

```bash
wpsacan --url https://domain.com 
``` 


Si quisieramos enumerar usuarios validos poteniciales existentes detras de este gestor de contenidos, podriamos ejecutar el siguiente escaneo alternativo:

```bash
wpscan --url https://domain.com --enumerat u
```

Otra de las utilidades de esta herramienta es que es capaz de aplicar fuerza bruta para descubrir credenciales validas en los paneles de autenticacion:
```bash
wpscan --url https://domain.com -U luisillo -P /usr/share/wordlist/rockyou.txt
```
Hay que tener en cuenta que este procedimiento, tambien puede aplicarse de forma manual [^2], abusando del archivo **xmlrpc.php** siendo necesario crear para ello un script en *Python* o *Bash*

-----------------------------

- ## Enumeracion plugins vulnerables:
```bash
wpscan --url http://192.168.3.160/blog/ --enumerate u,vp --plugins-detection aggressive --api-token='JCC8LTpALyVB9OA0wb3HyrnKdCXSZ9CaysMsZ7sxYHI'
```


---------------------------
- ## BruteForce Passwords
```bash
 wpscan --url http://192.168.3.163/wp/ --passwords /usr/share/wordlists/rockyou.txt --api-token='JCC8LTpALyVB9OA0wb3HyrnKdCXSZ9CaysMsZ7sxYHI'
```

----------------

## Referencias
[^1]:  Enlace al proyecto en GitHub: [Respositorio](https://github.com/wpscanteam/wpscan) 
 [^2]  Procedimiento manual abusando del [[XMLRPC]]

