  --------------
- Tags: #owasp 
-------------------------------

# Definicion

El modo de operación de cifrado por bloques CBC (cipher-block chaining) **es un sistema en el que se realiza una operación XOR entre el bloque de texto plano y el bloque de texto cifrado anterior**

### Tabla Verdad (XOR)
0 0 --> 0
1 0 --> 1
0 1 --> 1
1 1 --> 0 

- Ejemplo : 
valor 2 : *0 0 1 0*
valor 5 : *0 1 0 1*
- **Aplicando un XOR** : 
#### Resultado: 0 1 1 1 = 7
