-----------
- Tags: #owasp #web
-------------------
# Definicion

La vulnerabilidad de redirección abierta, también conocida como **Open Redirect**, es una vulnerabilidad común en aplicaciones web que puede ser explotada por los atacantes para dirigir a los usuarios a sitios web maliciosos. Esta vulnerabilidad se produce cuando una aplicación web permite a los atacantes manipular la URL de una página de redireccionamiento para redirigir al usuario a un sitio web malicioso.

Por ejemplo, supongamos que una aplicación web utiliza un parámetro de redireccionamiento en una URL para dirigir al usuario a una página externa después de que se haya autenticado. Si esta URL no valida adecuadamente el parámetro de redireccionamiento y permite a los atacantes modificarlo, los atacantes pueden dirigir al usuario a un sitio web malicioso, en lugar del sitio web legítimo.

Un ejemplo de cómo los atacantes pueden explotar la vulnerabilidad de redirección abierta es mediante la creación de correos electrónicos de **phishing** que parecen legítimos, pero que en realidad contienen enlaces manipulados que redirigen a los usuarios a un sitio web malicioso. Los atacantes pueden utilizar técnicas de **ingeniería social** para convencer al usuario de que haga clic en el enlace, como ofrecer una oferta atractiva o una oportunidad única.

Para prevenir la vulnerabilidad de redirección abierta, es importante que los desarrolladores implementen medidas de seguridad adecuadas en su código, como la validación de las URL de redireccionamiento y la limitación de las opciones de redireccionamiento a sitios web legítimos. Los desarrolladores también pueden utilizar técnicas de codificación segura para evitar la manipulación de URL, como la codificación de caracteres especiales y la eliminación de caracteres no válidos.

------------------------------------

 - **Ejemplo 1 Uso:**
```url
http://localhost:5000/redirect?newurl=https://google.es
```

### En este ejemplo se redirige a una pagina a nuestra eleccion

----------------------

-----------------------------
 - **Ejemplo 2 Uso:**
```url
http://localhost:5000/redirect?newurl=https://google%252ees
```

### En este ejemplo el navegador no nos deja hacer uso del *.* por lo cual se Url Encodea

-------------------------

-------------------------

 - **Ejemplo 3 Uso:**
```url
http://localhost:5000/redirect?newurl=https:google%252ees
```

### En este ejemplo el navegador no nos deja hacer uso del *.* por lo cual se Url Encodea, pero tambien no nos deja usar */ /* por lo cual **unicamente** cuando el domino sea **https** se pueden omitir y nos redirige a la web de forma normal

--------------------------


