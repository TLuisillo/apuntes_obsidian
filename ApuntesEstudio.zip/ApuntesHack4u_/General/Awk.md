---

---
done

----
- Tags:  #bash #scripting #shell #tools #terminal #tutorial #comands 
-----
# Definicion
En términos generales el comando awk permite procesar y modificar el texto según nuestras necesidades.

Los usos básicos que podemos dar al comando Awk son los siguientes:
- 1. Buscar palabras y patrones de palabras y reemplazarlos por otras palabras y/o patrones.
- 2. Hacer operaciones matemáticas.
- 3. Procesar texto y mostrar las líneas y columnas que cumplen con determinadas condiciones.

----------------
# Uso

- Ejemplo basico tomar primer *Columna* del output.
```bash
ps | awk '{print $1}'
```

- Ejemplo tomar *ultima* Columna del output
```bash
ps | awk '{print $NF}'
```

- Delimitar por otro *Caracter* 
```bash
ps | awk -F ":" '{print $2 "\t" $3 "\n" $4}' 
```

- *Condiciones* en awk: Puedes usar condiciones en `awk` para filtrar líneas específicas. Por ejemplo, para imprimir solo las líneas donde la segunda columna es *mayor* que 10:
```bash
ps | awk '$2 > 10 {print $1}'
```

- **Expresiones regulares**: Puedes utilizar expresiones regulares para buscar y manipular texto. Por ejemplo, para encontrar líneas que contengan la palabra "kernel":
```bash
ps | awk '/kernel/ {print $1}'
```