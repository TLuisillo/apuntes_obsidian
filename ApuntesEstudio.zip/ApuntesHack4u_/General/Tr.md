---

---
-----
- Tags:  #bash #scripting #shell #tools #terminal #tutorial #comands 
-----
# Definicion
*tr* no es más que una abreviación de *translate*. Esto ya nos puede dar la pista que las principales utilidades de *tr* son las siguientes:
- 1. Cambiar caracteres, palabras y frases de mayúscula a minúscula o viceversa.
- 2. Buscar palabras y reemplazarlas por otras.
- 3. Borrar caracteres, palabras o frases.
- 4. Eliminar caracteres repetidos de forma innecesaria.
- 5. Cambiar letras o palabras de mayúscula a minúscula.
- 6. Eliminar la totalidad de caracteres que son ilegibles de un texto.
- 7. Añadir una nueva línea cada vez que encontremos un delimitador que podemos definir.
- 8. Eliminar la totalidad de caracteres de puntuación de una frase.

 *Tr* solo puede operar y transformar texto desde la entrada estándar hasta la salida estándar. Por lo tanto no podremos actuar de forma directa sobre un fichero de texto.

---
# Uso 

- Reemplazar texto en un archivo y guardar el resultado en el mismo archivo:
```bash
tr 'A-Z' 'a-z' < archivo.txt
```

- Cambiar minúsculas a mayúsculas:
```bash
tr 'a-z' 'A-Z' < archivo.txt
```

- Eliminar caracteres específicos:
```bash
tr -d 'caracteres_a_eliminar' < archivo.txt
```

- Eliminar caracteres no alfabéticos:
```bash
tr -cd '[:alnum:]' < archivo.txt
//others
'[:lower:]'
'[:upper:]'
'[:alpha:]'
```

- Reemplazar un conjunto de caracteres con otro conjunto:
```bash
tr 'abc' 'xyz' < archivo.txt
```

- Eliminar espacios en blanco:
```bash
tr -d ' ' < archivo.txt
```

- Eliminar saltos de línea y espacios en blanco:
```bash
tr -d '\n\t ' < archivo.txt
```

- Eliminar duplicados de caracteres consecutivos:
```bash
tr -s 'a-z' < archivo.txt
```

- Reemplazar una secuencia de caracteres con uno solo:
```bash
tr -s '\n' ' ' < archivo.txt
```