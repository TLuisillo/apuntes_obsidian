---------
- Tags: #info #tutorial #bash #scripting #comands 
----------

- Paleta de Colores
```bash
#Colours
greenColour="\e[0;32m\033[1m"
endColour="\033[0m\e[0m"
redColour="\e[0;31m\033[1m"
blueColour="\e[0;34m\033[1m"
yellowColour="\e[0;33m\033[1m"
purpleColour="\e[0;35m\033[1m"
turquoiseColour="\e[0;36m\033[1m"
grayColour="\e[0;37m\033[1m"
```

- Funcion Ctrl + C
```bash
function ctrl_c(){
	echo -e "\n\n${redColour}[!] Saliendo...${endColour}\n"
	exit 1
}
#CTRL C
trap ctrl_c SIGINT
```

- Panel de Ayuda
```bash
function helpPanel(){
	echo -e "\n${redColour}[!]Uso: $0${endColour}"
	exit 1
}
```

- Pasar Argumentos
```bash
# Parameter Counter
declare -i parameter_counter=0

while getopts "u:w:h" arg; do
	case $arg in
		u) username=$OPTARG && let parameter_counter+=1;;
		w) wordlist=$OPTARG && let parameter_counter+=1;;
		h) helpPanel
	esac
done	
```

- Condicional *IF*
```bash
if [  ]; then

else

fi
```

