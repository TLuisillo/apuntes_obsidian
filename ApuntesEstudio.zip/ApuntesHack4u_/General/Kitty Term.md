
---

-----


#### kitty.conf:

```
# temas
include GruvBox_DarkHard.conf
#include Wryan.conf
#include VSCode_Dark.conf

# opacidad y desenfoque de fondo
background_opacity 0.5
background_blur 1

# avanzado
term xterm-kitty

# timbre de terminal
enable_audio_bell no

# ajustes específicos del sistema operativo (decoración de ventana Gnome para Wayland)
#linux_display_server wslg

# fuente
font_family        SauceCodePro Nerd Font
bold_font          auto
italic_font        auto
bold_italic_font   auto
font_size 12.0

# gestión del tamaño de fuente
map ctrl+shift+backspace change_font_size all 0

# personalización del cursor
# bloque / rayo / subrayado
cursor_shape beam
cursor_blink_interval 0.7
cursor_stop_blinking_after 0
shell_integration no-cursor

# desplazamiento hacia atrás
scrollback_lines 5000
wheel_scroll_multiplier 3.0

# ratón
mouse_hide_wait -1

# diseño de ventana
remember_window_size  no
initial_window_width  1200
initial_window_height 750
window_border_width 1.5pt
enabled_layouts tall
window_padding_width 0
window_margin_width 2
hide_window_decorations no

# gestión de ventanas
map ctrl+shift+enter new_window
map ctrl+shift+] next_window
map ctrl+shift+[ previous_window

# gestión de diseño
map ctrl+shift+l next_layout
map ctrl+alt+r goto_layout tall
map ctrl+alt+s goto_layout stack

# personalización de la barra de pestañas
tab_bar_style powerline
tab_powerline_style slanted
tab_bar_edge bottom
tab_bar_align left
active_tab_font_style   bold
inactive_tab_font_style normal

# gestión de pestañas
map ctrl+shift+t new_tab
map ctrl+shift+right next_tab
map ctrl+shift+left previous_tab
map ctrl+shift+q close_tab

# Colores de selección
selection_foreground     #f8f8f2
selection_background     #323633

# Colores del borde de la ventana
active_border_color      #300991
inactive_border_color    #44475a

# Colores de las pestañas de Kitty
active_tab_foreground    #f1f1f1
active_tab_background    #300991
inactive_tab_foreground  #f1f1f1
inactive_tab_background  #44475a

# Color básico
background               #0c0c0c
foreground               #f1f1f1

# Color
color0  #e80000
color1  #9c1503
color2  #e1ebe2
color3  #bf0f0f
color4  #4c529c
color5  #d1de40
color6  #a30b0b
color7  #d1de40
color8  #178f8f
color9  #d1de40
color10 #d1de40
color11 #d1de40
color12 #d1de40
color13 #d1de40
color14 #d1de40
color15 #d1de40


# Color de URL
url_color                #c41f35  

cursor                   #a3a4a8  
cursor_text_color        #0c0c0c 

map ctrl+left neighboring_window left
map ctrl+right neighboring_window right
map ctrl+up neighboring_window up
map ctrl+down neighboring_window down
```



- Posible error de display
```
 export DISPLAY=:0
  125  history
  126  sudo apt-get install fontconfig
  127  sudo apt-get install libwayland-client0 libwayland-server0 libwayland-cursor0 libwayland-egl1
  128  sudo apt-get install fonts-dejavu fonts-inconsolata
  129  unset WAYLAND_DISPLAY
```