
-----
- Tags: #shell #github  #tutorial #comands #terminal #oneliner #info
---

1. `git init`:
   - Descripción: Inicializa un nuevo repositorio Git en un directorio vacío.
   - Uso: `git init [nombre_del_directorio]`

2. `git clone`:
   - Descripción: Clona un repositorio Git existente en tu sistema.
   - Uso: `git clone [URL_del_repositorio]`

3. `git add`:
   - Descripción: Agrega cambios en el directorio de trabajo al área de preparación (staging) para la confirmación.
   - Uso: `git add [nombre_del_archivo_o_directorio]`

4. `git commit`:
   - Descripción: Crea un nuevo commit con los cambios en el área de preparación y agrega un mensaje descriptivo.
   - Uso: `git commit -m "Mensaje descriptivo"`

5. `git status`:
   - Descripción: Muestra el estado actual del directorio de trabajo y el área de preparación.
   - Uso: `git status`

6. `git log`:
   - Descripción: Muestra un registro de commits en la rama actual.
   - Uso: `git log`

7. `git branch`:
   - Descripción: Lista todas las ramas en el repositorio y muestra la rama actual con un asterisco.
   - Uso: `git branch`

8. `git checkout`:
   - Descripción: Cambia entre ramas o commits.
   - Uso: `git checkout [nombre_de_la_rama_o_commit]`
   - -b para crear branch

9. `git merge`:
   - Descripción: Fusiona cambios de una rama en otra.
   - Uso: `git merge [nombre_de_la_rama]`

10. `git pull`:
    - Descripción: Descarga cambios desde un repositorio remoto y los fusiona en la rama actual.
    - Uso: `git pull [nombre_del_remoto] [nombre_de_la_rama_remota]`

11. `git push`:
    - Descripción: Sube cambios locales a un repositorio remoto.
    - Uso: `git push [nombre_del_remoto] [nombre_de_la_rama_local]`

12. `git remote`:
    - Descripción: Muestra una lista de repositorios remotos conectados.
    - Uso: `git remote -v`

13. `git fetch`:
    - Descripción: Descarga cambios desde un repositorio remoto sin fusionarlos.
    - Uso: `git fetch [nombre_del_remoto]`

14. `git diff`:
    - Descripción: Muestra las diferencias entre los cambios en el directorio de trabajo y la última confirmación.
    - Uso: `git diff`

15. `git reset`:
    - Descripción: Restablece el estado del repositorio a un commit específico.
    - Uso: `git reset [nombre_del_commit]`
