---

---
-----
- Tags:  #bash #scripting #shell #tools #terminal #tutorial #comands 
----------------
# Definicion
Sed es una herramienta de terminal cuyo uso principal es **buscar y reemplazar un texto**. En otras palabras más precisas permite buscar cadenas de texto, palabras o patrones de palabras y reemplazarlos por el texto que queramos. Aparte de lo que acabo de mencionar también permite insertar y eliminar texto de un documento.Sed es una herramienta de terminal cuyo uso principal es **buscar y reemplazar un texto**. En otras palabras más precisas permite buscar cadenas de texto, palabras o patrones de palabras y reemplazarlos por el texto que queramos. Aparte de lo que acabo de mencionar también permite insertar y eliminar texto de un documento.

-----
# Uso 

- Uso Basico de sed:
```bash
sed 's/find/replace/g' /home/archivo.txt
```

- Reemplazar texto en un archivo y guardar el resultado en el mismo archivo:
```bash
sed -i 's/antiguo_texto/nuevo_texto/g' archivo.txt
```

- Eliminar *líneas* que coincidan con un patrón:
```bash
sed '/patron_a_eliminar/d' archivo.txt
```

- Eliminar *líneas* en blanco:
```bash
sed '/^$/d' archivo.txt
```

