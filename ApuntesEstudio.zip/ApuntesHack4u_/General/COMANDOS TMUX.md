---------------------
- Tags: #tmux #bash #scripting #shell #tools #terminal 
-------------------

# INSTALACION
```bash
apt install tmux -y

# Oh My TMUX Install:
cd
git clone https://github.com/gpakosz/.tmux.git
ln -s -f .tmux/.tmux.conf
cp .tmux/.tmux.conf.local .
```

## ( Recomendable instalarlo en todos los usuarios disponibles, en su carpeta /home )


# Comandos Navegacion
```bash
# Abrir Nueva Sesion Tmux
tmux new -s "session_Name" 

#  ---------- ( Prefix = CTRL + B) ----------

# Reonombrar Ventana
Prefix - > ,

# Renombrar Sesion
tmux rename-session -t old-session-name new-session-name

# Nueva Term Horizontal
Prefix -> " "

# Nueva Term Vertizal
Prefix -> %

# Term en Pantalla Completa (Zoom)
Prefix -> z

# Cerrar ultima Term
Prefix -> x -> y/n

# Rotar Terms
Prefix -> { }

# Rotar en Sentido del reloj
Prefix -> o

# Rotar Terms / Organizar Terms ALEATORIO 
Prefix -> space

# Moverse entre Terms
Prefix -> (Flechas)

# Ver Reloj en Term
Prefix -> t

# Nueva Ventana 
Prefix -> c

# Moverse a Otra Ventana
Prefix -> 1,2,3,4,5, etc

# Moverse entre Ventanas con Mouse
Prefix -> m

# Llevarse una Terminal a una nueva Ventana (situados en la ventana)
Prefix -> !

# Unir Ventanas (de izq a der solamente) ---- (Es decir no podemos unir 3 con 1, mas bien 1 con 3 )
Prefix -> : -> join-pane -s 1 -t 3

# Cambiar ORDEN de VENTANAS (igual que el anterior)
Prefix -> : -> swap-window -s 2 -t 1

# Ver Numero indicativo de Cada Panel( Cada Terminal )
Prefix -> q

# Modo Copiar
Prefix -> [

# Modo Seleccion
Prefif -> space

# Cerrar sesion Tmux o dejarla en 2do Plano
Prefix -> d

# Listar sesiones Tmux
tmux list-sessions

# Abrir sesion existente Tmux
tmux attach -t 'SessionName'

# Modo Busqueda
Prefix ->  [  -> s

# Busqueda Comandos Recientes (Busqueda Reversa)
Ctrl + r

# Cambiar a otra sesion (DENTRO DE UNA SESION)
Prefix -> s  (otra opcion es ' w ' )

# Matar una sesion desde fuera
tmux kill-session -t 'SessionName'



```

-----------------------------------
# Editar Colores TMUX
```bash
micro /root/.tmux.conf.local
tmux source ~/.tmux.conf

//Lo mismo para todos los usuarios
```

------------------------------------------

- ### Oh My TMUX: [Github Link](https://github.com/gpakosz/.tmux)
