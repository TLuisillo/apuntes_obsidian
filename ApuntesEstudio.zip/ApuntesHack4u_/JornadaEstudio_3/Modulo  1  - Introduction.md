
----
- Tags: #cybrary  #aws 
-----

### Respuesta Incidenetes

La respuesta a incidentes (o IR, por sus siglas en inglés "*Incident Response*" es un proceso organizado para abordar y gestionar las consecuencias de una brecha de seguridad o un ciberataque. El objetivo principal de la respuesta a incidentes es manejar la situación de manera que se minimicen los daños y se reduzca el tiempo de recuperación y costos asociados.

## Typical IR Steps
- Notify Responders
- Confirm Thath something happend
- Inform Stakeholders
- Perform resolution processes
- Validate that the incident has been resolved
- Perform clean-up / post incident tasks

-------------

 