
------
- Tags: #cybrary #aws
----

La certificación AWS Certified Security - Specialty (SCS-C02) es una credencial avanzada diseñada para profesionales de seguridad que desean demostrar su experiencia en la seguridad de AWS. La plataforma Cybrary ofrece cursos y recursos que pueden ayudarte a prepararte para esta certificación. Aquí tienes algunos detalles sobre la certificación y lo que Cybrary puede ofrecer:

### Detalles de la Certificación AWS Certified Security - Specialty (SCS-C02)

1. **Requisitos Previos**:
    
    - Conocimiento profundo de al menos una de las áreas de seguridad de AWS.
    - Experiencia práctica en seguridad de AWS.
    - Recomendado tener una certificación AWS Associate o experiencia equivalente.
2. **Áreas de Conocimiento Clave**:
    
    - Gestión de identidad y acceso (IAM).
    - Detección.
    - Protección de infraestructura.
    - Protección de datos.
    - Respuesta a incidentes.