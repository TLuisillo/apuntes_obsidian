
---
- Tags: #nist #info 
----

**National Institute of Standards and Technology**

#### NIST FRAMEWORK *(CSF)*
El NIST Cybersecurity Framework (CSF) es un conjunto de directrices voluntarias desarrolladas para ayudar a las organizaciones a gestionar y reducir los riesgos de ciberseguridad.


## Componentes del NIST CSF

1 - **Funciones (Functions):** Categorías amplias que representan los principales pilares de la ciberseguridad. Incluyen:
- **Identificar (Identify):** Desarrollar una comprensión organizacional para gestionar el riesgo de ciberseguridad.
- **Proteger (Protect):** Implementar medidas de salvaguardia para asegurar la entrega de servicios críticos.
- **Detectar (Detect):** Desarrollar y aplicar actividades para identificar la ocurrencia de eventos de ciberseguridad.
- **Responder (Respond):** Tomar medidas para contener el impacto de un incidente de ciberseguridad.
- **Recuperar (Recover):** Implementar planes para la resiliencia y restaurar cualquier capacidad o servicio que se haya visto afectado.

### Importancia y Aplicación:
- **Cumplimiento y Regulación:** Muchas industrias y agencias gubernamentales requieren adherencia a estas guías para cumplir con regulaciones y leyes de seguridad.
- **Base para Certificaciones:** Proporcionan la base para varias certificaciones de ciberseguridad y sirven como referencia en auditorías y evaluaciones de seguridad.
- **Desarrollo de Políticas:** Ayudan a las organizaciones a desarrollar políticas y procedimientos sólidos de ciberseguridad.