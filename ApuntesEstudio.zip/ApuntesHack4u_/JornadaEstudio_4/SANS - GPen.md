
----
- Tags:  #info 
----

La certificación GIAC Penetration Tester (GPEN) es una credencial ofrecida por Global Information Assurance Certification (GIAC) que valida las habilidades y conocimientos necesarios para realizar pruebas de penetración de manera eficaz. Esta certificación se enfoca en las técnicas, herramientas y metodologías utilizadas en la realización de pruebas de penetración para identificar y explotar vulnerabilidades en sistemas y redes.

#### Objetivos de la Certificación GPEN

- **Validar Competencias:** Asegurar que los profesionales poseen las habilidades necesarias para realizar pruebas de penetración.
- **Mejorar la Seguridad:** Ayudar a las organizaciones a mejorar su postura de seguridad mediante la identificación proactiva de vulnerabilidades.
- **Reconocimiento Profesional:** Proveer una credencial reconocida que valide la experiencia y conocimientos en pruebas de penetración.

#### Temas Clave y Contenido del Examen

La certificación GPEN cubre una amplia gama de temas relacionados con las pruebas de penetración. Algunos de los temas clave incluyen:

1. **Metodologías de Pruebas de Penetración:**
    
    - **Planificación y Alcance:** Cómo definir el alcance y los objetivos de una prueba de penetración.
    - **Metodologías Estandarizadas:** Conocimiento de metodologías reconocidas, como OWASP, NIST, y OSSTMM.
2. **Recopilación de Información:**
    
    - **Reconocimiento Activo y Pasivo:** Técnicas para recolectar información sobre los objetivos sin alertar a los defensores.
    - **Herramientas de Reconocimiento:** Uso de herramientas como Nmap, Whois, y Shodan.
3. **Escaneo y Enumeración:**
    
    - **Identificación de Servicios y Puertos:** Uso de herramientas para escanear y enumerar servicios y puertos abiertos.
    - **Enumeración de Usuarios y Recursos Compartidos:** Técnicas para identificar usuarios y recursos compartidos en la red.
4. **Explotación de Vulnerabilidades:**
    
    - **Explotación de Vulnerabilidades Comunes:** Técnicas para explotar vulnerabilidades en sistemas operativos, aplicaciones web, y redes.
    - **Uso de Herramientas de Explotación:** Herramientas como Metasploit y Exploit-DB para desarrollar y ejecutar exploits.
5. **Post-Explotación:**
    
    - **Mantenimiento del Acceso:** Técnicas para mantener el acceso a sistemas comprometidos.
    - **Movimiento Lateral:** Cómo moverse dentro de la red para comprometer otros sistemas.
    - **Escalamiento de Privilegios:** Técnicas para obtener mayores privilegios en los sistemas comprometidos.
6. **Reportes y Comunicación de Resultados:**
    
    - **Documentación de Hallazgos:** Cómo documentar los hallazgos y las vulnerabilidades descubiertas.
    - **Comunicación con las Partes Interesadas:** Presentar los resultados de manera efectiva a las partes interesadas.