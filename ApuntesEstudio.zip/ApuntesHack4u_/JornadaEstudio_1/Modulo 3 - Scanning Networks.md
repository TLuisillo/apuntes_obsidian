
---
- Tags: #hping #hping3 #reconocimiento #enum #cybrary
--------


## Host Discovery Scan [[Nmap]]

```bash
nmap -sP 192.168.3.1/24
```

- OS Discovery with [[Nmap]]
```shell
nmap -O IP
```

---

## Uso de **HPing**

Nos permite realizar lo siguiente, haciendo uso de parametros
- Test firewall rules
- Advanced port scanning
- test net performance
- Path MTU discovery
- Tranfering files between even fascist firewall rules
- Traceroute-like under different protocols
- Remote OS fingerprinting and other
----

- *ACK* Packet:
```bash
hping -A IP
```

---

- Create packet with *FIN*, *URG*, *PSH* flags:
```shell
hping3 -F -U -P IP
```