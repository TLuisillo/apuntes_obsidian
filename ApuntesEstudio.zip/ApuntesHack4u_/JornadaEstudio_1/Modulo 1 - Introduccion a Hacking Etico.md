
------
- Tags: #cybrary
----

Seguridad de sistemas coniste en los metodos o procesos utlizados para proteger la informacion. De Ingresos no autorizados, proteccion de informacion sensible, divulgacion o uso inapropiado .Incluso la modificacion de los mismos.

Seguridad De La informacion engloba lo que es **Confidencialidad, Integridad y Disponibilidad** De la informacion

# Conceptos - Terminos

*HackValue* : Que tan atractivo o interesante es para el hacker dicho Objetivo

*ZeroDay*: Vulnerabilidades que no tienen un parche o que son NUEVAS

*Vulnerabilidad*: se Refiere a un punto debil en alguna red o algun sistema que puede ayudar a los atacantes a hackear el sistema, una vulnerabilidad puede ser un 
punto de entrada a tu objetivo

*Daisy Chaining(Conexion Encadenada)*: Es una secuencia de ataques realizados uno tras otro, usando la mismo informacion obtenida del anterior intento

*Exploit*: Es la brecha del sistema vulnerable, la tecninca que usaremos para vulnerar

*Doxing*: Se refiere a publicar informacion de alguna entridad, normalemnte recopilado de informacion publica, redes sociales, etc.
(A traves de ingeniera social, OSINT)

*Payload*: se refiere a la seccion de informacion o al dato que se ingresa y que realiza la acción dañina o no autorizada en el sistema comprometido.

*Bot*: es un software que realiza tareas especificas, asi como existen bots que realicen trabajos de dia a dia, como por ejemplo un *chatbot*, tambien existen los
bots  que pueden ser utilizados con propositos maliciosos. Los hackers usan los *Malware Bots* para ganar acceso o autoridad sobre un equipo


----------
# Tipos de Amenazas
### Amenazas de Red
**Los principales componentes de infraestructura de una red son los Routers, Switches y Firewalls**
- Escaneos
- Sniffing
- Spoofing
- Secuestro de sesion
- Man-In-The-Middle-Attack
- DNS & ARP Poisoning

### Amenazas de Host
**Se centran en un sistema de software, ya sea una aplicacion, framework o SO**
- Malware
- Ataques de Diccionario
- Ejecucion de codigo
- Escalados de Privilegios
- Backdoors
- Login Bypass

### Amenazas de Aplicacion
- Validacion de entradas
- Validacion de autenticaciones
- SQL Injection
- Configuraciones y reglas
- BufferOverflow (*BOF*)
- Ataques de criptografia
- Manejos de excepcion
- Parches de Seguridad a Servicios

----

# Cadena de Ciberataques / Cyber Kill Chain

1. **Reconocimiento:** El atacante investiga y recopila información sobre su objetivo, como identificar sistemas vulnerables o puntos de entrada.(OSINT, emails, Escaneo Red, Social Media, etc)
    
2. **Intrusión:** El atacante logra ingresar al sistema objetivo, ya sea a través de técnicas como el phishing, la explotación de vulnerabilidades o el uso de credenciales robadas.
    
3. **Elevación de privilegios:** Una vez dentro del sistema, el atacante busca obtener acceso a niveles más altos de privilegios para poder llevar a cabo acciones más destructivas.
    
4. **Persistencia:** El atacante establece mecanismos para mantener el acceso al sistema de manera prolongada, como instalando programas maliciosos o creando cuentas de usuario adicionales.
    
5. **Movimiento lateral:** El atacante se mueve dentro de la red, buscando expandir su acceso a otros sistemas y recursos.
    
6. **Obtención de objetivos:** Finalmente, el atacante logra su objetivo principal, que puede ser robar información confidencial, interrumpir servicios o causar daño a la organización atacada.

----

# Hacking concepts
Hacking nos referimos a explotar las vulnerabilidades de un sistema con el fin de obtener control del mismo.

## Fases del Hacking
- Reconocimiento
- Escaneo
- Ganar acceso
- Mantener el acceso (Persistencia)
- Borrar rastro
- Elevacion Privilegios???

### Hacking ETICO Conceptos
- Hacker etico se refiere a los encargados de encontrar debilidades o deficiencias en algun sistema, con el fin de prevenir futos ataques de cibercriminales

---
# Controles de seguridad de Informacion, Leyes y Estandares

## - Controles de seguridad de informacion
Se refiere a proteger la informacion para minimizar ataques ciberneticos. Esto incluye:
- Filtracion de datos
- Brechas de informacion
- Accesos no autorizados

### Information Assurance (IA) (Aseguramiento de Informacion)
Se compone de *Integridad*, *Disponibilidad*, *Confidencialidad* y *Autenticidad* 

- Politicas de seguridad:  Estas politicas cubren los lineamientos de la administracion, gestion y seguirdad que se requiere como un arcquitecto de seguridad

- Programa de administracion de seguridad: Disenados para reducir el riesgo de vulnerabilidades en relacion al sistema o entorno 

- Modelo de amenzas: processo de identifcar, diagnosticar y evaluar las amenzasas o vulnerabiliades de un sistema o apliicacion, teniendo en cuenta los objetivos de seguridad

---

# Leyes y Estandares

### Payment card industry Data Security Standar (PCI-DSS)
Es un estanadar global de seguirdad, creado para desarrollar, mejorar y evaluar los standeres requeridos para la manipulacion de informacion de pagos de algun titular de tarjeta

## ISO / IEC 27001:2013
Garantiza que los requerimientos para la implementacion o mantenimiendo y mejoramiento de un sistema de manejo seguro de informacion
- Implementacion y mantenimiento de requerimientos de seguridad
- Proceso de gestion de seguridad de informaicon
- Evaluacion de costo-Efectividad de gestion de riesgos
- Status de la seguridada de la informacion y gestion de actividades
- cumplimiento con las leyes