
---
- Tags: #cybrary #web #owasp 
---

### OWASP Top Ten

1. **Injection (Inyecciones)**: Ocurre cuando datos no confiables son enviados a un intérprete como parte de un comando o consulta. Esto puede permitir a un atacante ejecutar comandos maliciosos.

2. **Broken Authentication (Autenticación Rota)**: Problemas relacionados con la gestión, almacenamiento y transmisión incorrectos de credenciales y sesiones de autenticación, lo que puede permitir a los atacantes comprometer cuentas de usuario.

3. **Sensitive Data Exposure (Exposición de Datos Sensibles)**: La exposición de datos sensibles puede ocurrir cuando la aplicación web no cifra adecuadamente la información confidencial, como contraseñas, tarjetas de crédito u otra información personal.

4. **XML External Entities (XXE)**: Vulnerabilidad que permite a un atacante leer archivos locales, realizar escaneos de puertos, o llevar a cabo ataques de denegación de servicio a través de la carga de XML malicioso.

5. **Broken Access Control (Control de Acceso Roto)**: Fallos en la implementación de restricciones de acceso adecuadas, lo que puede permitir a los atacantes acceder a recursos no autorizados o realizar acciones no permitidas.

6. **Security Misconfiguration (Configuración de Seguridad Incorrecta)**: Errores en la configuración de la seguridad de la aplicación, incluyendo configuraciones predeterminadas no seguras, información sensible expuesta, y falta de actualizaciones y parches.

7. **Cross-Site Scripting (XSS)**: Ocurre cuando un atacante puede ejecutar scripts maliciosos en el navegador de un usuario final. Esto puede conducir a la manipulación de sesiones de usuario, redirección a sitios web maliciosos, o la obtención de cookies de sesión.

8. **Insecure Deserialization (Deserialización Insegura)**: Problemas relacionados con la deserialización de datos, que pueden llevar a la ejecución de código no autorizado si no se valida adecuadamente la entrada del usuario.

9. **Using Components with Known Vulnerabilities (Uso de Componentes con Vulnerabilidades Conocidas)**: Incorporar bibliotecas, frameworks o componentes de software obsoletos o con vulnerabilidades conocidas que no han sido parcheadas, lo que puede facilitar a los atacantes la explotación de la aplicación.

10. **Insufficient Logging & Monitoring (Registro y Monitoreo Insuficientes)**: La falta de registros adecuados y monitoreo de eventos de seguridad, lo que dificulta la detección y respuesta a incidentes de seguridad a tiempo.
