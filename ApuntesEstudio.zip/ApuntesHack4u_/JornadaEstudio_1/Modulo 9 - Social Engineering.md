
---
- Tags: #cybrary #osint
----

# Social Engineering Concepts

Stealing human information is known as social engineering. It does not require interaction with target systems or networks, so it is considered a non-technical attack. Social Engineering is seen as convincing the target to reveal and share information. The process may be executed through physical interaction with the target or by convincing the target to part with information using any social media platform. This technique is much easier than others because people are careless and often unaware of the importance and value of the information they possess.

# Social Engineering Techniques

There are a variety of techniques for carrying out social engineering attacks, which are categorized as follows: 

Human-based Social Engineering  

One-on-one interaction with the target is part of human-based social engineering. A social engineer gathers sensitive information by tricking the target, ensuring trust, and taking advantage of habits, behavior, and moral obligations.

Impersonation

Impersonating is a human-based social engineering technique. Pretending to be someone or something is known as impersonation. In this context, impersonation refers to pretending to be a legitimate user or an authorized individual. This impersonation can occur face-to-face or through a communication channel, including email or telephone.

Eavesdropping and Shoulder Surfing

Eavesdropping is a technique in which an attacker gathers information by covertly listening to a conversation. It also includes reading or accessing any source of information without being noticed.

Dumpster Diving

Dumpster Diving is the process of looking for treasure in the trash. This technique is old but still effective. It includes accessing the target's trash, such as printer trash, their user desk, or the company's trash, to find phone bills, contact information, financial information, source codes, and other helpful material.

Reverse Social Engineering

A Reverse Social Engineering attack requires the interaction of the attacker and the victim, where an attacker convinces the target they have a problem or might have an issue in the future. If the victim is convinced, they will provide the attacker with the information requested. The following steps are used to perform reverse social engineering:

1. An attacker harms the target system or identifies the known vulnerability.
2. An attacker advertises himself as an authorized person to solve that problem.
3. An attacker gains the target's trust and obtains access to sensitive information.
4. Upon successful reverse social engineering, the user may often approach the attacker for help.

Computer-based Social Engineering

There are various ways of performing PC-based social engineering. The most popular methods are pop-up windows requiring login credentials, Internet messaging, and emails such as Hoax Letters, Chain Letters, and Spam.

Mobile-based Social Engineering

Publishing Malicious Apps Mobile-based Social Engineering is the technique of publishing malicious applications on an application store. Being available on an official application store increases the chances of the application being downloaded on a large scale. These malicious applications are normally replicas or similar copies of a popular application.

Fake Security Apps

An attacker may develop a fake security application similar to the above techniques. A pop-up window can then download this security application when users browse the infected website.

Insider Attack

Social Engineering is more than just a third party gathering data about your organization. It may be an insider, an organization employee with or without privileges, or spying on your organization for malicious intentions. Insider attacks are those conducted by these insiders, who may be supported by a competitor of the organization hoping to obtain secrets and other sensitive information.

Social Engineering Through Impersonation on Social Networking Sites

Impersonation on social networking sites for social engineering is very common, simple, and interesting. The gathered information may include full name, a recent profile picture, date of birth, residential address, email address, contact details, professional details, educational details, etc. After gathering information about a target, the attacker creates an account that is the same as that person's account. This fake account is then introduced to friends and groups joined by the target. Usually, people do not question a friend request; if they do and find accurate information, they accept the request.

Risks of Social Networking to Corporate Networks

A corporate website is more secure than a social networking site. The authentication, identification, and authorization of employees accessing resources on these sites are different. Sensitive information is not stored on social networking sites; they use ordinary authentication. Social networking's authentication vulnerability is its major weakness. An attacker can easily alter the security authentication and make a fake account to gain access to information.

Pretexting

Pretexting is a form of social engineering in which plausible scenarios, or pretexts, are created to convince victims to share sensitive and valuable data. It could be a password, information about your credit card, personally identifiable information, confidential data, or anything else that could be used for fraud, like identity theft.

Catfishing

Catfishing is a deceptive behavior in which a person uses a fictitious persona or fake identity on a social networking site to target a specific individual.

Phishing

The process of sending a fake email to a target host and looking like an authorized email that appears to be processed is known as phishing. The recipient is enticed to provide information when they click on the link. Typically, users are redirected to fake web pages that resemble an official website. Because of the resemblance, the user provides sensitive information to a fake website, believing it is official.

1. Spear Phishing

It is a more targeted form of phishing in which the hacker targets a specific individual or company. The attacker customizes the messages based on the victims' features, occupations, phone numbers, and email addresses to make the scams less obvious. This kind of social engineering requires much effort from the attacker, which makes it hard to detect. If executed well, it has the biggest success rate.

1. Vishing

The only difference between this and phishing is that audio is used. The "scam call" is the social engineering attack used most frequently, where it is possible to fake caller identification numbers.

1. Smishing

SMS phishing, or smishing, uses SMS texting to carry out the same kind of scam, sometimes with an embedded malicious link to click.

1. Whale Phishing

Whale Phishing targets high-profile victims. Celebrities, politicians, and high-ranking businesspeople are examples of this.

How to recognize a phishing attack

1. The email's offer appears too good to be true. It could declare that you have won an expensive prize, the lottery, or something else.
2. You are aware of the sender, but you have not spoken to them.
3. It sounds like a scary message.
4. Unexpected or unusual attachments are in the message.
5. There are links in the message that do not look quite right.

# Social Engineering: Phishing Tools

Evilginx2

This tool is the successor to Evilginx, released in 2017, and provides man-in-the-middle functionality by utilizing a customized version of the Nginx HTTP server to serve as a proxy between a browser and a phished website.

SEToolkit

An open-source framework for social engineering-specific penetration testing is the Social Engineer Toolkit. You can quickly create a custom attack using SET's various attack vectors.

HiddenEye

This is a modern phishing tool with numerous tunneling services and advanced functionality.

King-Phisher

King Phisher is a tool for testing and raising user awareness by simulating phishing attacks.

Gophish

Business owners and penetration testers can benefit from the open-source phishing toolkit known as Gophish. It makes it possible to quickly and easily set up security awareness training and phishing events.

Wifiphisher

Wifiphisher is a rogue Access Point framework for carrying out Wi-Fi security testing or red team. Penetration testers can easily gain a man-in-the-middle position against wireless clients by carrying out specialized Wi-Fi association attacks with the help of Wifiphisher.

# Insider Threats

One of the greatest dangers that associations face is insider threats. These incorporate the accidental loss of information of on-screen characters who take data or bargain frameworks. In many of these cases, the loss of information could have been relieved or anticipated with powerful penetration testing. Insider threat is defined by the Cyber and Infrastructure Security Agency (CISA) as the threat that an insider will use their authorized access to harm the department's mission, resources, personnel, facilities, information, equipment, networks, or systems, whether they intend to or not. The threat by an insider can be unintentional or intentional.

# Unintentional Threats

Negligence

An organization is put at risk by this kind of insider. Careless insiders are, for the most part, acquainted with security and IT policy yet decide to disregard them, creating a risk for the association.

Accidental

This kind of insider mistakenly creates an unintended risk to an organization. Organizations work well to minimize accidents, but accidents do happen.

# Intentional Threats

Intentional Threats

An intentional threat is causing harm to an organization for personal gain or to address a personal grievance. The term intentional insider is frequently used as a "malicious insider."

# Other threats

Collusive Threats  

Collusive threats comprise a subset of malicious insider threats, in which one or more insiders collaborate with an external threat actor to compromise an organization.

Third-Party Threats

Additionally, contractors or vendors who have been granted access to facilities, systems, networks, or individuals to complete their work are typically considered third-party threats.

# Identity Theft

Stealing information about another person's identity is known as identity theft. Identity theft is popularly used in fraud. Anyone with malicious intent may steal your identity by gathering documents such as utility bills, personal and other relevant information, and creating a new ID card to impersonate you. This information may also be used to confirm and take advantage of the fake identity. Identity theft starts with the initial phase in which an attacker focuses on finding all the necessary and useful information, including personal and professional details. Dumpster diving and accessing the desk of an employee are very effective techniques.

# Social Engineering Countermeasures

Social engineering attacks can be defended using a variety of methods.

1. Corporate privacy is essential to prevent the threat of surfing the shoulder or diving in a dump.
2. Configuring strong passwords and keeping them safe and confidential protects you from social engineering. Information can always leak from social networking platforms.

However, social media is becoming an important part of an organization's marketing. Therefore, attention should be paid to social networking platforms, logging, training, awareness, and auditing to mitigate the risk of social engineering attacks.