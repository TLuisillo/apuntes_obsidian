
----
- Tags: #cybrary #hijacking 
----

**Session Hijacking:** El secuestro de sesión se refiere al acto de tomar el control de una sesión de usuario legítima después de que se ha establecido una conexión válida. Esto puede ocurrir mediante el robo de cookies de sesión, la interceptación de tokens de autenticación o la explotación de vulnerabilidades en la comunicación entre el cliente y el servidor. Los atacantes suelen buscar tomar el control de la sesión para realizar acciones maliciosas en nombre del usuario legítimo, como acceder a datos sensibles o realizar transacciones no autorizadas.

**Techniques:** Existen diversas técnicas para llevar a cabo el secuestro de sesión. Estas incluyen el uso de herramientas especializadas como programas de escucha de red (sniffers) para interceptar datos de sesión, ataques de fuerza bruta para adivinar cookies de sesión válidas, o ataques man-in-the-middle (MITM) donde el atacante se interpone en la comunicación entre el cliente y el servidor para obtener información de sesión.

**Process:** El proceso de secuestro de sesión generalmente comienza con la identificación de la sesión válida que el atacante desea tomar. Luego, se utilizan técnicas para obtener el identificador de sesión (como una cookie o un token) o para interceptar la sesión activa. Una vez que el atacante tiene el control de la sesión, puede utilizarla para acceder a recursos protegidos por la autenticación del usuario legítimo.

**Types:** Los tipos de secuestro de sesión pueden clasificarse en función del nivel en el que ocurre el ataque. En el nivel de aplicación, los ataques pueden dirigirse a vulnerabilidades específicas en aplicaciones web, como XSS (Cross-Site Scripting) o SQL Injection, para robar cookies de sesión. A nivel de red, los ataques MITM son comunes, donde el atacante intercepta y modifica la comunicación entre el cliente y el servidor para obtener acceso a la sesión.

**Application Level:** El secuestro de sesión a nivel de aplicación se centra en explotar vulnerabilidades dentro de la lógica de la aplicación o las configuraciones de seguridad débiles para obtener acceso a cookies de sesión válidas. Esto puede incluir la ejecución de scripts maliciosos en el lado del cliente para robar cookies o manipular sesiones de usuario.

**Network Level:** El secuestro de sesión a nivel de red se produce cuando un atacante intercepta y manipula la comunicación entre el cliente y el servidor. Esto puede llevarse a cabo mediante ataques MITM, donde el atacante intercepta los datos en tránsito para obtener tokens de autenticación o cookies de sesión válidas, permitiéndoles acceder a la sesión del usuario sin ser detectados inicialmente

---

El *CRIME attack* (ataque CRIME) es una técnica de ataque específica que explota una vulnerabilidad en los protocolos de compresión utilizados en conexiones HTTPS y SPDY, los cuales son usados para comprimir el tráfico web con el objetivo de mejorar el rendimiento. Esta vulnerabilidad fue descubierta en 2012 por investigadores de seguridad.

El nombre "CRIME" proviene de las iniciales de los términos "Compression Ratio Info-leak Made Easy" (fuga de información de relación de compresión facilitada). El ataque se basa en la capacidad del atacante para observar la longitud comprimida del tráfico HTTPS y SPDY mientras modifica el contenido enviado a la víctima. A través de técnicas de prueba y error, un atacante puede deducir el valor de ciertas cookies de sesión o tokens de autenticación que están encriptados dentro del tráfico comprimido.
