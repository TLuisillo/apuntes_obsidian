
-----
- Tags: #enum #cybrary #puerto #ldap
---
### Conceptos Basicos de Enumercion

(In the phase of Enumeration, an attacker initiates active connections with the target system to extract more information.)

Obtener mas informacion del sistema objetivo, para identificar los puntos de ataque.

- Routing information
- SNMP Information(Simple Network Management Protocol (SNMP) es un **protocolo de capa de aplicación basado en IP que intercambia información entre una solución de administración de red y cualquier dispositivo habilitado para SNMP**.)
- DNS information
- Machine Name
- User Information
- Group **information**
- Application and Banners
- Network Sharing Information
- Network Resources

---

- Enumeracion usando *Email*, teniendo una direccion de correo podemos obtener el nombre de usario de y el *Dominio*

- Usando Credenciales por defecto. Siempre todo software tiene credenciales por defecto y en veces estas no son cambiadas o configuradas correctamente, permitiendonos facilmente un acceso no autorizado

- Enumeracion usando SNMP: Es un proceso de recolectar inforamcion a traves del SNMP usa las cadenas o strings por default de la comunidad como *Guesses*

- BruteForce Attack on AD: con el fin de conocer usuarios, direcciones, credenciales, inforamacion privilegiada, etc

- DNS Transfer Zone Attack: Para extraer informacion del DNS como su locacion, DNS records, IP , Usernames, etc.
  Una transferencia de zona es actualizar el servidor DNS; un *Archivo de Zona* contiene informacion valiosa que un atacante podria aprovechar

----

## NetBIOS

 (Stands for network Basic *Input/Output* System)

Es, en sentido estricto, **una especificación de interfaz para acceso a servicios de red**, es decir, una capa de software desarrollado para enlazar un sistema operativo de red con hardware específico.

### PUERTOS 

- *UDP* 137 (*Name Services*)
- *UDP* 138 (*Datagram Services*)
- *TCP* 139 (*Session Services*)

Haciendo una enumeracion del NetBIOS, un atacante puede conocer:
- Lista de maquinas dentro de un Dominio
- Archivos compartidos (SMB)
- Printer Sharing
- Username
- Group Inform,ation
- Password
- Politicas

----

Comando: **net view**
Herramienta: **nbstat** 

The command:
```shell
nbstat -A <IP> 
```
shows the List the remote machine’s name table given its IP address

----

#### SNMPv3 supports *DES && Hashing*
Lo que se traduce a **MD5 y SHA**

- Herraminetas Enumeracion *SNMP*: OpUtils, Enginerr's Toolset

-------

# LDAP

(El **protocolo ligero de acceso a directorios** (en inglés: Lightweight Directory Access Protocol, también conocido por sus siglas de *LDAP*) hace referencia a un protocolo a nivel de aplicación que permite el acceso a un servicio de directorio ordenado y distribuido para buscar diversa información en un entorno de red.)

- LDAP provee un sitio central para almacenar usuarios y contrasenas
- Applications y services se conectan al servcicio LDAP para validar credenciales
- AD
- Open Directory
- OracleiPlanet
- Novell eDictionary
- OpenLDAP

### Herramientas Enumeracion
- JXplorer
- LDAP Admin Tool
- LDAP Account Manageer
- Active Directory Explorer
- LDAP Administration Tool
- LDAP search
- AD Domain services Management Pack

---

# NTP 
(Network Time Protocol)

*PUERTO UDP - 123*

Destinado a sincronizar relojes de la red de computadoras

- Herramientas Enum: *Nmap, NTP ServerScanner, wireshark ,NTP Query*

---

# NFS
(Network File System)

permite a un host correr diferentes SO montando un sistema de archivos centralizado

---

# SMTP 
(Simple Mail Transfer Protocol)
*Puerto TCP - 25*

### Herramientas Enum:
- Telnet
- SMTP-user-enum

---

## Nslookup

El comando "nslookup" es una herramienta de línea de comandos utilizada para consultar y obtener información sobre sistemas de nombres de dominio (DNS). 

```bash
nslookup
set type=mx
domain.com
```

"nslookup" con el parámetro "set type=mx" seguido del nombre de dominio, estás configurando la consulta para que devuelva registros MX (Mail Exchange) asociados con ese dominio.


```bash
nslookup
set type=ns
domain.com
```

Este comando te proporcionará información sobre los registros NS (Name Server) del dominio "domain.com".