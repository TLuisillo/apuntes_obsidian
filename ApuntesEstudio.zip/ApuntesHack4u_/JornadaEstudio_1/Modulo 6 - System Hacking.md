
---
- Tags: #cybrary 
---

### System Hacking Methodology (CEH - EcCouncil)
-  Ganar acceso
- Romper Contrasenas
- Explotar Vulnerabilidades
- Escalar Privilegios
- Mantener acceso
- Ejecucion de aplicaiones
- Encontrar Archivos
- Cubriendo / Borrando Huellas


**Fuerza Bruta**: Prueba todas las combinaciones alfanumericas posibles
**Ataque de Diccionario**: Prueba una lista especifica de palabras comunes o relacionadas

---

## Encypted Passwords

![[Pasted image 20240425182944.png]]

 **Cracking Password Tools**

- pwduump7
- fgdump
- l0phtCrack
- ophcrack
- RainbowCrack
- Cain and Abel

-------

# Exploit 
Codigo que explota una Vulnerabilidad 

---

# Privesc

- **Escalada de privilegios vertical**: Se refiere al proceso mediante el cual un usuario o un programa obtiene permisos o privilegios más elevados dentro de un sistema. Esto puede ocurrir dentro del mismo usuario (por ejemplo, de un usuario con permisos limitados a uno con permisos de administrador) o entre diferentes usuarios (por ejemplo, de un usuario estándar a uno con privilegios de administrador).

- **Escalada de privilegios horizontal**: Es el proceso mediante el cual un usuario o un programa obtiene los mismos niveles de privilegios pero en cuentas diferentes dentro de un sistema. Esto permite a un atacante o usuario acceder a recursos o datos a los que no tendría acceso de otro modo, al aprovechar la falta de segregación de privilegios entre cuentas.

---

