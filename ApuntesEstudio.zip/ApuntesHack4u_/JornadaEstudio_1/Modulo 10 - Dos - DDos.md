
---
- Tags: #cybrary 
---

# DoS/DDoS Concepts

A Denial-of-Service (DoS) attack attempts to shut down a machine or network, making it unreachable to its intended users. DoS attacks achieve this by providing the victim with excessive traffic or information that causes a system breakdown. The attack denies the service or resource that legitimate users (such as employees, members, or account holders) expected. 

The technique for performing a DoS attack is to generate huge traffic to the target system requesting a specific service. This unexpected traffic overloads the system's capacity and either results in a system crash or unavailability.

# DoS/DDoS Attack Techniques

Distributed Denial-of-Service (DDoS)  

DDoS is similar to Denial-of-Service in which an attacker generates fake traffic. In a Distributed DoS attack, multiple compromised systems are involved in attacking a target to cause a denial of service. Botnets are most often used for carrying out a DDoS attack.

Volumetric Attacks  

Volumetric Attacks focus on overloading bandwidth consumption capabilities. These volumetric attacks are carried out to slow down the performance and degrade the service.

Fragmentation Attacks  

DoS Fragmentation Attacks fragment the IP datagram into multiple smaller-size packets. These fragmented packets require reassembling at the destination, requiring the router's resources. Fragmentation attacks are of the following two types: 

1. UDP and ICMP Fragmentation Attacks  
2. TCP Fragmentation Attacks

TCP-State-Exhaustion Attacks  

TCP State-Exhaustion Attacks focus on web servers, firewalls, load balancers, and other infrastructure components to disrupt connections by consuming the connection state tables. A TCP State-Exhaustion attack results in exhausting the finite number of concurrent connections the target device can support. The most common state-exhaustion attack is the ping of death.

Application Layer Attacks   

An Application Layer DDoS Attack is also called a layer 7 DDoS attack. An application-level DoS attack focuses on the application layer of the OSI model for its malicious intention. An application-layer DDoS attack includes an HTTP flood attack in which a victim's server is attacked by botnets flooding it with HTTP requests.

Bandwidth Attacks  

A Bandwidth Attack requires multiple sources to generate a request to overload the target. A DoS attack using a single machine cannot generate enough requests to overwhelm the service. The distributed DoS attack is a very effective technique for flooding requests toward a target.

A Service Request Floods  

A Service Request Flood is a DoS attack in which an attacker floods requests to a server, such as an application server or web server until the entire service is overloaded. When a legitimate user attempts to initiate a connection, it will be denied because the TCP connection limit on the server has already been exceeded.

SYN Attack/Flooding

SYN Attacks or SYN Flooding exploit the three-way handshake. The attacker floods SYN requests to the target server to tie up the system. This SYN request has a fake source IP address that cannot be used to find the victim.

ICMP Flood Attack  

An Internet Control Message Protocol (ICMP) Flood Attack is another type of DoS attack that uses ICMP requests. ICMP is a supporting protocol used by network devices to send operational information, error messages, and indications. These requests and their responses consume the resources of the network device. Thus, flooding ICMP requests without waiting for responses overwhelms the device's resources.

Peer-to-Peer Attacks  

A Peer-to-Peer DDoS Attack exploits bugs in peer-to-peer servers or peering technology using the Direct Connect (DC++) protocol to execute a DDoS attack. Most peer-to-peer networks are on the DC++ client. Each DC++-based network client is listed in a network hub. Peer-to-peer networks are deployed among a large number of hosts. One or more malicious hosts in a peer-to-peer network can perform a DDoS attack.

Permanent Denial-of-Service Attack  

A Permanent Denial-of-Service Attack is a DoS attack that focuses on hardware sabotage instead of focusing on the denial of services. Hardware affected by a PDoS attack is damaged to an extent requiring replacement or reinstalling of hardware. PDoS is performed by a method known as Phlashing or Bricking, which causes irreversible damage to the hardware or a system by sending fraudulent hardware updates.

Distributed Reflection Denial-of-Service (DRDoS)  

A Distributed Reflection Denial-of-Service Attack is the type of DoS attack in which intermediary and secondary victims are involved in launching a DoS attack. An attacker sends requests to the intermediary victim, redirecting traffic toward the secondary victim. The secondary victim redirects the traffic toward the target. The involvement of intermediary and secondary victims is for spoofing the attack.

# Botnets 

A botnet (short for “robot network”) is a network of computers infected by malware that is under the control of a single attacking party, known as the “bot-herder.” Each individual machine under the control of the bot-herder is known as a bot. From one central point, the attacking party can command every computer on its botnet to simultaneously carry out coordinated criminal actions or repetitive tasks. The scale of a botnet (many comprised of millions of bots) enables the attacker to perform large-scale actions that were previously impossible with malware. Since botnets remain under the control of a remote attacker, infected machines can receive updates and change their behavior on the fly.

Malicious botnets gain access to a system using malicious scripts and codes. This alerts the master computer when the botnets start controlling the system. Through this master computer, an attacker can control the system and issue requests to attempt a DoS attack.

The botnet is typically set up by installing a bot program on a victim using Trojan Horse. Trojan Horse carries a bot as a payload, which is forwarded to the victim by phishing or redirecting to either a malicious website or a compromised genuine website. Once this malicious payload is executed, the device gets infected and comes under the control of Bot Command and Control (C&C). C&C controls all the infected devices through Handler.

Subnet Scanning Technique 

This technique is used to attempt scanning behind a firewall where the compromised host is scanning for vulnerable targets in its own local network. This technique is used for forming an army of zombies in a short span of time 

Permutation Scanning Technique 

Permutation scanning uses a pseudorandom permutation. In this technique, infected machines share the pseudorandom permutation of IP addresses. If scanning detects an infected system by either hit-list scanning or any other method, it continues scanning from the next IP in the list. If scanning detects an already infected system by permutation list, it starts scanning from a random point in the permutation list

Propagation of Malicious Code 

The three most commonly used malicious code propagation methods are:

1. Central Source Propagation  
2. Back-Chaining Propagation  
3. Autonomous Propagation

Central Source Propagation 

Central Source propagation requires a central source from where the copy of the attack toolkit is transmitted to a system that has been recently compromised. When an attacker exploits a vulnerable machine, this opens the connection on the infected system for a file transfer request. Then, the toolkit is copied from the central source and automatically installed on the compromised system. This toolkit is used for initiating further attacks.

Back-Chaining Propagation  

Back-Chaining Propagation requires an attack toolkit to be installed on the attacker's machine. When an attacker exploits the vulnerable machine, a connection on the infected system is opened to accept the file transfer request. Then, the toolkit is copied from the attacker's machine. Once the toolkit is installed on the infected system, it will search for other vulnerable systems, and the process continues.

Autonomous Propagation

In autonomous propagation, an attacker exploits and sends malicious code to the vulnerable system. Once the code is copied or a malicious toolkit is installed, it searches for other vulnerable systems.  Unlike Central Source Propagation, it does not require any central source or planting of a toolkit on the attacker's system.

# DoS/DDoS Attack Tools

Pandora DDoS Bot Toolkit  

The Pandora DDoS Toolkit was developed by Sokol, who also developed the Dirt Jumper Toolkit. The Pandora DDoS Toolkit can generate five types of attacks, including infrastructure and application-layer attacks, namely: 

1. HTTP Min  
2. HTTP Download  
3. HTTP Combo  
4. Socket Connect  
5. Max Flood  

Other DDoS Attack Tools  

1. Derail  
2. HOIC (High Orbit Ion Cannon) 
3. DoS HTTP  
4. BanglaDos  
5. R.U.D.Y (R-U-Dead-Yet)  

DoS and DDoS Attack Tools for Mobile  

1. AnDOSid 
2. Lo Orbit Ion Cannon (LOIC)

# DoS/DDoS Detection Tecniques

Activity Profiling  

Activity Profiling means monitoring the activities running on a system or network. By monitoring the traffic flow, DoS/DDoS attacks can be observed by analyzing a packet's header information for TCP Sync, UDP, ICMP, and Netflow traffic. Activity profiling is measured by comparing it to the average traffic rate of a network.

Wavelet Analysis  

Wavelet-based Signal Analysis is an automated process of detecting DoS/DDoS attacks by analyzing input signals. This automated detection is used to detect volume-based anomalies. Wavelet analysis evaluates the traffic and filters it on a certain scale, whereas Adaptive threshold techniques are used to detect DoS attacks.

Sequential Change-Point Detection  

Change-Point detection is an algorithm used to detect DoS attacks. This detection technique uses a non-parametric Cumulative Sum (CUSUM) algorithm to detect traffic patterns. Change-Point detection requires very low computational overheads. The Sequential Change-Point detection algorithm isolates the changes in the network traffic statistics caused by the attack. The key functions of the sequential change-point detection technique are to:

1. Isolate traffic
2. Filter traffic
3. Identify attack
4. Identify scan activity 

# DoS/DDoS Protection Tools

AWS Shield   

The AWS (Amazon Web Services) Shield is a DDoS protection tool that examines the traffic approaching your websites using flow monitoring. By examining the flow data, the program detects suspicious traffic in real-time. This tool includes features like packet filtering and prioritization to further assist you in managing incoming traffic. 

Indusface AppTrana   

Indusface App Trana is a DDoS and bot mitigation software that provides a service bundle with a Web Application Firewall, vulnerability scanners, and patching service. It references the OWASP top 10 threats list and the SANS 25 Vulnerability list to find threats. It is also remarkably capable of handling volumetric attacks. 

SolarWinds Security Event Manager

It is a DDoS protection tool that includes event log monitoring capabilities. The tool has a list of various automated features which helps the tool automatically block out available malicious IPs from dealing with your network. The list is frequently updated, ensuring your protection even from the most current threats.

Link11  

Link11 is a cloud-based DDoS security tool that can identify and prevent DDoS attacks in layers 3–7. It also has a cutting-edge, AI-based attack detection method.

Cloudflare  

A DDoS prevention tool with a network bandwidth of 30Tbps, making it more powerful than even the most powerful DDoS attacks. The tool primarily relies on its huge IP reputation database, which allows it to block malicious IPs from over 20 million locations. 

Sucuri Website Firewall   

It is a cheap, scalable tool that provides geo-blocking features to help you block out DDoS traffic. This tool also looks at your HTTP and HTTPS traffic to stop malicious agents from getting to your site. 

StackPath Web Application Firewall  

StackPath is a DDoS prevention tool and a WAP ( Web Application Protection) tool that provides layer 3, 4, and 7 protection. Behavioral algorithms are used in layer seven defense to detect and prevent volumetric threats. Its mitigation tools can block HTTP, UDP, SYN flood, and other attack channels.

Akamai Prolexic Routed   

It is a security tool with zero-second mitigation, which can assist in addressing vulnerabilities as soon as they are detected. Akamai Prolexic Routed is an advanced protection tool with various features like hybrid cloud protection and is specialized for enterprises.

Techniques to Defend Against Botnets  

RFC 3704 Filtering is used for defending against botnets. It is designed for ingress filtering for multi-homed networks to limit DDoS attacks. RFC 3704 denies traffic with spoofed address access to the network and traces the host's source address. 

Cisco IPS Source IP Reputation Filtering  

Source IP Reputation Filtering is ensured by Cisco IPS devices, which can filter traffic based on reputation score and other factors. IPS devices collect real-time information from a Sensor Base Network. Its Global Correlation feature ensures the intelligence update of known threats, including botnets and malware, to help detect advanced and latest threats. These threat intelligence updates are frequently downloaded on IPS and Cisco firepower devices. 

Black Hole Filtering

Black Hole Filtering is a process of silently dropping traffic (either incoming or outgoing) so that the source is not notified about a packet being discarded. Remotely Triggered Black Hole Filtering (RTBHF) is a routing technique used to mitigate DoS attacks using the Border Gateway Protocol (BGP). The router performs black hole filtering using null-0 interfaces. However, BGP also supports blackhole filtering.

Enabling TCP Intercept on Cisco IOS Software  

The TCP Intercept command is used on Cisco IOS routers to protect TCP Servers from TCP SYN flooding attacks. The TCP Intercept feature prevents the TCP SYN, a type of DoS attack, by intercepting and validating TCP connections. 

Incoming TCP Synchronization (SYN) packets are matched against the extended access list. TCP intercept software responds to the TCP connection request on behalf of the destination server; if the connection is successful, it initiates a session with the destination server on behalf of the requesting client and knits the connection together transparently. Thus, SYN flooding will never reach the destination server.

