
---
- Tags: #cybrary #web #owasp 
----
# Web App Concepts

Web Applications run on a remote application server and are available for clients over the Internet. A web application can be available on different platforms, for example, browsers and software. The use of web applications has increased enormously in the last few years. 

They depend on a client-server relationship and provide an interface for clients to use web services. Web pages may be generated on the server or may contain scripts for dynamic execution on the client web browser.

# Web App Threats

Threats to Web Applications include: 

1. Cookie Poisoning  
2. Insecure Storage  
3. Information Leakage  
4. Directory Traversal  
5. Parameter/Form Tampering  
6. DOS Attack  Buffer Overflow  
7. Log Tampering  SQL Injection  
8. Cross-Site (XSS)
9. Cross-Site Request Forgery
10. Security Misconfiguration 
11. Broken Session Management 
12. DMZ Attacks Session Hijacking
13. Network Access Attacks

Invalidated Inputs 

Invalidated input refers to processing non-validated input from the client to a web application or backend server. This vulnerability can be exploited to perform XSS, buffer overflow, and injection attacks. 

Parameter/Form Tampering 

Parameter Tampering refers to an attack in which parameters are manipulated while the client and server communicate. An attacker modifies parameters such as the Uniform Resource Locator (URL) or web page form fields. In this way, a user may be redirected to another website, which may look exactly like the legitimate site, or an attacker can modify the fields, for example, cookies, form fields, and HTTP Headers.

Injection Flaws 

Injection attacks work because of web application vulnerabilities. If a web application is vulnerable enough to allow untrusted input to be executed, then the following injection attacks can be performed: 

1. SQL Injection  
2. Command Injection
3. LDAP Injection

SQL Injection

SQL Injection is the injection of malicious SQL queries. Using SQL queries, an unauthorized user interrupts the processes, manipulates the database, and executes commands and queries by injection, resulting in data leakage or loss. These vulnerabilities can be detected by using application vulnerability scanners. An SQL injection is often executed using the address bar. Attackers bypass the vulnerable application's security and extract valuable information from its database using SQL injection.

OWASP Top 10 Application Security Risk  

The OWASP Top 10 is the best way to start transforming an organization's software development culture towards one that produces more secure code, and their desktop applications minimize these risks.

Broken access control

Access control limits what users can access, restricting them to resources within their assigned permissions. Access control failure commonly results in users performing business functions that require different permissions than they were assigned, among other activities. Failure also leads to unauthorized information disclosure, modification, or data destruction.

Cryptographic failures

Cryptographic failures are a broad symptom of a breakdown or deficiency in cryptography, which can lead to system compromise or sensitive data exposure. Personally identifiable data and credit card numbers are among the data types that require extra protection. Data protection methods are determined by the type of data and whether or not it is subject to data privacy laws such as the EU General Data Protection Regulation (GDPR).

Injection

Injection vulnerabilities can be detected through source-code review. This category includes cross-site scripting, SQL injection, and XML injection, among many others. Automation can help by ensuring all parameters and data inputs are tested to identify vulnerabilities.

Applications are vulnerable to injection when:

1. User-entered data is accepted without validation, sanitization, or filtering.
2. Hostile data is used to extract sensitive information.

Insecure design

Insecure design differs from insecure implementation. A secure design can be implemented imperfectly, resulting in vulnerabilities. Insecure design can’t be fixed through implementation since the design itself doesn’t contain appropriate security controls. A failure to accurately assess business risk associated with the software or system under development leads to insufficient levels of security.

Security misconfiguration

Security misconfigurations can be caused by an array of inappropriately configured controls and other factors contributing to application vulnerability. This category includes many common misconfigurations.

1. Misconfigured permissions for cloud services.
2. Enabling unnecessary features may lead to needlessly opened ports, services, or incorrectly elevated privileges.
3. Unchanged default account login credentials.

Vulnerable and outdated components

Unpatched and legacy components that remain in production well after vulnerabilities are discovered and disclosed can be a major risk. Applications can be vulnerable when they aren’t running the latest software version. The application may be vulnerable if it’s unclear which library or component version is being used. Components that aren’t scanned for vulnerabilities may also be at risk.

Identification and authentication failures

Authentication and identification failures happen when user identity, authentication, and session information aren’t confirmed before the user is permitted to access systems and data. Factors that may put an application at risk due to these failures include allowing weak passwords; using weakly hashed, plain-text password data stores; and allowing bots, which can perform automated attacks such as brute-force and credential stuffing.

Software and data integrity failures

New to the OWASP list is the CWE of failures in software and data integrity. The risk here is trusting data and software updates without checking their integrity. Attackers have used the software supply chain to issue malware through seemingly legitimate software updates. Many systems use automated software update features that do not verify the integrity of updates.

Security logging and monitoring failures

The security logging and monitoring failures category focuses on issues with audit logs and monitoring during an attack. Security monitoring and logs are essential to detect and mitigate an active breach. Failures happen when:

1. Logging doesn’t keep track of transactions with high value, login attempts, and failed login attempts.
2. Errors and warnings generate unclear, inadequate, or no log entries.
3. APIs and applications aren’t monitored for suspicious activities. Aren’t monitored for suspicious activities.
4. Security logs are only available locally.
5. Applications that can neither detect nor issue timely alerts for attacks in progress.

Server-side request forgery (SSRF)

The server-side request forgery category focuses on weaknesses within user-convenience features. SSRF flaws happen when web applications fetch user-requested remote sources without first verifying the destination. Specific requests can be sent to the application through an unexpected source. 

# Web App Hacking Methodology

Footprint Web Infrastructure

Footprinting web application infrastructure helps to discover information, vulnerabilities, and entry point in the target web application. There are different techniques to footprint web infrastructure, such as: 

1. Collecting Server related information (version, make, model, etc.)  
2. Services Footprinting (running services, vulnerable services, ports)  
3. Network Footprinting (open, closed, and filtered ports)

Analyze Web Applications  

Analyzing Web Applications includes observing the functionality and other parameters to identify vulnerabilities, entry points, and server technologies that can be exploited. HTTP requests and HTTP fingerprinting techniques are used to diagnose these parameters.

By-pass Client-side Control  

Web security becomes even more challenging when a web application supports clients to submit arbitrary input. Some of the application partially or completely depends on client-side controls. It is a security flaw because a user has full control over the client and the data it submits. It can bypass the control that is not replicated on the server side. Following are some techniques to bypass client-side controls:

1. Bypass hidden form fields  
2. Bypass client-side JavaScript validation  
3. Parameter manipulation  
4. Forced browsing

Attack Authentication Mechanism  

By exploiting the Authentication Mechanism using different techniques, an attacker may bypass the authentication or steal information. Attacking on authentication mechanism includes: 

1. Username Enumeration  
2. Cookie Exploitation  
3. Session Attacks  
4. Password Attacks  

Authorization Attack Schemes  

By accessing the web application using a low-privilege account, an attacker can escalate privileges to access sensitive information. Different techniques like URL, POST data, Query string, cookies, parameter tampering, and HTTP header are used to escalate privileges.

Attack Access Control

A web application authorizes its users to access the resources and functions using an access control mechanism. In a web application, an access control mechanism plays an important role as it authorizes access to the content and resources published in that particular application.

Session Management Attack  

A Session Management Attack is performed by bypassing authentication to impersonate a legitimate authorized user. This can be done using different session hijacking techniques such as: 

1. Session Token Prediction  
2. Session Token Tampering  
3. Man-in-the-Middle Attack  
4. Session Replay  

Perform Injection Attacks  

An Injection Attack is the injection of malicious code, commands, and files by exploiting vulnerabilities in a web application. An injection attack may be performed in different forms, like: 

1. Web Script Injection
2. OS Command Injection  
3. SMTP Injection  
4. SQL Injection  
5. LDAP Injection  
6. XPath Injection  
7. Buffer Overflow  
8. Canonicalization

Attack Database Connectivity  

A Database Connectivity Attack focuses on exploiting the data connectivity between an application and its database. Initiating a connection to the database requires a connection string. A data connectivity attack includes: 

1. Connection String Injection  
2. Connection String Parameters Pollution (CSPP)  
3. Connection Pool DoS

Attack Web Client  

Web browsers running on the user's machines that render the requested pages from the application server are typically called web clients.  The definition of web client also covers "thin client," which does not execute complex rules as these operations are off-loaded on the server.

Attack Web Services  

An application server runs several web-related services that support an application in loading, executing, and functioning properly. These running web services may include vulnerable services protocols (such as SOAP, WSDL, UDDI, and others) that an attacker can target.

Web APIs  

The Web Application Programming Interface (API) is an intermediary component of a web application that helps applications communicate with other applications, services, and platforms.  APIs are typically used for accessing, extracting, and sharing data. SOAP and Rest APIs are popular approaches used in web applications.

WebHooks, & Web Shell  

Webhooks are user-defined callbacks that are triggered by an event. They are unlike a typical API in which data is frequently polled for real-time ingestion. The server responds with a POST request whenever a web client requests a webhook call. These incoming requests should be authenticated to avoid any malicious ingestion like MITM, XSS, and Scripting.