
----
# Penetration Testing an Ethical Hacking
---
- Tags: #cybrary 
----

To assess the strength of your organization’s cybersecurity posture, you need to gather information, perform scanning and enumeration, and show how an adversary could hack into your systems. This ethical hacking course will give you those skills and prepare you for related certification exams so you can prove your capabilities.

### - 30 Hrs

---------------
# Temario 

- *Modulo 1* : Introduccion a hacking etico
- *Modulo 2* : Reconocimiento y Footprinting
- *Modulo 3* : Escaneo de Redes
- *Modulo 4* : Enumeracion
- *Modulo 5* : Analisis de Vulnerabilidades
- *Modulo 6* : Hackeo de Sistemas
- *Modulo 7* : Malware
- *Modulo 8* : Sniffing
- *Modulo 9* : Ingenieria Social
- *Modulo 10* : Denegacio de Servicios
- *Modulo 11* : Secuestro de Sesion
- *Modulo 12* : Evacion IDS, Firewall y HoneyPots
- *Modulo 13* : Hacking servicios Web
- *Modulo 14* : Hacking App Web
- *Modulo 15* : Inyeccion SQL
- *Modulo 16* : Hacking redes WIFI
- *Modulo 17* : Hacking Apps Moviles
- *Modulo 18* : IoT & OT Hacking
- *Modulo 19* : Computo en la nube
- *Modulo 20* : Criptografia


-----------------

-- Creds: mtzlumbrerasl