
---
- Tags: #cybrary #sql #sqli  #owasp 
----

# SQL Injection Concepts

SQL Injection Attack uses SQL websites or web applications. It relies on strategically injecting malicious code or scripts into existing queries. This malicious code is drafted to reveal or manipulate data stored in the tables within a database. SQL injection is a powerful and dangerous attack. It identifies the flaws and vulnerabilities in a website or application. The fundamental concept of SQL injection is to inject commands to reveal sensitive information from the database. Hence, it can result in a high-profile attack.

# Types of SQL Injection

SQL Injections can be classified into three major categories:

1. In-band SQLi
2. Inferential SQLi
3. Out-of-band SQLi

# In-band SQL Injection 

In-band SQL Injection includes injection techniques that use the same communication channel to launch an injection attack and to gather information from the response. In-band injection techniques include:

1. Error-based SQL Injection. Injection Error-based SQL Injection is an in-band SQL injection technique. It relies on error messages from the database server to reveal information about the structure of the database. Error-based SQL injection is very useful for an attacker to enumerate an entire database. Error messages are used during the development phase to troubleshoot issues. These messages should be disabled when an application website is live. Error-based SQL injection can be performed using the following techniques: 
2. Union-based SQL Injection. Union-based SQL Injection is another in-band SQL injection technique that involves using the UNION SQL operator to combine the results of two or more SELECT statements into a single result.

# Inferential SQL Injection (Blind Injection) 

No data is transferred from a web application in an Inferential SQL Injection. These are referred to as Blind Injections because the attacker cannot see the results of an attack; they simply observe the server's behavior. The two types of inferential SQL injection are:

1. Boolean-based Blind SQL Injection
2. Time-based Blind SQL Injection.

Boolean Exploitation Technique.  Blind SQL injection is the technique of sending a request to a database. The response is either true or false, so it does not contain any database data. By observing the HTTP response, the attacker can evaluate it and infer whether the injection was successful or unsuccessful. 

# Out-of-band SQL Injection  

Out-of-band SQL Injection is a technique that uses different channels to launch the injection and to gather the response. It requires some features to be enabled, for example, DNS or HTTP requests on the database server; hence, it is not very common.

# SQL Injection Methodology

Information Gathering and SQL Injection Vulnerability Detection  

In the Information Gathering phase, information about the web application, Operating System, database, and the structure of the components is collected. Evaluation of the extracted information is useful for identifying vulnerabilities that can be exploited.

Launch SQL Injection Attacks  

An appropriate SQL injection attack can be initiated just after gathering information about the structure of a database and the vulnerabilities found. An injection succeeds by exploiting them.

How can SQL Injection be Prevented?

[Open Worldwide Application Security Project (OWASP) SQL Injection Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html)

1. Use Input Validation 
2. Use a Web Application Firewall (WAF)
3. Use parameterized Queries
4. Use Whitelist instead of Blacklist 
5. Sanitize Encode user-Provided Inputs

# Evasion Techniques

To secure a database, it is recommended that deployment is isolated in a secure network location with an Intrusion Detection System (IDS). IDS continually monitors the network and host traffic and database applications. Using different evasion techniques, the attacker has to evade IDS to access the database.

Types of Signature Evasion Techniques:  

1. Inserting Inline Comments between Keywords  
2. Character Encoding  
3. String Concatenating  
4. Obfuscating Codes  
5. Manipulating White Spaces  
6. Hex Encoding 
7. Sophisticated Matches 

# Countermeasures 

Several detection tools are available to mitigate SQL injection attacks. These tools test websites and applications, report the data and issues, and take remediation action. Some of these advanced tools also offer a technical description of the issue.

Other SQL Injection Countermeasures 

1. Limit the length of user input 
2. Use custom error messages 
3. Monitor DB traffic using an IDS, WAF 
4. Disable commands like xp_cmdshell 
5. Isolate database server and web server 
6. Always use method attribute set to POST and low privileged account for DB connection 
7. Run database service account with minimal rights 
8. Move extended stored procedures to an isolated server 
9. Use typesafe variables or functions such as IsNumeric to ensure type safety 
10. Validate and sanitize user inputs passed to the database 

# SQL Injection Tools

1. BSQL 
2. SQLmap  
3. SQLninja
4. BSQL Hacker
5. Marathon Tool
6. SQL Power Injector
7. Havij