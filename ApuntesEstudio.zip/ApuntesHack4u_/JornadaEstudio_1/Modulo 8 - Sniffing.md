
---
- Tags: #cybrary 
---

# Conceptos

- *SPAN PORT (Switch Port Analyzer)* : Permite capturar trafico desde un puerto en un switch a otro puerto en ese mismo switch

- *Wiretapping*: Es obtener informacion pulsando(tapping) la señal de cables, como por ejemplo un telefono o linea de internet

- *MAC ATTACK*:Un ataque MAC es una forma de ataque de red que se centra en la dirección MAC (Media Access Control) de un dispositivo. Los atacantes pueden utilizar técnicas como el "spoofing" (suplantación) para cambiar su dirección MAC y así ganar acceso no autorizado a una red, o bien para interrumpir la comunicación entre dispositivos dentro de la red.

- *ARP POISONING*: Es una técnica maliciosa en la que un atacante envía falsas respuestas ARP (Address Resolution Protocol) a una red local. Esto puede conducir a que los dispositivos de la red asocien direcciones IP incorrectas con direcciones MAC falsificadas, lo que permite al atacante interceptar o modificar el tráfico de red de manera no autorizada

- *DNS POISONING*: Ataque informático en el que se manipulan las respuestas del sistema de nombres de dominio (DNS) de manera maliciosa.En un ataque de envenenamiento de DNS, un atacante intenta corromper la tabla de caché del servidor DNS o del sistema cliente, para que responda con direcciones IP falsas cuando se soliciten nombres de dominio específicos.