
---
- Tags: #cybrary 
---

# IDS, IPS, Firewall, and Honeypot Concepts

Awareness of cyber and network security is increasing day by day. It is very important to understand the core concepts of the Intrusion Detection/Defense System (IDS) as well as the Intrusion Prevention System (IPS). 

IDS and IPS often create confusion as multiple vendors create both modules and use similar terminology to define the technical concepts. Sometimes the same technology is used for the detection and prevention of threats.

IDS

An intrusion detection system (IDS) monitors traffic on your network, analyzes that traffic for signatures matching known attacks, and when something suspicious happens, you're alerted. In the meantime, the traffic keeps flowing. 

IPS

An intrusion prevention system (IPS) also monitors traffic. But when something unusual happens, the traffic stops altogether until you investigate and decide to open the floodgates again.

# Ways to Detect an Intrusion   

When analyzing traffic for anomalies, a sensor uses multiple techniques based on the rules defined in the IPS/IDS sensor. 

The following tools and techniques can be used in this regard:  

1. Signature-based IDS/IPS: A signature detects an anomaly by looking for some specific string or behavior in a single packet or stream of packets. Next-generation firewalls come with pre-loaded digital signatures, which can be used to mitigate previously discovered attacks. 
2. Policy-based IDS/IPS: As the name suggests, policy-based IDS/IPS modules are based on an organization's policy or Standard Operating Procedure (SOP).
3. Anomaly-based IDS/IPS: In this type, a baseline is created for specific kinds of traffic. 
4. Reputation-based IDS/IPS: Collects information from systems that participate in global correlation. Reputation-based IDS/IPS includes relative descriptors such as known URLs, domain names, etc.

# Types of Intrusion Detection Systems  

Depending on the network scenario, IDS/IPS modules are deployed in one of the following configurations:  

1. Host-based Intrusion Detection
2. Network-based Intrusion Detection

There are four types of Host-based IDS/IPS: 

1. File System Monitoring: In this configuration, IDS/IPS works by closely comparing the versions of files within a directory with the previous versions of the same files and checks for any unauthorized tampering or changes within the files.
2. Log Files Analysis: In this configuration, IDS/IPS works by analyzing the log files of the host machine and generates a warning for the system’s administrators responsible for machine security.
3. Connection Analysis: IDS/IPS works by monitoring the overall network connections being made with the secure machine and determining which are legitimate and how many are unauthorized.
4. Kernel Level Detection: In this configuration, the OS kernel itself detects changes within the system binaries, and any anomaly in the system alerts it to detect intrusion attempts on that machine

# Firewalls

The primary function of using a dedicated firewall at the edge of a corporate network is isolation. A firewall prevents the internal LAN from having a direct connection with the internet or the outside world. This isolation is carried out by but is not limited to:  

1. A Layer 3 device using an Access List for restricting the specific type of traffic on any of its interfaces  
2. A Layer 2 device using the concept of VLANs or Private VLANs (PVLAN) for separating the traffic of two or more networks  
3. A dedicated host device with the installed software. This host device, also acting as a proxy, filters the desired traffic while allowing the remaining traffic 

# Firewall Architecture

Bastion Host 

A Bastion Host is a computer system placed between public and private networks. It is intended to be a crossing point through which traffic passes. The system is assigned certain roles and responsibilities. A bastion host has two interfaces, one connected to the public network and the other to a private network.

Screened Subnet 

Screened Subnet can be set up with a firewall with three interfaces. These three interfaces are connected with the internal Private Network, Public Network, and Demilitarized Zone (DMZ). In this architecture, each zone is separated by another zone hence any compromise of one zone will not affect another.

Multi-homed Firewall 

A Multi-homed Firewall is two or more networks where each interface is connected to its network. It increases the efficiency and reliability of a network. A firewall with two or more interfaces allows further subdivision.

Demilitarized Zone (DMZ) 

A DMZ, or demilitarized zone, is a physical or logical subnet that separates a local area network (LAN) from other untrusted networks, usually the public internet. 

DMZs are also known as perimeter networks or screened subnetworks.

# Types of Firewalls 

Packet Filtering Firewall 

A Packet Filtering Firewall includes the use of access lists to permit or deny traffic based on layer 3 and layer 4 information. Whenever a packet hits an ACL configured layer 3 device’s interface, it checks for a match in an ACL (starting from the first line of ACL).

Circuit-level Gateway Firewall  

A Circuit-level Gateway Firewall operates at the session layer of the OSI model. It captures the packet to monitor the TCP Handshake in order to validate whether the sessions are legitimate. Packets forwarded to the remote destination through a circuit-level firewall appear to be originated from the gateway.

Application-level Firewall 

An Application-level Firewall can work at layer 3 up to layer 7 of the OSI model. Normally, specialized or open-source software running on a high-end server acts as an intermediary between the client and destination address. As these firewalls can operate up to layer 7, it is possible to control moving in and out of more granular packets.

Transparent Firewalls

Transparent Firewalls work exactly like the techniques mentioned earlier, but the firewall interfaces are layer 2 in nature. IP addresses are not assigned to any interface – think of it as a switch with ports assigned to some VLAN. The only IP address assigned to the transparent firewall is for management purposes.

Next Generation (NGFW) Firewalls 

NGFW is a relatively new term for the latest firewalls with advanced feature sets. This firewall provides in-depth security features to mitigate known threats and malware attacks.

Personal Firewalls 

A Personal Firewall is also known as a desktop firewall. It helps to protect end-users personal computers from general attacks from intruders.

# Honeypots 

Honeypots are devices or systems deployed to trap attackers attempting to gain unauthorized access to a system or network. They are deployed in an isolated environment and are monitored. Typically, honeypots are deployed in DMZ and configured identically to a server. Any probe, malware, or infection will be immediately detected as the honeypot appears to be a legitimate part of the network.

# Types of Honeypots

High-Interaction Honeypots 

High-Interaction Honeypots are configured with various services that are enabled to waste an attacker’s time to obtain information about the intrusion. Multiple honeypots can be deployed on a single physical machine and can be restored if an attacker even compromises the honeypot.

Low-Interaction Honeypots 

Low-Interaction Honeypots are configured to entertain only the services that are commonly requested by users. Response time, less complexity, and the need for few resources make low-interaction honeypot deployment easier compared to high-interaction honeypots.

# IDS, Firewall, and Honeypot Tools

Intrusion Detection Tools 

1. Snort
2. ZoneAlarm PRO Firewall 20 15  
3. Comodo Firewall  

Firewalls for Mobile 

1. Android Firewall  
2. Firewall IP  

Honeypot Tools 

1. KFSensor  
2. SPECTER  
3. PatriotBox  
4. HIHAT

# Evading IDS

Insertion Attack 

An Insertion Attack is a kind of evasion of an IDS device done by taking advantage of a belief that an IDS will accept accepted packets. This type of attack particularly targets Signature-based IDS devices to insert data into the IDS. Taking advantage of a vulnerability, an attacker can insert packets with bad checksum or TTL values and send them out of order. 

Evasion 

Evasion is a technique intended to send a packet that is accepted by the end system, but the IDS rejects that. Evasion techniques are intended to exploit the host. An IDS that mistakenly rejects such a packet misses its contents entirely. An attacker may take advantage of this condition and exploit it.

Denial-of-Service Attack (DoS) 

Passive IDS devices are inherently Fail-Open rather than Fail-Closed. Taking advantage of this limitation, an attacker may launch a denial-of-service attack on the network to overload the IDS System. An attacker may target CPU exhaustion or Memory Exhaustion techniques to overload the IDS. These can be done by sending specially crafted packets consuming more CPU resources or transmitting a large number of fragmented out-of-order packets.

Obfuscating 

Obfuscation is the encryption of a packet’s payload destined for a target so that the target host can reverse it, but the IDS cannot. It exploits the end-user without alerting the IDS, using different techniques such as encoding, encryption, and polymorphism. The IDS does not inspect encrypted protocols unless it is configured with the private key used by the server to encrypt the packets. 

False Positive Generation 

False Positive Alert Generation is the false indication of a result inspected for a particular condition or policy. An attacker may generate a large number of false-positive alerts by sending a suspicious packet containing real malicious packets to pass the IDS.

Session Splicing 

Session Splicing is a technique in which an attacker splits the traffic into a large number of smaller packets so that not even a single packet triggers the alert. This can also be done by a slightly different technique, such as adding a delay between packets. This technique is effective for those IDS that do not reassemble the sequence to check against intrusion. 

Unicode Evasion Technique 

The Unicode Evasion Technique is another technique in which an attacker may use Unicode to manipulate the IDS. Unicode is a character encoding, as defined earlier in the HTML Encoding section. Converting strings using Unicode characters can prevent signature matching and alerting the IDS, thus bypassing the detection system.

# Evading Firewalls

Firewall Identification 

Identification of firewalls includes firewall fingerprinting to obtain sensitive information such as open ports, the version of services running in a network, etc. This information is extracted using different techniques, for example, Port Scanning, Fire-Walking, Banner Grabbing, etc. 

Port Scanning 

Port Scanning is an examination procedure mostly used by attackers to identify the open port. However, legitimate users may also use it. Port scanning does not always lead to an attack, as the user and attacker use it. However, a network reconnaissance can be used to collect information before an attack. In this scenario, special packets are forwarded to a particular host whose response is examined by the attacker to get information regarding open ports.

Firewalking 

Firewalking is a technique in which an attacker, using an ICMP packet, finds out the location of the firewall and networking map by probing the ICMP echo request with TTL values incrementing one by one. It helps the attacker to find out the number of hops.

Banner Grabbing 

Banner Grabbing is another technique in which information from a banner is grabbed. Different devices such as routers, firewalls, and web servers display a banner in the console after login through FTP or Telnet. Using banner grabbing, an attacker can extract the target device’s vendor information and firmware version information. 

IP Address Spoofing 

As defined earlier in this workbook, IP Address Spoofing is a technique used to gain unauthorized access to machines by spoofing the IP address. An attacker illicitly impersonates any user machine by sending manipulated IP packets with a spoofed IP address. The spoofing process involves modifying the header with a spoofed source IP address, a checksum, and the order values. 

Source Routing 

Source Routing is the technique of sending a packet via a selected route. In session hijacking, this technique is used to attempt IP spoofing as a legitimate host, and with the help of source routing, the traffic is directed through a path identical to the victim's path.

Bypassing Blocked Sites Using an IP Address

In this technique, a blocked website in a network is accessed using the IP address. Consider a firewall blocking the incoming traffic destined for a particular domain. It can be accessed by typing the IP address in the URL instead of the domain name unless the IP address is also configured in the access control list.

Bypassing Blocked Sites Using a Proxy 

Accessing a blocked website using a proxy is very common. There are many online proxy solutions available that can hide your actual IP address and allow access to restricted websites.

Bypassing through the ICMP Tunneling Method 

CMP tunneling is a technique of injecting arbitrary data into the payload of an echo packet and forwarding it to the targeted host. ICMP tunnels function on ICMP echo requests and reply packets. Using ICMP tunneling, TCP communication is tunneled over a ping request. A reply is received because most firewalls do not examine the payload field of the ICMP packets. Also, some network administrators allow ICMP for troubleshooting purposes.

Bypassing a Firewall through the SSH Tunneling Method 

OpenSSH is an encryption protocol for securing traffic from threats and attacks such as eavesdropping, hijacking, etc. An SSH connection is mostly used by applications to connect to application servers. An attacker uses OpenSSH to encrypt traffic to avoid detection by security devices. 

Bypassing a Firewall through External Systems 

Bypassing through an external system is the process of hijacking a legitimate user's session on a corporate network connected to an external network. An attacker can easily sniff the traffic to extract information, steal session IDs and cookies, and impersonate the user to bypass the firewall. An attacker can also infect the legitimate user using the external system with malware or Trojans to steal information.

# IDS/Firewall Evasion Countermeasures

There are many techniques that make it difficult for an attacker to evade detection. These defensive and monitoring techniques ensure the detection system protects the network and provides more control of traffic. Some of these techniques are basic troubleshooting and monitoring, whereas other techniques focus on the proper configuration of IPS/IDS and firewalls. 

Initially, observe and troubleshoot the firewall by:

1. Port scanning  
2. Banner grabbing  
3. Firewalking  
4. IP address spoofing  
5. Source routing  
6. Bypassing firewall using IP in URL  
7. Attempting a fragmentation attack  
8. Troubleshooting behavior using proxy servers  
9. Troubleshooting behavior using ICMP tunneling