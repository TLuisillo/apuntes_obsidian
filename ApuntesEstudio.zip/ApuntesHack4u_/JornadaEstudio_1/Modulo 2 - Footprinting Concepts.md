
----
- Tags: #cybrary
-------

Recolectar informacion realacionada al objetivo o a la red objetivo, con el fin de identificar posibles vias de entrada a la Red

### Objetivos: 
*conocer la postura de la seguridad, reducir el area de enfoque, identificar vulnerabilidades, y dibujar un mapa de red*

### Metodologia
Recopilacion de informacion publica, como redes sociales,  websites, internet,etc
*Plataformas comunes utilizadas*
- motores de busqueda
- google dorks
- redes sociales
- websites
- emails
- *competitive intelligence* (proceso de recopilar, analizar y utilizar información sobre competidores, clientes, industria y otros factores externos relevantes para la toma de decisiones estratégicas en una organización)
- *WHOIS* (WHOIS es un protocolo de búsqueda y consulta de bases de datos que permite obtener información sobre el registro de nombres de dominio en internet y otros recursos relacionados, como direcciones IP)
- DNS
- Network

Herramienta : Netcraft (ver info de una red)
[LINK](https://searchdns.netcraft.com/)


*SHODAN*: Motor de busqeuda que permite encontrar dispositvos conectados como routers, servidores, IoT u otros dispositvos conectados 

-----

### Website Mirroring
Es el proceso en el cual se crea una replica del sitio web con el fin de estudiarlo o analizarlo para concer su estrucutra o funcionamiento en general:

**HERRAMIENTAS**
- HTTrack
- WEbRipper
- GNU Wget
- Website Ripper Copier
- BlackWindows

---

### Email Footprinting
El atacante envia un mail a la victiva con en el fin de obtener informacion como su nombre, localizacion, direccion, etc:

**HERRAMIENTAS**
- Polite Mail
- Emailtracker Pro
- Read Notify
- Trace Email
- Who Read Me
- Yesware
- Email Lookup
  
---
# Network Footprinting

 El buscador de la informacion puede crear un mapa de la red objetivo y puede llegar a extraer informacion como:
 - Hostname
 - Netwrok address range
 - Exposed Host
 - OS and App Versions
 - Path State
 - Strcuture of apps and Back-End Servers

**HERRAMIENTAS**
- Whois
- Ping
- NsLookup
- Tracert