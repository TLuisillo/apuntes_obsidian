---------
- Tags #enum  #tutorial #reconocimiento #puerto
----------

- Ingreso Usuario *Anonymus*
```bash
ftp <ip>
//Digitar Usuario
//Enter
```

