


## Contenedor to IMG
```bash
docker commit idCont nombreSnap
```


### Compilar
```bash
docker build --tag mimaquina .
```


## Exportar a TAR
```bash
docker save -o maquina.tar maquina:latest  
```

