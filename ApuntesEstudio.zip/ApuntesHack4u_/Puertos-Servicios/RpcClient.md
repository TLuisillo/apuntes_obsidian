

---
- Tags: #tools #AD #enum #tutorial 
---

- Enumerar usuarios y grupos
```bash
enumdomusers

enumdomgroups
```

- RID enumeration
```bash
querygroupmem 0x200
(RID a usar)
```



- Info de cada usuario
```bash
querydispinfo
```