-----------
- Tags: #BOF
---------

# Definicion

El **buffer overflow** (**desbordamiento de búfer**) es una vulnerabilidad común en software que puede permitir a un atacante ejecutar código malicioso o tomar control de un sistema comprometido.

Esta vulnerabilidad se produce cuando un programa intenta almacenar **más datos** en un **búfer** (zona de memoria temporal para almacenamiento de datos) de lo que se había previsto, y al exceder la capacidad del búfer, los datos adicionales se escriben en otras zonas de memoria adyacentes.

Esto puede permitir que un atacante escriba código malicioso en estas zonas de memoria y sobrescriba otros datos críticos del sistema, como la dirección de retorno de una función o la dirección de memoria donde se almacena una variable, permitiendo al atacante tomar el control del flujo del programa.

Los impactos de un buffer overflow pueden ser graves, ya que un atacante puede aprovechar esta vulnerabilidad para obtener información confidencial, robar datos o incluso tomar el control completo del sistema. Si los atacantes disponen del conocimiento necesario, pueden incluso conseguir ejecutar comandos maliciosos en el sistema comprometido.

DEP (Data Execution Prevention) es una medida de seguridad que se utiliza para prevenir la ejecución de código malicioso en sistemas comprometidos a través de un buffer overflow.

DEP trabaja marcando ciertas áreas de memoria como “**no ejecutables**“, lo que significa que cualquier intento de ejecutar código en esas áreas de memoria será bloqueado y se producirá una excepción.

Esto es especialmente útil para prevenir ataques de buffer overflow que intentan aprovecharse de la ejecución de código en zonas de memoria vulnerables. Al marcar estas zonas de memoria como “no ejecutables”, DEP puede prevenir que el código malicioso se ejecute y proteger el sistema de posibles daños. Aún así, esto puede no ser suficiente para impedir que el atacante logre inyectar sus instrucciones maliciosas.