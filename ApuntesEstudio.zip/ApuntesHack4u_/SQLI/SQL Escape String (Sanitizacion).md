----------
- Tags: #sql #sqli #basesdatos 
-------------

### Filtrado de entradas
Filtrar la entrada también puede ser útil para protegerse contra la inyección SQL eliminando los caracteres de escape. Sin embargo, debido al gran número de caracteres que pueden plantear problemas, ésta no es una defensa fiable. El siguiente ejemplo busca el carácter delimitador de cadena.

```C#
private string SafeSqlLiteral(string inputSQL)  
{  
  return inputSQL.Replace("'", "''");  
}  

```
LIKE Clauses:
Tenga en cuenta que si utiliza una cláusula LIKE, los caracteres comodín deben escaparse:

```C#
s = s.Replace("[", "[[]");  
s = s.Replace("%", "[%]");  
s = s.Replace("_", "[_]");
```

- Referencias: [Input Filter](https://learn.microsoft.com/en-us/sql/relational-databases/security/sql-injection?view=sql-server-ver16)