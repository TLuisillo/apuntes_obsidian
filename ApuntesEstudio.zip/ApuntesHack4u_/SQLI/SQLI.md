--------------------------
- Tags:  #sqli #sql #basesdatos
------------------------------

# Definicion

**SQL Injection** (**SQLI**) es una técnica de ataque utilizada para explotar vulnerabilidades en aplicaciones web que **no validan adecuadamente** la entrada del usuario en la consulta SQL que se envía a la base de datos. Los atacantes pueden utilizar esta técnica para ejecutar consultas SQL maliciosas y obtener información confidencial, como nombres de usuario, contraseñas y otra información almacenada en la base de datos.

Las inyecciones SQL se producen cuando los atacantes insertan código SQL malicioso en los campos de entrada de una aplicación web. Si la aplicación no valida adecuadamente la entrada del usuario, la consulta SQL maliciosa se ejecutará en la base de datos, lo que permitirá al atacante obtener información confidencial o incluso controlar la base de datos.

-------------------------------

## Tipos
- **Inyección SQL basada en errores**:
- **Inyección SQL basada en tiempo**:
- **Inyección SQL basada en booleanos**:
- **Inyección SQL basada en uniones**:
- **Inyección SQL basada en stacked queries**: