
---
- Tags: #tools #AD #enum #tutorial #writeup 
---

```bash
kerbrute userenum -d cicada.htb --dc 10.10.11.35 ../users.txt 
```
