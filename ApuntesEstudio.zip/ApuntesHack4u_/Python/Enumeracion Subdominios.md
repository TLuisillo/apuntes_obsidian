
---
- Tags: #python #tools 
---

```python
#!/usr//bin/python3
#Author: TLuisillo_o

import requests
from os import path
import argparse
import sys,time,signal

#Parametros
parser = argparse.ArgumentParser()
parser.add_argument('-t','--target', help='Indicar Dominio')
parser = parser.parse_args()

# CTRL + C
def signal_handler(key, frame):
	print("\n\n[!] Saliendo...\n")
	sys.exit(0)

signal = signal.signal(signal.SIGINT, signal_handler)

# Main
def main():
    if parser.target:
        if path.exists('/usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt'):
            wordlist = open('/usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt' ,'r')
            wordlist = wordlist.read().split('\n')
            # HTTP
            for subdomain in wordlist:
                url = "http://" + subdomain + "." + parser.target
                try:
                    requests.get(url)
                except requests.ConnectionError:
                    pass
                else:
                    print("[+] Subdominio Encontrado: " + url)   
            #HTTPS
            for subdomain in wordlist:
                url = "https://" + subdomain + "." + parser.target
                try:
                    requests.get(url)
                except requests.ConnectionError:
                    pass
                else:
                    print("[+] Subdominio Encontrado: " + url)         
    else:
        print("[!] Ingrese un dominio valido")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(0)
```
