
---------
- Tags: #privesc #info #sudo #tutorial 
----

- Parecido a Bandit en OverTheWire
- Lo  que hacemos es intentar reducir las proporciones de la ventana para ganar una especie  de "Consola de comandos", Podemos probar haciendo uso de:
```bash
stty rows X columns Y
```

- O simplemente reduciendo el tamaño de la term.
- Por ultimo nos mandamos una */bin/sh*
