
---
- Tags: #tutorial #scripting #terminal #privesc 
---

### Importante estar en /dev/shm o directorio con permisos

```shell
cd /dev/shm  
```

```shell
#!/bin/bash  
  
old=$(ps -eo command)  
filter="kworker|command|defunct"  
  
function ctrl_c(){  
  exit 1  
}  
  
trap ctrl_c int  
  
while true; do  
  new=$(ps -eo command)  
  diff <(echo "$old") <(echo "$new") | grep "[\>\<]" | grep -vE "$filter"  
  old=$new  
done  
```

```shell
chmod +x pspysito.sh
```


---

## Script 2
```bash
#!/bin/bash

old_process=$(ps -eo user,command)

while true; do
    new_process=$(ps -eo user,command)
    diff <(echo "$old_process") <(echo "$new_process") | grep "^[<>]" | grep -vE "procmon|command|kworker"
    old_process=$new_process
done
```