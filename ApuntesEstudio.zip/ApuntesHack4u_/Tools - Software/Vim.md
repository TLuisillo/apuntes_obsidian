--------------
- Tags: #shell #bash #tools #scripting #terminal
--------------------

## Los modos de Vim

La clave para aprender a manejar Vim es acostumbrarse a sus distintos modos de funcionamiento. Esta es la parte que hace a Vim especial y difícil de entender para las personas que se inician.

### Modo comando

Cuando abrimos un archivo para editar con Vim, algo que conseguimos desde el terminal con el comando _vim_ seguido del nombre del archivo que se desea editar.

vim archivo.txt

Una vez abierto Vim, se inicia en modo comando.

El modo comando permite realizar gran cantidad de acciones administrativas sobre el fichero, como buscar en el texto, salir, guardar, borrar líneas, etc.

### Modo inserción

El modo inserción nos sirve cuando queremos editar el texto del archivo, añadiendo nuevo contenido con el teclado, o borrando carácter a carácter con las correspondientes teclas (_Retroceso_/_Supr_).

Estando en modo comando, pasamos a modo inserción pulsando la tecla _i_. A partir de entonces el editor funcionará tal y como se esperaría en un editor de texto. Es decir, escribes cualquier cosa y se va introduciendo el texto en el archivo.

Para salir del modo inserción y volver al modo comando pulsamos la tecla escape _Esc_.

## Guía esencial de Vim

Ahora veamos los comandos más útiles y necesarios para que nuestros primeros pasos con Vim sean más llevaderos. **Recuerda que estos comandos los tienes que escribir en modo comando y no en modo inserción.**

Para algunos de estos comandos es necesario pulsar la tecla Enter para que realmente se ejecuten. En este caso, los comandos aparecerán en la parte de abajo del terminal, para que veamos qué es lo que se va a ejecutar.

### Guardar y cerrar

- **_:w_** – Permite guardar el fichero.
- **_:q_** – Salir de Vim. Si el fichero ha sido modificado pero no se ha guardado, nos advertirá y no podremos salir de Vim usando este comando.
- _**:q!**_ – Salir de Vim, descartando posibles cambios no guardados que se hayan realizado en el fichero.
- _**:wq**_ – Hace el guardado del archivo y después sale de Vim.

### Deshacer y rehacer

- _**u**_ – Deshacer acción.
- _**Ctrl+r**_ – Rehacer una acción.

### Moverse por el fichero

Además de usar los cursores para movernos por el archivo, podemos movernos de una manera más rápida con algunos comandos:

- _**gg**_ – Ponerse al inicio del fichero.
- _**Mayús+g**_ – Ir a la última línea del fichero.
- _**Num+G**_ – Ir a una línea determinada. Por ejemplo 14G llevaría el cursor a la línea 14.
- :set number – Hace que el editor muestre el número de las líneas.
- _**$**_ – Ir al final de la línea.
- _**0**_ – Ir al principio de la línea.

### Borrar líneas

- _**dd**_ – El comando permite borrar la línea actual, donde está el cursor.
- _**d+num**_ – Este comando permite borrar un número de líneas. Por ejemplo, d3 borrará tres líneas.

### Buscar

Vim tiene unas herramientas muy potentes para buscar texto en los archivos. Los comandos más útiles son los siguientes:

- _**/+texto**_ – Al pulsar «/» se abre la función de búsqueda. Entonces podremos escribir el texto que queremos buscar. El editor resaltará todas las apariciones de este texto. Pulsamos enter y nos llevará a la siguiente aparición de la búsqueda, con respecto a la posición de nuestro cursor.
- _**n**_ y _**N**_ – Una vez hemos aceptada una búsqueda, el comando _**n**_ nos lleva a la siguiente aparición de la cadena buscada. El comando _**N**_ nos llevará a la anterior.

### Otras ayudas

Con estos comandos te aseguramos que te podrás defender por Vim con cierta agilidad, de modo que puedas realizar las tareas de edición más comunes. Además, desde Vim puedes hacer lo siguiente:

- _**:h –**_ Abre la ayuda principal de Vim. Esto hacer que nuestra ventana de terminal se divida en dos editores. En este momento nuestro cursor estará en el texto del archivo de ayuda de Vim. Podremos leer el fichero y utilizar las funciones de búsqueda comentadas con anterioridad. Cuando queramos salir tenemos que hacerlo como cualquier otro fichero, usando el comando correspondiente de Vim, por ejemplo _**:q**_.