---------------
- Tags: #tools #comands #software #reversing 
---------------------

# Definicion

Steghide **es un software de esteganografía de código abierto que permite ocultar un archivo secreto en un archivo de imagen o audio**. No notarás ningún cambio en la imagen o el archivo de audio. Sin embargo, el archivo secreto estará dentro de la imagen original o el archivo de audio. Es un software de línea de comandos.

- ## Uso

-  Poner un archivo dentro de la imagen **Embed** 
```bash
steghide embed -ef my.txt -cf img.jpg
//digitar Clave
```

- *Extraer* archivo oculto de la imagen
```bash
steghide extract -sF img.jpg
//Proporcionar la Clave
```

- Ver *informacion* del archivo imagen
```bash
steghide info fileExample.wav

//Try to get information about embedded data? (Y/N)? Yzca
//Enter Passphrase
```

