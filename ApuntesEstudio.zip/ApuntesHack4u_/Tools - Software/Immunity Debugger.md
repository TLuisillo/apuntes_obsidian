----------------------------
- Tags: #software #BOF #shellcode #reversing #debugging
---------------

# Definicion

Immunity Debugger el **Depurador** Inmmunity es una poderosa nueva manera para escribir exploits, analizar malware, y realizar ingeniería inversa a archivos binarios. Se construye sobre una sólida interfaz de usuario con representación gráfica de funciones, es la primera herramienta de la industria construida específicamente para creación de pila, con una amplia y bien soportada API Python para una fácil expansión.

![[Pasted image 20230723213522.png]]

## Entre sus características principales se enumeran.

- Un depurador con una funcionalidad diseñada específicamente para la industria de la seguridad
- Acorta el 50% el tiempo para desarrollo de exploits.
- Interfaces simples y comprensibles.
- Lenguaje de Scripting robusto y poderoso para una depuración inteligente.
- Depuración rápida y liviana para prevenir corrupción durante un análisis complejo.
- Conectividad a fuzzers y herramientas para el desarrollo de exploits.

![[Pasted image 20230723213627.png]]