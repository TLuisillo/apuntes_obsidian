-------
- Tags: #tools #comands #software #reversing #github 
---------

# Definicion

Binwalk es una **herramienta rápida y fácil de usar para: analizar en busca de codigo malicioso, realizar ingeniería inversa y extraer imágenes de firmware**. Binwalk hace un buen trabajo analizando posibles firmas de archivos y filtrando falsos positivos obvios, pero no es perfecto

- **How to install:**
```bash
sudo apt install binwalk
```

---------------------------

- Binwalk es una herramienta rápida y fácil de usar para analizar, realizar ingeniería inversa y extraer imágenes de firmware.

Además de firmware, Binwalk puede analizar archivos e imágenes de sistemas de archivos para encontrar muchos tipos de archivos incorporados y sistemas de archivos diferentes.

Binwalk contiene un gran número de firmas de varios archivos, gracias a las cuales el programa puede encontrar archivos incorporados. Binwalk puede utilizarse para identificar tipos de archivos sin extensiones.


## Uso: 

```
binwalk -e example.bin

//

binwalk --extract --directory output_directory path/to/binary
```

-----------------

GitHub: [Link](https://github.com/ReFirmLabs/binwalk)
