-----------
- Tags: #tools #github #pivoting 
----------

# Definicion
Es una utilidad que puede ser utilizada por los profesionales de la seguridad informática para ayudar en la realización de tareas relacionadas con la explotación de sistemas y redes de manera ética y con fines de pruebas de seguridad.

Chisel es una herramienta que se utiliza para establecer túneles o conexiones seguras a través de una red comprometida o insegura. Permite a los profesionales de la seguridad redirigir el tráfico de red de una manera segura y controlada, lo que puede ser útil para la depuración, la supervisión de tráfico o la realización de pruebas de penetración. Algunas de las características típicas de Chisel incluyen:

1. **Túneles reversos y directos**: Chisel puede establecer túneles tanto en sentido inverso (desde la máquina comprometida hacia el atacante) como en sentido directo (desde el atacante hacia la máquina comprometida).
    
2. **Autenticación y cifrado**: Puede cifrar y autenticar el tráfico que fluye a través de los túneles, lo que garantiza la confidencialidad e integridad de los datos.
    
3. **Puertos dinámicos**: Permite asignar puertos dinámicos para reenviar tráfico a través del túnel, lo que facilita la evasión de restricciones de firewall y detección de intrusiones.
    
4. **Compatibilidad con diferentes protocolos**: Chisel es compatible con varios protocolos de red, lo que le permite ser utilizado en una variedad de escenarios de seguridad.

--------
- ## Descarga
- [Github Link](https://github.com/jpillora/chisel/releases/tag/v1.9.1)  (linux_amd64.gz)
```bash
gunzip linux_amd64.gz
mv linux_amd64 chisel
chmod +x chisel
```

- ## Uso (Maquina Atacante)
```bash
./chisel server -p 1234 --reverse
```

- ### Port Forwading
```bash
./chisel client <LocalIPAtacante>:1234 R:9000:127.0.0.1:5000 
```

- ## Maquina Victima (Tunel socks)
```bash
./chisel client <ipAtacante>:Puerto R:socks
```
-----------

- ## M Atacante
```bash
cp /etc/proxychains.conf .  
(traer una copia al Lab para mas comodidad)
```

```bash
nano proxychain.conf
cambiar socks4 a socks5
cambiar puerto deacuerdo al TUNEL DE CHISEL  
```
