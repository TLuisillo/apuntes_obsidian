--------------
- Tags: #pivoting #msfv #payload 
---------------

# Descubrir Dispositivos en la red / Barrido de la red

```bash
MAQUINA 1 (puente)

for ip in {1..254} ;do (ping 172.223.0.$ip -c 1 >/dev/null && echo "[+] Host Up: 172.223.0.$ip" &) ;done

```

- ## Descubrimiento Puertos 
```bash
for port in {1..65535} ;do echo '' > /dev/tcp/10.0.3.3/$port 2>/dev/null && echo "[+] Puerto $port OPEN" ;done 2>/dev/null
```

- ## Gobuster con PROXY
```shell
gobuster dir -u http://<IpVictima2>/ -w /usr/share/seclist/Discovery/Web-Content/directory-list-2.3-medium.txt --proxy socks5://127.0.0.1:1080
```

- ## Nmap Con Proxy
```shell
proxychains nmap -p80 <IpVictima2> -Pn -sT
```